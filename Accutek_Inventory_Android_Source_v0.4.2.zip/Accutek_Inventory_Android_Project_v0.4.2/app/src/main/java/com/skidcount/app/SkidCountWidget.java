package com.skidcount.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;
import android.widget.Toast;

public final class SkidCountWidget extends AppWidgetProvider {
    static final String ACTION_PREVIOUS = "com.skidcount.app.widget.PREVIOUS";
    static final String ACTION_NEXT = "com.skidcount.app.widget.NEXT";
    static final String ACTION_OPEN_BOX = "com.skidcount.app.widget.OPEN_BOX";
    static final String EXTRA_PART_ID = "part_id";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    static void updateWidgets(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            final RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_skidcount);

            final Intent serviceIntent = new Intent(context, SkidCountWidgetService.class);
            serviceIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            serviceIntent.setData(android.net.Uri.parse(serviceIntent.toUri(Intent.URI_INTENT_SCHEME)));
            views.setRemoteAdapter(R.id.widget_stack, serviceIntent);
            views.setEmptyView(R.id.widget_stack, R.id.widget_empty);

            final Intent openBoxTemplate = new Intent(context, SkidCountWidget.class)
                    .setAction(ACTION_OPEN_BOX)
                    .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
            final int mutableFlag = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                    ? PendingIntent.FLAG_MUTABLE
                    : 0;
            final PendingIntent openBoxPendingIntent = PendingIntent.getBroadcast(
                    context,
                    30000 + appWidgetId,
                    openBoxTemplate,
                    PendingIntent.FLAG_UPDATE_CURRENT | mutableFlag
            );
            views.setPendingIntentTemplate(R.id.widget_stack, openBoxPendingIntent);

            views.setOnClickPendingIntent(
                    R.id.widget_previous,
                    broadcastIntent(context, ACTION_PREVIOUS, appWidgetId, 10000 + appWidgetId)
            );
            views.setOnClickPendingIntent(
                    R.id.widget_next,
                    broadcastIntent(context, ACTION_NEXT, appWidgetId, 20000 + appWidgetId)
            );

            final Intent appIntent = new Intent(context, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            final PendingIntent openApp = PendingIntent.getActivity(
                    context,
                    40000 + appWidgetId,
                    appIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            views.setOnClickPendingIntent(R.id.widget_open_app, openApp);

            manager.updateAppWidget(appWidgetId, views);
            manager.notifyAppWidgetViewDataChanged(appWidgetId, R.id.widget_stack);
        }
    }

    private static PendingIntent broadcastIntent(Context context, String action, int appWidgetId, int requestCode) {
        final Intent intent = new Intent(context, SkidCountWidget.class)
                .setAction(action)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        final String action = intent.getAction();
        if (action == null) {
            return;
        }

        final int appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        final AppWidgetManager manager = AppWidgetManager.getInstance(context);

        if (ACTION_PREVIOUS.equals(action) || ACTION_NEXT.equals(action)) {
            if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
                return;
            }
            final RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_skidcount);
            if (ACTION_PREVIOUS.equals(action)) {
                views.showPrevious(R.id.widget_stack);
            } else {
                views.showNext(R.id.widget_stack);
            }
            manager.partiallyUpdateAppWidget(appWidgetId, views);
            return;
        }

        if (ACTION_OPEN_BOX.equals(action)) {
            final String partId = intent.getStringExtra(EXTRA_PART_ID);
            final StateStore.OpenBoxResult result = StateStore.openBox(context, partId);
            Toast.makeText(context, result.message(), Toast.LENGTH_SHORT).show();

            final ComponentName componentName = new ComponentName(context, SkidCountWidget.class);
            final int[] ids = manager.getAppWidgetIds(componentName);
            manager.notifyAppWidgetViewDataChanged(ids, R.id.widget_stack);
            updateWidgets(context, manager, ids);
        }
    }
}
