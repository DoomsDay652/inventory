package com.skidcount.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class NativeBridge {
    private static final String WORK_ROOT = "Accutek Inventory Work Photos";

    private final Activity activity;
    private final Context context;
    private final WebView webView;
    private final TextRecognizer recognizer;
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();

    NativeBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.webView = webView;
        this.recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @JavascriptInterface
    public String getState() {
        return StateStore.getStateJson(context);
    }

    @JavascriptInterface
    public void syncState(String json) {
        if (json == null || json.isBlank()) {
            return;
        }
        try {
            new JSONObject(json);
            StateStore.saveStateJson(context, json);
        } catch (Exception ignored) {
            showToast("Accutek Inventory could not save invalid inventory data");
        }
    }

    @JavascriptInterface
    public void recognizeText(String requestId, String dataUrl) {
        ioExecutor.execute(() -> {
            try {
                final byte[] bytes = decodeDataUrl(dataUrl);
                final Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) {
                    sendOcrResult(requestId, "", "The image could not be decoded");
                    return;
                }

                final InputImage image = InputImage.fromBitmap(bitmap, 0);
                recognizer.process(image)
                        .addOnSuccessListener(result ->
                                sendOcrResult(requestId, result.getText(), "")
                        )
                        .addOnFailureListener(error ->
                                sendOcrResult(
                                        requestId,
                                        "",
                                        error.getMessage() == null
                                                ? "OCR failed"
                                                : error.getMessage()
                                )
                        );
            } catch (Exception error) {
                sendOcrResult(
                        requestId,
                        "",
                        error.getMessage() == null ? "OCR failed" : error.getMessage()
                );
            }
        });
    }

    /**
     * Saves a durable process photo into app-private external storage.
     * These files do not appear in the user's personal Camera/DCIM roll.
     */
    @JavascriptInterface
    public void saveWorkPhoto(
            String requestId,
            String dataUrl,
            String partId,
            String partName,
            String stage,
            String notes,
            String setId,
            String setName
    ) {
        ioExecutor.execute(() -> {
            try {
                final byte[] bytes = decodeDataUrl(dataUrl);
                final Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) {
                    sendWorkPhotoResult(
                            requestId,
                            null,
                            "The work photo could not be decoded"
                    );
                    return;
                }

                final Date now = new Date();
                final String dateFolder = new SimpleDateFormat(
                        "yyyy-MM-dd",
                        Locale.US
                ).format(now);
                final String timestamp = new SimpleDateFormat(
                        "yyyyMMdd-HHmmss-SSS",
                        Locale.US
                ).format(now);

                final File picturesRoot = context.getExternalFilesDir(
                        Environment.DIRECTORY_PICTURES
                );
                if (picturesRoot == null) {
                    throw new IllegalStateException(
                            "The app-private photo folder is unavailable"
                    );
                }

                final File folder = new File(
                        picturesRoot,
                        WORK_ROOT
                                + File.separator + safeFolder(partName, "Unknown Part")
                                + File.separator + dateFolder
                                + File.separator + safeFolder(
                                        setName == null || setName.isBlank()
                                                ? setId
                                                : setName,
                                        "Photo Set"
                                )
                );
                if (!folder.exists() && !folder.mkdirs()) {
                    throw new IllegalStateException(
                            "The work photo folder could not be created"
                    );
                }

                final String filename = timestamp
                        + "-"
                        + safeFolder(stage, "process")
                        + ".jpg";
                final File outputFile = new File(folder, filename);
                try (FileOutputStream stream = new FileOutputStream(outputFile)) {
                    stream.write(bytes);
                }

                final String photoId = UUID.randomUUID().toString();
                final String thumbnailDataUrl = createThumbnailDataUrl(bitmap);
                bitmap.recycle();

                final JSONObject result = new JSONObject();
                result.put("id", photoId);
                result.put("path", outputFile.getAbsolutePath());
                result.put("filename", filename);
                result.put("partId", partId == null ? "" : partId);
                result.put("partName", partName == null ? "" : partName);
                result.put("stage", stage == null ? "" : stage);
                result.put("notes", notes == null ? "" : notes);
                result.put("setId", setId == null ? "" : setId);
                result.put("setName", setName == null ? "" : setName);
                result.put("createdAt", new Date().toInstant().toString());
                result.put("thumbnail", thumbnailDataUrl);
                result.put("privateStorage", true);

                sendWorkPhotoResult(requestId, result, "");
            } catch (Exception error) {
                sendWorkPhotoResult(
                        requestId,
                        null,
                        error.getMessage() == null
                                ? "The work photo could not be saved"
                                : error.getMessage()
                );
            }
        });
    }

    @JavascriptInterface
    public void deleteWorkPhoto(String absolutePath) {
        ioExecutor.execute(() -> {
            try {
                if (!isManagedWorkPhoto(absolutePath)) {
                    return;
                }
                final File file = new File(absolutePath);
                if (file.exists() && !file.delete()) {
                    showToast("The photo record was removed, but the image file could not be deleted");
                }
                removeEmptyParents(file.getParentFile());
            } catch (Exception ignored) {
                // The web state is the source of truth for the photo record.
            }
        });
    }

    @JavascriptInterface
    public void openWorkPhoto(String absolutePath) {
        activity.runOnUiThread(() -> {
            try {
                final File file = requireManagedWorkPhoto(absolutePath);
                final Uri uri = FileProvider.getUriForFile(
                        activity,
                        activity.getPackageName() + ".fileprovider",
                        file
                );
                final Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, "image/jpeg");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(intent);
            } catch (Exception error) {
                showToast("Could not open that work photo");
            }
        });
    }

    /**
     * Opens the user's email/share app with the selected work photos attached.
     * The user still reviews and sends the message themselves.
     */
    @JavascriptInterface
    public void shareWorkPhotos(
            String absolutePathsJson,
            String recipient,
            String subject,
            String body
    ) {
        ioExecutor.execute(() -> {
            try {
                final ArrayList<Uri> uris = parseManagedPhotoUris(absolutePathsJson);
                if (uris.isEmpty()) {
                    showToast("There are no saved work photos to attach");
                    return;
                }

                final Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                intent.setType("image/jpeg");
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                if (recipient != null && !recipient.isBlank()) {
                    intent.putExtra(
                            Intent.EXTRA_EMAIL,
                            new String[]{recipient.trim()}
                    );
                }
                intent.putExtra(
                        Intent.EXTRA_SUBJECT,
                        subject == null ? "" : subject
                );
                intent.putExtra(
                        Intent.EXTRA_TEXT,
                        body == null ? "" : body
                );
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                final ClipData clipData = ClipData.newRawUri(
                        "Accutek Inventory work photos",
                        uris.get(0)
                );
                for (int i = 1; i < uris.size(); i++) {
                    clipData.addItem(new ClipData.Item(uris.get(i)));
                }
                intent.setClipData(clipData);

                activity.runOnUiThread(() -> {
                    try {
                        activity.startActivity(
                                Intent.createChooser(
                                        intent,
                                        "Email or share work photos"
                                )
                        );
                    } catch (Exception error) {
                        showToast("No email or sharing app is available");
                    }
                });
            } catch (Exception error) {
                showToast(
                        "Could not prepare the work photos: "
                                + safeMessage(error)
                );
            }
        });
    }

    /**
     * Copies selected private work photos into a visible Downloads folder.
     * This is useful for manual upload, backup, or transferring them elsewhere.
     */
    @JavascriptInterface
    public void exportWorkPhotos(
            String absolutePathsJson,
            String folderName
    ) {
        ioExecutor.execute(() -> {
            try {
                final JSONArray paths = new JSONArray(
                        absolutePathsJson == null ? "[]" : absolutePathsJson
                );
                int copied = 0;
                final String relativeFolder = Environment.DIRECTORY_DOWNLOADS
                        + "/Accutek Inventory/Work Photos/"
                        + safeFolder(folderName, "Export");

                for (int i = 0; i < paths.length(); i++) {
                    final String path = paths.optString(i, "");
                    if (!isManagedWorkPhoto(path)) {
                        continue;
                    }
                    final File source = new File(path);
                    if (!source.exists()) {
                        continue;
                    }

                    final ContentValues values = new ContentValues();
                    values.put(
                            MediaStore.MediaColumns.DISPLAY_NAME,
                            source.getName()
                    );
                    values.put(
                            MediaStore.MediaColumns.MIME_TYPE,
                            "image/jpeg"
                    );
                    values.put(
                            MediaStore.MediaColumns.RELATIVE_PATH,
                            relativeFolder
                    );

                    final Uri destination = context
                            .getContentResolver()
                            .insert(
                                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                    values
                            );
                    if (destination == null) {
                        continue;
                    }

                    try (
                            FileInputStream input = new FileInputStream(source);
                            OutputStream output = context
                                    .getContentResolver()
                                    .openOutputStream(destination, "w")
                    ) {
                        if (output == null) {
                            continue;
                        }
                        final byte[] buffer = new byte[16 * 1024];
                        int read;
                        while ((read = input.read(buffer)) != -1) {
                            output.write(buffer, 0, read);
                        }
                        copied++;
                    }
                }

                showToast(
                        copied + " work photo"
                                + (copied == 1 ? "" : "s")
                                + " exported to Downloads/Accutek Inventory/Work Photos"
                );
            } catch (Exception error) {
                showToast(
                        "Could not export the work photos: "
                                + safeMessage(error)
                );
            }
        });
    }

    @JavascriptInterface
    public void saveTextFile(String filename, String mimeType, String content) {
        ioExecutor.execute(() -> {
            try {
                final String safeName = sanitizeFilename(filename);
                final ContentResolver resolver = context.getContentResolver();
                final ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                values.put(
                        MediaStore.MediaColumns.MIME_TYPE,
                        mimeType == null || mimeType.isBlank()
                                ? "text/plain"
                                : mimeType
                );
                values.put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Accutek Inventory"
                );

                final Uri uri = resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        values
                );
                if (uri == null) {
                    throw new IllegalStateException(
                            "Downloads location is unavailable"
                    );
                }
                try (OutputStream stream = resolver.openOutputStream(uri, "w")) {
                    if (stream == null) {
                        throw new IllegalStateException(
                                "The download file could not be opened"
                        );
                    }
                    stream.write(
                            (content == null ? "" : content)
                                    .getBytes(StandardCharsets.UTF_8)
                    );
                }
                showToast(
                        "Saved to Downloads/Accutek Inventory/" + safeName
                );
            } catch (Exception error) {
                showToast(
                        "Could not save the file: " + safeMessage(error)
                );
            }
        });
    }

    void close() {
        recognizer.close();
        ioExecutor.shutdownNow();
    }

    private byte[] decodeDataUrl(String dataUrl) {
        final int comma = dataUrl == null ? -1 : dataUrl.indexOf(',');
        final String encoded = comma >= 0
                ? dataUrl.substring(comma + 1)
                : dataUrl;
        return Base64.decode(encoded, Base64.DEFAULT);
    }

    private String createThumbnailDataUrl(Bitmap bitmap) {
        final int maxSide = 320;
        final double scale = Math.min(
                1.0,
                (double) maxSide / Math.max(bitmap.getWidth(), bitmap.getHeight())
        );
        final int width = Math.max(
                1,
                (int) Math.round(bitmap.getWidth() * scale)
        );
        final int height = Math.max(
                1,
                (int) Math.round(bitmap.getHeight() * scale)
        );
        final Bitmap thumb = width == bitmap.getWidth()
                && height == bitmap.getHeight()
                ? bitmap
                : Bitmap.createScaledBitmap(bitmap, width, height, true);
        final ByteArrayOutputStream stream = new ByteArrayOutputStream();
        thumb.compress(Bitmap.CompressFormat.JPEG, 62, stream);
        if (thumb != bitmap) {
            thumb.recycle();
        }
        return "data:image/jpeg;base64,"
                + Base64.encodeToString(
                        stream.toByteArray(),
                        Base64.NO_WRAP
                );
    }

    private ArrayList<Uri> parseManagedPhotoUris(String json) throws Exception {
        final JSONArray paths = new JSONArray(
                json == null ? "[]" : json
        );
        final ArrayList<Uri> uris = new ArrayList<>();
        for (int i = 0; i < paths.length(); i++) {
            final String path = paths.optString(i, "");
            if (!isManagedWorkPhoto(path)) {
                continue;
            }
            final File file = new File(path);
            if (!file.exists()) {
                continue;
            }
            uris.add(
                    FileProvider.getUriForFile(
                            activity,
                            activity.getPackageName() + ".fileprovider",
                            file
                    )
            );
        }
        return uris;
    }

    private File requireManagedWorkPhoto(String absolutePath) {
        if (!isManagedWorkPhoto(absolutePath)) {
            throw new IllegalArgumentException("Photo is outside app storage");
        }
        final File file = new File(absolutePath);
        if (!file.exists()) {
            throw new IllegalArgumentException("Photo file is missing");
        }
        return file;
    }

    private boolean isManagedWorkPhoto(String absolutePath) {
        if (absolutePath == null || absolutePath.isBlank()) {
            return false;
        }
        try {
            final File picturesRoot = context.getExternalFilesDir(
                    Environment.DIRECTORY_PICTURES
            );
            if (picturesRoot == null) {
                return false;
            }
            final File workRoot = new File(picturesRoot, WORK_ROOT);
            final String canonicalRoot = workRoot.getCanonicalPath()
                    + File.separator;
            final String canonicalPhoto = new File(absolutePath)
                    .getCanonicalPath();
            return canonicalPhoto.startsWith(canonicalRoot);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void removeEmptyParents(File folder) {
        try {
            final File picturesRoot = context.getExternalFilesDir(
                    Environment.DIRECTORY_PICTURES
            );
            if (picturesRoot == null) {
                return;
            }
            final File workRoot = new File(picturesRoot, WORK_ROOT);
            while (folder != null
                    && !folder.equals(workRoot)
                    && folder.isDirectory()) {
                final File[] children = folder.listFiles();
                if (children != null && children.length == 0) {
                    final File parent = folder.getParentFile();
                    //noinspection ResultOfMethodCallIgnored
                    folder.delete();
                    folder = parent;
                } else {
                    break;
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void sendOcrResult(String requestId, String text, String error) {
        final String script = "window.onNativeOcrResult("
                + JSONObject.quote(requestId == null ? "" : requestId) + ","
                + JSONObject.quote(text == null ? "" : text) + ","
                + JSONObject.quote(error == null ? "" : error)
                + ");";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void sendWorkPhotoResult(
            String requestId,
            JSONObject result,
            String error
    ) {
        final String script = "window.onNativeWorkPhotoSaved("
                + JSONObject.quote(requestId == null ? "" : requestId) + ","
                + (result == null ? "null" : result.toString()) + ","
                + JSONObject.quote(error == null ? "" : error)
                + ");";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void showToast(String message) {
        webView.post(() ->
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        );
    }

    private static String sanitizeFilename(String filename) {
        final String fallback = "accutek-inventory-export.txt";
        if (filename == null || filename.isBlank()) {
            return fallback;
        }
        final String sanitized = filename.replaceAll(
                "[^A-Za-z0-9._-]",
                "_"
        );
        return sanitized.isBlank() ? fallback : sanitized;
    }

    private static String safeFolder(String value, String fallback) {
        final String cleaned = value == null
                ? ""
                : value.trim().replaceAll("[^A-Za-z0-9._ -]", "_");
        final String compact = cleaned.replaceAll("\\s+", " ").trim();
        if (compact.isBlank()) {
            return fallback;
        }
        return compact.length() > 80
                ? compact.substring(0, 80)
                : compact;
    }

    private static String safeMessage(Exception error) {
        return error.getMessage() == null
                ? "unknown error"
                : error.getMessage();
    }
}
