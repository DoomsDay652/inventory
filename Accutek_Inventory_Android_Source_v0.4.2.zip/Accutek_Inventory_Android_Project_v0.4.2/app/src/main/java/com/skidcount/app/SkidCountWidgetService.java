package com.skidcount.app;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import android.widget.RemoteViewsService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class SkidCountWidgetService extends RemoteViewsService {
    @Override
    public RemoteViewsFactory onGetViewFactory(Intent intent) {
        return new PartFactory(getApplicationContext(), intent);
    }

    private static final class PartFactory implements RemoteViewsFactory {
        private final Context context;
        @SuppressWarnings("unused")
        private final int appWidgetId;
        private final List<WidgetPart> parts = new ArrayList<>();

        PartFactory(Context context, Intent intent) {
            this.context = context;
            this.appWidgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        }

        @Override public void onCreate() { }

        @Override
        public void onDataSetChanged() {
            parts.clear();
            final String raw = StateStore.getStateJson(context);
            if (raw == null || raw.isBlank()) {
                return;
            }
            try {
                final JSONObject state = new JSONObject(raw);
                final JSONArray jsonParts = state.optJSONArray("parts");
                if (jsonParts == null) {
                    return;
                }
                for (int i = 0; i < jsonParts.length(); i++) {
                    final JSONObject part = jsonParts.optJSONObject(i);
                    if (part == null) {
                        continue;
                    }
                    parts.add(new WidgetPart(
                            part.optString("id"),
                            part.optString("name", "Unnamed Part"),
                            part.optDouble("unopenedBoxes", 0),
                            part.optDouble("tableQty", 0)
                    ));
                }
                parts.sort(Comparator.comparing(WidgetPart::name, String.CASE_INSENSITIVE_ORDER));
            } catch (Exception ignored) {
            }
        }

        @Override public void onDestroy() { parts.clear(); }
        @Override public int getCount() { return parts.size(); }

        @Override
        public RemoteViews getViewAt(int position) {
            if (position < 0 || position >= parts.size()) {
                return null;
            }
            final WidgetPart part = parts.get(position);
            final RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_part_item);
            views.setTextViewText(R.id.widget_part_name, part.name());
            views.setTextViewText(
                    R.id.widget_part_counts,
                    "Unopened: " + format(part.unopenedBoxes()) + " boxes  •  Table: " + format(part.tableQty())
            );

            final Intent fillInIntent = new Intent()
                    .putExtra(SkidCountWidget.EXTRA_PART_ID, part.id());
            views.setOnClickFillInIntent(R.id.widget_open_box, fillInIntent);
            return views;
        }

        @Override public RemoteViews getLoadingView() { return null; }
        @Override public int getViewTypeCount() { return 1; }
        @Override public long getItemId(int position) { return parts.get(position).id().hashCode(); }
        @Override public boolean hasStableIds() { return true; }

        private static String format(double value) {
            if (Math.rint(value) == value) {
                return Long.toString((long) value);
            }
            return Double.toString(value);
        }
    }

    private record WidgetPart(String id, String name, double unopenedBoxes, double tableQty) { }
}
