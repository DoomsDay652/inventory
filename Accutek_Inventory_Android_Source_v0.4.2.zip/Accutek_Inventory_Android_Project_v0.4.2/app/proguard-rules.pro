-keepclassmembers class com.skidcount.app.NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
