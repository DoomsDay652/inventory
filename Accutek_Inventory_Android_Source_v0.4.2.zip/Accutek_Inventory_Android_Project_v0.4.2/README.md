# Accutek Inventory Android v0.4.2

Accutek Inventory is a native Android inventory and work-documentation app for skid, box, loose-part, assembly, and process-photo tracking.

## New in v0.3.0

- Added a dedicated **Photos** tab.
- Create photo sets by part and optional job/run number.
- Default workflow expects five process photos:
  1. Received
  2. Before process
  3. In process
  4. Completed
  5. Final / shipping
- Photos are grouped in collapsible folders by part and local date.
- Each photo stores its stage, note, date, and exact time.
- Camera captures are placed in app-private storage instead of the personal Camera/DCIM roll.
- Added **Email Set** with all photos attached through the user's email app.
- Added **Export Set** and **Export All** to copy images into:
  `Downloads/Accutek Inventory/Work Photos`
- Added Settings fields for the company email, expected photos per set, and email subject prefix.
- Label and skid camera captures also use a private temporary camera area, so new app captures do not clutter the personal gallery.
- Keeps the Android status-bar and bottom-navigation safe-area fix.
- Visible version: `0.3.0`
- Android `versionCode`: `5`

## Existing inventory features

- Parts with pieces per box, boxes per full skid, low-stock amount, and label photo.
- Full, partial, mixed, and custom skid receipts.
- Quick `+ 1 Skid` and `− 1 Skid` controls on each part.
- Open Box, Use, Adjust, and Edit controls.
- Organized History filters and collapsible folders by part and local date.
- Assembly recipes with hardware required per finished unit.
- Offline Google ML Kit label OCR.
- Home-screen part widget.
- CSV export and JSON backup.
- Stable application ID `com.skidcount.app`.

## Work-photo storage

Native full-size work photos are stored inside the app's private external-files area. They do not appear in the normal Camera/DCIM roll.

Important:

- Installing an update over the existing app preserves these private photos.
- Uninstalling the app removes them.
- Before uninstalling, use **Email Set**, **Export Set**, or **Export All**.
- JSON backup preserves photo records and settings, but full-size native image files should also be exported or emailed.

The browser test can preview the photo-set workflow, but it cannot attach photos to email or guarantee private Android storage.

## Update safety

1. Open the installed app.
2. Go to **Settings → Download Backup**.
3. Keep the JSON backup.
4. Upload and build v0.3.0.
5. Install v0.3.0 directly over the existing APK.
6. Do not uninstall the old app first.

The application ID and included signing key are unchanged, so this build is intended to update the existing installation without erasing inventory.

## GitHub Actions build

Upload:

`Accutek_Inventory_Android_Source_v0.3.0.zip`

Then replace:

`.github/workflows/build-apk.yml`

with the included:

`build-accutek-inventory-v0.3.0.yml`

The completed artifact is:

`Accutek-Inventory-APK-v0.3.0`

The APK inside it is:

`Accutek-Inventory-v0.3.0-release.apk`

## Android Studio build

1. Open `Accutek_Inventory_Android_Project_v0.3.0`.
2. Install Android SDK Platform 35 when prompted.
3. Sync Gradle.
4. Select the `release` build variant.
5. Choose **Build → Build APK(s)**.

Output:

`app/build/outputs/apk/release/app-release.apk`

## Keep the repository private

The project contains `skidcount-release.jks` and `keystore.properties`. Keep the repository private and back up both files. The same signing identity is required for future updates.


## v0.4.1 inventory hierarchy

- Parent folders keep the Inventory page compact.
- Open a folder and tap **+ Hardware** to add child items.
- Older ungrouped items migrate into **Unfiled Hardware** and can be moved by editing them.
- Every hardware card has separate **−/+ 1 Box** and **−/+ 1 Skid** controls.
- **Open Box** still moves one unopened box onto the assembly table; it is intentionally separate from quick box removal.
- v0.4.1 supersedes v0.3.0, so v0.3.0 does not need to be installed first.


## v0.4.1 scoped inventory summary

- Adds a **Totals shown for** selector above the Inventory summary.
- Choose All Inventory, a parent part folder, or one individual hardware item.
- Summary cards show scoped hardware count, unopened boxes, table pieces, and total estimated pieces.
- The selected summary view is saved on the device and restored when the app reopens.


## v0.4.2 build fix

- Fixes GitHub Actions failure at `:app:checkReleaseDuplicateClasses`.
- Aligns `kotlin-stdlib`, `kotlin-stdlib-jdk7`, and `kotlin-stdlib-jdk8` on version `1.8.22`.
- Prevents old Kotlin `1.6.21` classes from being packaged beside Kotlin `1.8.22`.
- No inventory workflow or stored-data format was changed.
- Android `versionCode`: `8`.
