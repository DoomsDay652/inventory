package com.bionest.prototype

import android.app.AlertDialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.text.InputType
import android.widget.EditText
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class GameView(context: Context) : View(context) {

    private enum class AppScreen { MAIN_MENU, WORLD_SETUP, BIOBOOK, SETTINGS, PLAYING }
    private enum class BioBookSection(val label: String) {
        UNITS("UNITS"),
        STRUCTURES("STRUCTURES"),
        FAUNA("FAUNA"),
        FLORA("FLORA"),
        INHABITANTS("INHABITANTS"),
    }
    private enum class MapSize(val label: String, val radius: Int, val note: String) {
        SMALL("SMALL", 3, "37 HEXES"),
        MEDIUM("MEDIUM", 5, "91 HEXES"),
        LARGE("LARGE", 7, "169 HEXES"),
    }
    private enum class BiomeType { VERDANT_FOREST, MISTY_WETLAND, CRYSTAL_BARRENS, HIGHLANDS, CANYON, RUINS }
    private enum class LandmarkType { RUIN, MOUNTAIN, CANYON, GROVE }

    private enum class ResourceType { MINERAL, GAS }
    private enum class ResourceFieldProfile { BALANCED, MINERAL_RICH, GAS_RICH, ABUNDANT }
    private enum class BuildingType { BIOSPEWER, NEST_WATCHER }
    private enum class ObstacleType { TREE, ROCK, BUSH }
    private enum class WaterType { LAKE, RIVER, OCEAN }
    private enum class AlienAnimalType { GRAZER, HOPPER, STRIDER }
    private enum class SpreaderState { IDLE, RELOCATING, MOVING_TO_BURROW, BURROWING, BURROWED }
    private enum class UnitKind { DRONE, WATCHER, GUARD, HATCHLING, SPREADER }
    private enum class CommandMode { NONE, GUARD_TARGET, BURROW_TARGET }
    private enum class EnemyState { WANDERING, CHASING, RETURNING }
    private enum class ColonyTargetKind { DRONE, WATCHER, GUARD, HATCHLING, SPREADER }

    /**
     * Shared world-scale standard.
     *
     * One BioCell is the authoring unit for movement, footprints, interaction
     * ranges, and sprite presentation. The visual sprite size is intentionally
     * separate from the gameplay footprint so large organic silhouettes do not
     * create oversized collision or placement blockers.
     */
    private object GameScale {
        const val CELL = 32f
        const val HEX_RADIUS = CELL * 96f

        const val START_ZOOM = 0.48f
        const val MIN_ZOOM = 0.04f
        const val MAX_ZOOM = 1.90f

        const val DRONE_VISUAL = CELL * 2f
        const val SMALL_UNIT_VISUAL = CELL * 2f
        const val GUARD_VISUAL = CELL * 2.5f
        const val SPREADER_VISUAL = CELL * 2.4f

        const val RESOURCE_VISUAL = CELL * 3.5f
        const val RESOURCE_RADIUS = CELL * 1.5f
        const val RICH_RESOURCE_RADIUS = CELL * 2f

        const val NEST_STAGE_1_VISUAL = CELL * 6f
        const val NEST_STAGE_2_VISUAL = CELL * 8f
        const val NEST_STAGE_3_VISUAL = CELL * 10f
        const val NEST_FOOTPRINT_RADIUS = CELL * 2.5f
        const val NEST_SELECTION_RADIUS = CELL * 3.2f

        const val BIOSPEWER_WIDTH = CELL * 5f
        const val BIOSPEWER_HEIGHT = CELL * 6f
        const val BIOSPEWER_FOOTPRINT_RADIUS = CELL * 2f

        const val WATCHER_WIDTH = CELL * 4f
        const val WATCHER_HEIGHT = CELL * 5f
        const val WATCHER_FOOTPRINT_RADIUS = CELL * 1.5f

        const val BUILD_SPACING = CELL
        const val ENEMY_CAMP_RADIUS = CELL * 3.5f
        const val ENEMY_CAMP_VISUAL = CELL * 7f

        const val DRONE_SPEED = CELL * 3f
        const val DRONE_SPEED_UPGRADE = CELL * 0.5f
        const val WATCHER_TRAVEL_SPEED = CELL * 4.5f
        const val GUARD_TRAVEL_SPEED = CELL * 4f
        const val HATCHLING_SPEED = CELL * 5f
        const val SPREADER_SPEED = CELL * 3.5f
        const val ENEMY_CHASE_SPEED = CELL * 2.1f
        const val ENEMY_RETURN_SPEED = CELL * 1.8f
        const val ENEMY_WANDER_SPEED = CELL * 1.2f
    }

    private enum class DroneState {
        IDLE,
        MOVING,
        HARVESTING,
        RETURNING,
        MOVING_TO_BUILD,
        BUILDING,
    }

    private data class HexTile(
        val q: Int,
        val r: Int,
        var unlocked: Boolean,
        val seed: Int,
    )

    private data class Obstacle(
        val id: Int,
        val tileKey: String,
        val type: ObstacleType,
        val x: Float,
        val y: Float,
        val radius: Float,
    )

    private data class Nest(
        var x: Float,
        var y: Float,
        var health: Int = 100,
        var maxHealth: Int = 100,
        var level: Int = 1,
    )

    private data class Larva(
        var x: Float,
        var y: Float,
        var ageSeconds: Float = 0f,
    )

    private data class ResourceNode(
        val id: Int,
        val tileKey: String,
        var x: Float,
        var y: Float,
        val type: ResourceType,
        val richnessTier: Int,
        var amount: Float,
        val maxAmount: Float,
        val clustered: Boolean = false,
    )

    private data class Drone(
        val id: Int,
        var x: Float,
        var y: Float,
        var targetX: Float = x,
        var targetY: Float = y,
        var facingDir: Int = 2,
        var state: DroneState = DroneState.IDLE,
        var selected: Boolean = false,
        var carryingType: ResourceType? = null,
        var carryingAmount: Float = 0f,
        var targetResourceId: Int? = null,
        var preferredResourceType: ResourceType? = null,
        var buildSiteId: Int? = null,
        var health: Int = 30,
        var maxHealth: Int = 30,
    )

    private data class BuildSite(
        val id: Int,
        val type: BuildingType,
        val builderDroneIds: MutableList<Int>,
        var x: Float,
        var y: Float,
        var progress: Float = 0f,
    )

    private data class Biospewer(
        val id: Int,
        var x: Float,
        var y: Float,
        var health: Int = 140,
        var maxHealth: Int = 140,
        var productionTimer: Float = 0f,
        var hatchlingProductionTimer: Float = 0f,
    )

    private data class NestWatcher(
        val id: Int,
        var x: Float,
        var y: Float,
        var level: Int = 1,
        var health: Int = 100,
        var maxHealth: Int = 100,
        var unitProductionTimer: Float = 0f,
    )

    private data class WatcherUnit(
        val id: Int,
        val homeWatcherId: Int,
        var x: Float,
        var y: Float,
        var patrolX: Float = x,
        var patrolY: Float = y,
        var targetX: Float = patrolX,
        var targetY: Float = patrolY,
        var facingDir: Int = 2,
        var hasMoveOrder: Boolean = false,
        var selected: Boolean = false,
        var health: Int = 45,
        var maxHealth: Int = 45,
        var attackCooldown: Float = 0f,
    )

    private data class Defender(
        val id: Int,
        val homeBiospewerId: Int,
        var x: Float,
        var y: Float,
        var guardX: Float = x,
        var guardY: Float = y,
        var guardTargetX: Float = guardX,
        var guardTargetY: Float = guardY,
        var facingDir: Int = 2,
        var hasMoveOrder: Boolean = false,
        var selected: Boolean = false,
        var health: Int = 70,
        var maxHealth: Int = 70,
        var attackCooldown: Float = 0f,
    )

    private data class Hatchling(
        val id: Int,
        val homeBiospewerId: Int,
        var x: Float,
        var y: Float,
        var targetX: Float = x,
        var targetY: Float = y,
        var facingDir: Int = 2,
        var hasMoveOrder: Boolean = false,
        var selected: Boolean = false,
        var health: Int = 20,
        var maxHealth: Int = 20,
        var attackCooldown: Float = 0f,
    )

    private data class Spreader(
        val id: Int,
        var x: Float,
        var y: Float,
        var targetX: Float = x,
        var targetY: Float = y,
        var facingDir: Int = 2,
        var state: SpreaderState = SpreaderState.IDLE,
        var selected: Boolean = false,
        var burrowTimer: Float = 0f,
        var spreadPulseTimer: Float = 0f,
        var health: Int = 35,
        var maxHealth: Int = 35,
    )

    private data class GooPatch(
        val id: Int,
        val x: Float,
        val y: Float,
        var radius: Float,
        var maxRadius: Float,
        val growthRate: Float,
    )

    private data class WaterFeature(
        val id: Int,
        val tileKey: String,
        val type: WaterType,
        val x1: Float,
        val y1: Float,
        val x2: Float,
        val y2: Float,
        val radius: Float,
    )

    private data class Landmark(
        val id: Int,
        val tileKey: String,
        val type: LandmarkType,
        val x: Float,
        val y: Float,
        val radius: Float,
    )

    private data class WildAnimal(
        val id: Int,
        val tileKey: String,
        val type: AlienAnimalType,
        var x: Float,
        var y: Float,
        var targetX: Float,
        var targetY: Float,
        val speed: Float,
        var wanderTimer: Float,
        val phase: Float,
    )

    private data class EnemyCamp(
        val id: Int,
        val tileKey: String,
        val x: Float,
        val y: Float,
        val populationTarget: Int,
        var health: Int,
        val maxHealth: Int,
        val goldReward: Int,
        var respawnTimer: Float = 0f,
    )

    private data class PrimitiveEnemy(
        val id: Int,
        val campId: Int,
        var x: Float,
        var y: Float,
        var targetX: Float,
        var targetY: Float,
        var facingDir: Int = 2,
        var state: EnemyState = EnemyState.WANDERING,
        var wanderTimer: Float = 0f,
        var targetKind: ColonyTargetKind? = null,
        var targetId: Int? = null,
        var attackCooldown: Float = 0f,
        var health: Int = 46,
        var maxHealth: Int = 46,
        val phase: Float,
    )

    private data class ColonyTarget(
        val kind: ColonyTargetKind,
        val id: Int,
        val x: Float,
        val y: Float,
    )

    private data class SlotData(
        val label: String,
        val value: String,
        val accent: Int,
        val active: Boolean,
    )

    private data class UnitTypeSummary(
        val kind: UnitKind,
        val label: String,
        val count: Int,
        val accent: Int,
    )

    private data class RenderEntry(
        val sortY: Float,
        val orderBias: Float = 0f,
        val draw: () -> Unit,
    )

    private data class MoveResult(
        val x: Float,
        val y: Float,
        val reached: Boolean,
    )

    private data class WorldSetupRects(
        val nameField: RectF,
        val sizeButtons: List<RectF>,
        val seedField: RectF,
        val randomButton: RectF,
        val createButton: RectF,
        val backButton: RectF,
    )

    private data class BioBookEntry(
        val title: String,
        val subtitle: String,
        val art: android.graphics.Bitmap,
        val artMode: Int = 0,
    )

    private val paint = Paint().apply {
        isAntiAlias = false
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        strokeWidth = 2f
    }
    private val path = Path()
    private val random = Random(System.currentTimeMillis().toInt())

    private val tiles = linkedMapOf<String, HexTile>()
    private val obstacles = mutableListOf<Obstacle>()
    private val drones = mutableListOf<Drone>()
    private val larvae = mutableListOf<Larva>()
    private val resourceNodes = mutableListOf<ResourceNode>()
    private val resourceRespawnTimers = mutableMapOf<String, Float>()
    private val resourceCycleByTile = mutableMapOf<String, Int>()
    private val buildSites = mutableListOf<BuildSite>()
    private val biospewers = mutableListOf<Biospewer>()
    private val nestWatchers = mutableListOf<NestWatcher>()
    private val watcherUnits = mutableListOf<WatcherUnit>()
    private val defenders = mutableListOf<Defender>()
    private val hatchlings = mutableListOf<Hatchling>()
    private val spreaders = mutableListOf<Spreader>()
    private val gooPatches = mutableListOf<GooPatch>()
    private val waterFeatures = mutableListOf<WaterFeature>()
    private val landmarks = mutableListOf<Landmark>()
    private val wildAnimals = mutableListOf<WildAnimal>()
    private val enemyCamps = mutableListOf<EnemyCamp>()
    private val primitiveEnemies = mutableListOf<PrimitiveEnemy>()

    private var appScreen = AppScreen.MAIN_MENU
    private var bioBookSection = BioBookSection.UNITS
    private var nest: Nest? = null
    private var placementMode = true
    private var nestMenuOpen = false
    private var selectedWatcherId: Int? = null
    private var selectedBarrierKey: String? = null
    private var sidebarExpanded = true
    private var buildMenuOpen = false
    private var shopMenuOpen = false
    private var buildPlacementType: BuildingType? = null
    private var ghostBuildX: Float? = null
    private var ghostBuildY: Float? = null
    private var commandMode = CommandMode.NONE
    private var followUnitKind: UnitKind? = null
    private var followUnitId: Int? = null
    private var inspectTitle = ""
    private var inspectBody = ""

    private var minerals = 0
    private var gas = 0
    private var shopGold = 0
    private var worldSeed = Random(System.currentTimeMillis().toInt()).nextInt(100000, 999999999)
    private var worldName = "New Colony"
    private var setupWorldName = "New Colony"
    private var setupSeedText = worldSeed.toString()
    private var selectedMapSize = MapSize.MEDIUM
    private var speedLevel = 0
    private var harvestLevel = 0
    private var nestHealthLevel = 0

    private var nextResourceId = 1
    private var nextDroneId = 1
    private var nextBuildingId = 1
    private var nextDefenderId = 1
    private var nextWatcherUnitId = 1
    private var nextHatchlingId = 1
    private var nextSpreaderId = 1
    private var nextGooPatchId = 1
    private var nextWaterId = 1
    private var nextLandmarkId = 1
    private var nextWildAnimalId = 1
    private var nextObstacleId = 1
    private var nextEnemyCampId = 1
    private var nextPrimitiveEnemyId = 1
    private var nestProductionTimer = 0f
    private var worldElapsedSeconds = 0f
    private var obstacleResolveAccumulator = 0f
    private var gooMaintenanceAccumulator = 0f
    private val dayLengthSeconds = 240f
    private val startingDayPhase = 0.42f
    private var message = "Tap the sunny forest clearing to place your Bionest"
    private var messageTimer = 99f

    private var cameraX = 0f
    private var cameraY = 0f
    private var zoom = GameScale.START_ZOOM
    private val minZoom = GameScale.MIN_ZOOM
    private val maxZoom = GameScale.MAX_ZOOM

    private var touchDown = false
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var touchCurrentX = 0f
    private var touchCurrentY = 0f
    private var previousTouchX = 0f
    private var previousTouchY = 0f
    private var touchDownTimeMs = 0L
    private var touchStartedInPlayfield = false
    private var selectionRingActive = false
    private var selectionRingRadius = 0f
    private var panning = false
    private var pinching = false
    private var pinchStartDistance = 0f
    private var pinchStartZoom = 1f
    private var pinchAnchorWorldX = 0f
    private var pinchAnchorWorldY = 0f

    private val density = resources.displayMetrics.density.coerceAtLeast(1f)
    private val longPressMs = 260L
    private val resourceSetRespawnDelay = 7.5f
    private val hexRadius = GameScale.HEX_RADIUS
    private val sqrt3 = sqrt(3f)

    private val biospewerDroneCost = 2
    private val biospewerMineralCost = 30
    private val biospewerGasCost = 20
    private val watcherDroneCost = 1
    private val watcherMineralCost = 22
    private val watcherGasCost = 12
    private val spreaderMineralCost = 18
    private val spreaderGasCost = 14
    private val maxSpreadersWaiting = 5
    private val enemyCampLeashRadius = GameScale.CELL * 10f
    private val enemyAggroRadius = GameScale.CELL * 5.5f
    private val enemyWanderRadius = GameScale.CELL * 5.5f
    private val campGoldBaseReward = 20
    private val prototypeVersionLabel = "v0.28.1"

    private fun decodeBitmap(resId: Int): Bitmap = BitmapFactory.decodeResource(resources, resId)
    private fun decodeBitmapSet(vararg resIds: Int): List<Bitmap> = resIds.map(::decodeBitmap)
    private fun pickVariant(bitmaps: List<Bitmap>, seed: Int): Bitmap = bitmaps[(if (seed < 0) -seed else seed) % bitmaps.size]

    private val workerDroneSheet by lazy {
        BitmapFactory.decodeResource(resources, R.drawable.worker_drone_full_sheet)
    }
    private val spitterSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.spitter_sheet) }
    private val hatchlingSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.hatchling_sheet) }
    private val spreaderIdleSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.spreader_idle_sheet) }
    private val spreaderMoveSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.spreader_move_sheet) }
    private val spreaderBurrowSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.spreader_burrow_sheet) }
    private val spreaderRootedIdleSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.spreader_rooted_idle_sheet) }
    private val spreaderPulseSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.spreader_pulse_sheet) }
    private val watcherSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.watcher_sheet) }
    private val primitiveEnemySheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.primitive_enemy_sheet) }
    private val nestStage1Sprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.nest_stage_1) }
    private val nestStage2Sprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.nest_stage_2) }
    private val nestStage3Sprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.nest_stage_3) }
    private val nestIdleSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.nest_idle_sheet) }
    private val biospewerIdleSheet by lazy { BitmapFactory.decodeResource(resources, R.drawable.biospewer_idle_sheet) }
    private val nestWatcherSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.nest_watcher) }
    private val enemyCampSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.enemy_camp) }
    private val mineralFieldSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.mineral_field) }
    private val gasFieldSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.gas_field) }
    private val sacredGroveSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.sacred_grove) }
    private val ruinsSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.ruins) }
    private val mountainSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.mountain) }
    private val canyonSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.canyon) }
    private val uiTitleSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_title) }
    private val uiPlayIdleSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_play_idle) }
    private val uiSettingsIdleSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_settings_idle) }
    private val uiExitIdleSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_exit_idle) }
    private val uiPanelLargeV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_panel_large_v2) }
    private val uiDayStripV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_day_strip_v2) }
    private val uiPortraitFrameV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_portrait_frame_v2) }
    private val uiZoomPlusV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_zoom_plus_v2) }
    private val uiZoomMinusV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_zoom_minus_v2) }
    private val uiToggleLeftV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_toggle_left_v2) }
    private val uiToggleRightV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_toggle_right_v2) }
    private val uiIconMineralsV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_icon_minerals_v2) }
    private val uiIconGasV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_icon_gas_v2) }
    private val uiIconGoldV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_icon_gold_v2) }
    private val uiIconBuildV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_icon_build_v2) }
    private val uiIconShopV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_icon_shop_v2) }
    private val uiIconSettingsV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_icon_settings_v2) }
    private val uiBtnBackV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_btn_back_v2) }
    private val uiBtnConfirmV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_btn_confirm_v2) }
    private val uiBtnCancelV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_btn_cancel_v2) }
    private val uiBtnStopV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_btn_stop_v2) }
    private val uiBtnSpreadV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_btn_spread_v2) }
    private val uiBtnGuardV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_btn_guard_v2) }
    private val uiBtnFollowV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_btn_follow_v2) }
    private val uiBtnBurrowV2 by lazy { BitmapFactory.decodeResource(resources, R.drawable.ui_btn_burrow_v2) }
    private val terrainTreeForestVariants by lazy { decodeBitmapSet(
        R.drawable.terrain_tree_forest_variant_01,
        R.drawable.terrain_tree_forest_variant_02,
        R.drawable.terrain_tree_forest_variant_03,
        R.drawable.terrain_tree_forest_variant_04,
        R.drawable.terrain_tree_forest_variant_05,
        R.drawable.terrain_tree_forest_variant_06,
        R.drawable.terrain_tree_forest_variant_07,
        R.drawable.terrain_tree_forest_variant_08,
        R.drawable.terrain_tree_forest_variant_09,
        R.drawable.terrain_tree_forest_variant_10,
        R.drawable.terrain_tree_forest_variant_11,
        R.drawable.terrain_tree_forest_variant_12,
    ) }
    private val terrainTreeWetlandVariants by lazy { decodeBitmapSet(
        R.drawable.terrain_tree_wetland_01,
        R.drawable.terrain_tree_wetland_02,
        R.drawable.terrain_tree_wetland_03,
        R.drawable.terrain_tree_wetland_04,
        R.drawable.terrain_tree_wetland_05,
        R.drawable.terrain_tree_wetland_06,
        R.drawable.terrain_tree_wetland_07,
        R.drawable.terrain_tree_wetland_08,
        R.drawable.terrain_tree_wetland_09,
        R.drawable.terrain_tree_wetland_10,
        R.drawable.terrain_tree_wetland_11,
        R.drawable.terrain_tree_wetland_12,
    ) }
    private val terrainTreeSavannaVariants by lazy { decodeBitmapSet(
        R.drawable.terrain_tree_savanna_01,
        R.drawable.terrain_tree_savanna_02,
        R.drawable.terrain_tree_savanna_03,
        R.drawable.terrain_tree_savanna_04,
        R.drawable.terrain_tree_savanna_05,
        R.drawable.terrain_tree_savanna_06,
        R.drawable.terrain_tree_savanna_07,
        R.drawable.terrain_tree_savanna_08,
        R.drawable.terrain_tree_savanna_09,
        R.drawable.terrain_tree_savanna_10,
        R.drawable.terrain_tree_savanna_11,
        R.drawable.terrain_tree_savanna_12,
    ) }
    private val terrainTreeJungleVariants by lazy { decodeBitmapSet(
        R.drawable.terrain_tree_jungle_01,
        R.drawable.terrain_tree_jungle_02,
        R.drawable.terrain_tree_jungle_03,
        R.drawable.terrain_tree_jungle_04,
        R.drawable.terrain_tree_jungle_05,
        R.drawable.terrain_tree_jungle_06,
        R.drawable.terrain_tree_jungle_07,
        R.drawable.terrain_tree_jungle_08,
        R.drawable.terrain_tree_jungle_09,
        R.drawable.terrain_tree_jungle_10,
        R.drawable.terrain_tree_jungle_11,
        R.drawable.terrain_tree_jungle_12,
    ) }
    private val terrainTreePineVariants by lazy { decodeBitmapSet(
        R.drawable.terrain_tree_pine_01,
        R.drawable.terrain_tree_pine_02,
        R.drawable.terrain_tree_pine_03,
        R.drawable.terrain_tree_pine_04,
        R.drawable.terrain_tree_pine_05,
        R.drawable.terrain_tree_pine_06,
        R.drawable.terrain_tree_pine_07,
        R.drawable.terrain_tree_pine_08,
        R.drawable.terrain_tree_pine_09,
        R.drawable.terrain_tree_pine_10,
        R.drawable.terrain_tree_pine_11,
        R.drawable.terrain_tree_pine_12,
    ) }
    private val terrainBush by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_bush) }
    private val terrainRock by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_rock) }
    private val terrainCrystalCluster by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_crystal_cluster) }
    private val terrainLake by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_lake) }
    private val terrainTileForest by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_tile_forest) }
    private val terrainTileWetland by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_tile_wetland) }
    private val terrainTileCrystal by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_tile_crystal) }
    private val terrainTileHighlands by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_tile_highlands) }
    private val terrainTileCanyon by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_tile_canyon) }
    private val terrainTileRuins by lazy { BitmapFactory.decodeResource(resources, R.drawable.terrain_tile_ruins) }
    private val terrainShaderForest by lazy { BitmapShader(terrainTileForest, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    private val terrainShaderWetland by lazy { BitmapShader(terrainTileWetland, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    private val terrainShaderCrystal by lazy { BitmapShader(terrainTileCrystal, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    private val terrainShaderHighlands by lazy { BitmapShader(terrainTileHighlands, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    private val terrainShaderCanyon by lazy { BitmapShader(terrainTileCanyon, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    private val terrainShaderRuins by lazy { BitmapShader(terrainTileRuins, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT) }
    private val terrainShaderMatrix = Matrix()
    private val wildGrazerSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.wild_grazer) }
    private val wildHopperSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.wild_hopper) }
    private val wildStriderSprite by lazy { BitmapFactory.decodeResource(resources, R.drawable.wild_strider) }

    private val isPortrait: Boolean
        get() = height > width

    private val expandedSidebarWidth: Float
        get() = min(108f * density, width * if (isPortrait) 0.30f else 0.21f)
            .coerceAtLeast(82f * density)

    private val collapsedSidebarWidth: Float
        get() = 36f * density

    private val sidebarWidth: Float
        get() = if (sidebarExpanded) expandedSidebarWidth else collapsedSidebarWidth

    private val bottomMenuHeight: Float
        get() {
            val desired = if (isPortrait) 214f * density else 130f * density
            return min(desired, height * if (isPortrait) 0.46f else 0.42f)
        }

    private val hasBottomMenu: Boolean
        get() = nestMenuOpen || selectedWatcherId != null || selectedBarrierKey != null ||
            buildMenuOpen || shopMenuOpen || anyUnitsSelected() || buildPlacementType != null

    init {
        setBackgroundColor(Color.rgb(145, 205, 112))
        isFocusable = true
        keepScreenOn = true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastFrameNanos = System.nanoTime()
        postInvalidateOnAnimation()
    }

    private var lastFrameNanos = 0L

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        val dt = if (lastFrameNanos == 0L) 0f else
            ((now - lastFrameNanos) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastFrameNanos = now

        update(dt)
        if (appScreen == AppScreen.PLAYING) {
            drawWorld(canvas)
        } else {
            canvas.drawColor(Color.rgb(6, 7, 10))
        }
        drawUi(canvas)
        postInvalidateOnAnimation()
    }

    private fun initializeWorld() {
        tiles.clear()
        addTile(0, 0, unlocked = true)
        generateTerrainForTile(tileKey(0, 0))
        generateFogFrontier(0, 0, radius = selectedMapSize.radius)
    }

    private fun startNewWorld(
        seed: Int,
        name: String = setupWorldName,
        size: MapSize = selectedMapSize,
        enterPlay: Boolean = true,
    ) {
        worldSeed = seed
        worldName = name.trim().ifBlank { "New Colony" }.take(24)
        setupWorldName = worldName
        setupSeedText = worldSeed.toString()
        selectedMapSize = size
        resetSimulationState()
        initializeWorld()
        if (enterPlay) {
            appScreen = AppScreen.PLAYING
            showMessage("$worldName loaded. Place your Bionest.")
        }
    }

    private fun resetSimulationState() {
        tiles.clear()
        obstacles.clear()
        drones.clear()
        larvae.clear()
        resourceNodes.clear()
        resourceRespawnTimers.clear()
        resourceCycleByTile.clear()
        buildSites.clear()
        biospewers.clear()
        nestWatchers.clear()
        watcherUnits.clear()
        defenders.clear()
        hatchlings.clear()
        spreaders.clear()
        gooPatches.clear()
        waterFeatures.clear()
        landmarks.clear()
        wildAnimals.clear()
        enemyCamps.clear()
        primitiveEnemies.clear()

        nest = null
        placementMode = true
        nestMenuOpen = false
        selectedWatcherId = null
        selectedBarrierKey = null
        buildMenuOpen = false
        shopMenuOpen = false
        buildPlacementType = null
        ghostBuildX = null
        ghostBuildY = null
        commandMode = CommandMode.NONE
        followUnitKind = null
        followUnitId = null
        inspectTitle = ""
        inspectBody = ""
        sidebarExpanded = true

        minerals = 0
        gas = 0
        shopGold = 0
        speedLevel = 0
        harvestLevel = 0
        nestHealthLevel = 0
        nestProductionTimer = 0f
        worldElapsedSeconds = 0f
        obstacleResolveAccumulator = 0f
        gooMaintenanceAccumulator = 0f

        cameraX = 0f
        cameraY = 0f
        zoom = GameScale.START_ZOOM

        nextResourceId = 1
        nextDroneId = 1
        nextBuildingId = 1
        nextDefenderId = 1
        nextWatcherUnitId = 1
        nextHatchlingId = 1
        nextSpreaderId = 1
        nextGooPatchId = 1
        nextWaterId = 1
        nextLandmarkId = 1
        nextWildAnimalId = 1
        nextObstacleId = 1
        nextEnemyCampId = 1
        nextPrimitiveEnemyId = 1
        message = "Seed $worldSeed ready. Tap Play to begin."
        messageTimer = 3f
    }

    private fun update(dt: Float) {
        if (width <= 0 || height <= 0) return
        if (appScreen != AppScreen.PLAYING) {
            updateMessages(dt)
            return
        }
        worldElapsedSeconds += dt
        updateSelectionRing()
        updateMessages(dt)
        updateGoo(dt)
        updateResourceSpawning(dt)
        updateNestProduction(dt)
        updateLarvae(dt)
        updateDrones(dt)
        updateBiospewers(dt)
        updateNestWatchers(dt)
        updateWatcherUnits(dt)
        updateDefenders(dt)
        updateHatchlings(dt)
        updateSpreaders(dt)
        updateWildAnimals(dt)
        updateEnemyCamps(dt)
        updatePrimitiveEnemies(dt)
        obstacleResolveAccumulator += dt
        if (obstacleResolveAccumulator >= 0.20f) {
            obstacleResolveAccumulator = 0f
            resolveUnitObstacleOverlaps()
        }
        updateCameraFollow(dt)
        resourceNodes.removeAll { it.amount <= 0.05f }
    }

    private fun updateCameraFollow(dt: Float) {
        val target = currentFollowTarget() ?: return
        val blend = min(1f, dt * 3.2f)
        cameraX += (target.first - cameraX) * blend
        cameraY += (target.second - cameraY) * blend
        clampCameraToMap()
    }

    private fun updateSelectionRing() {
        if (!touchDown || !touchStartedInPlayfield || placementMode || buildPlacementType != null || panning || pinching) {
            selectionRingActive = false
            return
        }
        val heldMs = SystemClock.uptimeMillis() - touchDownTimeMs
        if (heldMs >= longPressMs) {
            selectionRingActive = true
            val heldSeconds = (heldMs - longPressMs) / 1000f
            val maxRadius = min(playfieldRect().width(), playfieldRect().height()) * 0.38f
            selectionRingRadius = min(maxRadius, 30f * density + heldSeconds * 100f * density)
        }
    }

    private fun updateMessages(dt: Float) {
        if (messageTimer < 99f) {
            messageTimer -= dt
            if (messageTimer <= 0f) message = ""
        }
    }

    private fun updateResourceSpawning(dt: Float) {
        if (nest == null) return
        tiles.values.filter { it.unlocked }.forEach { tile ->
            val key = tileKey(tile.q, tile.r)
            val hasActiveField = resourceNodes.any {
                it.tileKey == key && it.amount > 0.05f
            }

            if (hasActiveField) {
                resourceRespawnTimers.remove(key)
                return@forEach
            }

            val remaining = (resourceRespawnTimers[key] ?: resourceSetRespawnDelay) - dt
            if (remaining <= 0f) {
                spawnResourceSetForTile(tile)
                resourceRespawnTimers.remove(key)
            } else {
                resourceRespawnTimers[key] = remaining
            }
        }
    }

    private fun updateNestProduction(dt: Float) {
        val activeNest = nest ?: return
        if (drones.size + larvae.size >= droneCapacity()) return

        val gooBonus = if (isInGoo(activeNest.x, activeNest.y)) 1.25f else 1f
        nestProductionTimer += dt * gooBonus
        val productionDelay = if (drones.isEmpty() && larvae.isEmpty()) 0.75f else 5.2f
        if (nestProductionTimer >= productionDelay) {
            nestProductionTimer = 0f
            val angle = random.nextFloat() * 6.28318f
            val spawnRadius = GameScale.NEST_FOOTPRINT_RADIUS + GameScale.CELL
            larvae += Larva(
                x = activeNest.x + cos(angle) * spawnRadius,
                y = activeNest.y + sin(angle) * spawnRadius,
            )
            showMessage("Bionest produced a larva")
        }
    }

    private fun updateLarvae(dt: Float) {
        val iterator = larvae.iterator()
        while (iterator.hasNext()) {
            val larva = iterator.next()
            larva.ageSeconds += dt
            if (larva.ageSeconds >= 3.2f) {
                drones += Drone(nextDroneId++, larva.x, larva.y)
                iterator.remove()
                showMessage("A worker drone hatched")
            }
        }
    }

    private fun updateDrones(dt: Float) {
        val activeNest = nest
        val baseSpeedValue = GameScale.DRONE_SPEED + speedLevel * GameScale.DRONE_SPEED_UPGRADE
        val harvestRateValue = 4.7f + harvestLevel * 1.6f

        drones.toList().forEach { drone ->
            val gooMovementBonus = if (isInGoo(drone.x, drone.y)) 1.25f else 1f
            val gooHarvestBonus = if (isInGoo(drone.x, drone.y)) 1.30f else 1f
            val droneSpeed = baseSpeedValue * gooMovementBonus
            val droneHarvestRate = harvestRateValue * gooHarvestBonus
            when (drone.state) {
                DroneState.IDLE -> {
                    if (drone.preferredResourceType != null && drone.carryingAmount <= 0f) {
                        assignNextResourceOrIdle(drone)
                    }
                }

                DroneState.MOVING -> {
                    if (moveToward(drone, drone.targetX, drone.targetY, droneSpeed, dt)) {
                        drone.state = DroneState.IDLE
                    }
                }

                DroneState.HARVESTING -> {
                    val node = drone.targetResourceId?.let(::findResource)
                    if (node == null || node.amount <= 0.05f) {
                        drone.targetResourceId = null
                        if (drone.carryingAmount > 0f && activeNest != null) {
                            drone.state = DroneState.RETURNING
                            drone.targetX = activeNest.x
                            drone.targetY = activeNest.y
                        } else {
                            assignNextResourceOrIdle(drone)
                        }
                    } else {
                        val reached = moveToward(drone, node.x, node.y, droneSpeed, dt, stopDistance = resourcePatchRadius(node) * 0.72f)
                        if (reached) {
                            val take = min(node.amount, min(droneHarvestRate * dt, 10f - drone.carryingAmount))
                            node.amount -= take
                            drone.carryingType = node.type
                            drone.carryingAmount += take
                            if (drone.carryingAmount >= 9.95f || node.amount <= 0.05f) {
                                drone.targetResourceId = null
                                if (activeNest != null) {
                                    drone.state = DroneState.RETURNING
                                    drone.targetX = activeNest.x
                                    drone.targetY = activeNest.y
                                } else {
                                    drone.state = DroneState.IDLE
                                }
                            }
                        }
                    }
                }

                DroneState.RETURNING -> {
                    if (activeNest == null) {
                        drone.state = DroneState.IDLE
                    } else if (moveToward(drone, activeNest.x, activeNest.y, droneSpeed, dt, stopDistance = GameScale.NEST_FOOTPRINT_RADIUS + GameScale.CELL * 0.45f)) {
                        depositDroneCargo(drone)
                        assignNextResourceOrIdle(drone)
                    }
                }

                DroneState.MOVING_TO_BUILD -> {
                    val site = drone.buildSiteId?.let(::findBuildSite)
                    if (site == null) {
                        drone.buildSiteId = null
                        drone.state = DroneState.IDLE
                    } else if (moveToward(drone, site.x, site.y, droneSpeed * 0.9f, dt, stopDistance = GameScale.CELL)) {
                        drone.state = DroneState.BUILDING
                    }
                }

                DroneState.BUILDING -> {
                    val site = drone.buildSiteId?.let(::findBuildSite)
                    if (site == null) {
                        drone.buildSiteId = null
                        drone.state = DroneState.IDLE
                    }
                }
            }
        }

        buildSites.toList().forEach { site ->
            val builders = site.builderDroneIds.mapNotNull(::findDrone)
            if (builders.isEmpty()) {
                buildSites.remove(site)
                return@forEach
            }
            val allReady = builders.all { it.state == DroneState.BUILDING }
            if (allReady) {
                site.progress += dt / if (site.type == BuildingType.BIOSPEWER) 4.8f else 4.0f
                if (site.progress >= 1f) completeBuildSite(site.id)
            }
        }
    }

    private fun updateBiospewers(dt: Float) {
        biospewers.forEach { spewer ->
            val productionBonus = if (isInGoo(spewer.x, spewer.y)) 1.25f else 1f

            val currentGuards = defenders.count { it.homeBiospewerId == spewer.id }
            if (currentGuards < 5) {
                spewer.productionTimer += dt * productionBonus
                if (spewer.productionTimer >= 6.5f) {
                    spewer.productionTimer = 0f
                    val angle = random.nextFloat() * 6.28318f
                    val radius = GameScale.CELL * (3.0f + random.nextFloat() * 0.75f)
                    val spawnX = spewer.x + cos(angle) * radius
                    val spawnY = spewer.y + sin(angle) * radius
                    defenders += Defender(
                        id = nextDefenderId++,
                        homeBiospewerId = spewer.id,
                        x = spawnX,
                        y = spawnY,
                        guardX = spawnX,
                        guardY = spawnY,
                        guardTargetX = spawnX,
                        guardTargetY = spawnY,
                        facingDir = facingCardinal(cos(angle), sin(angle)),
                    )
                    showMessage("Biospewer released a guard")
                }
            }

            val currentHatchlings = hatchlings.count { it.homeBiospewerId == spewer.id }
            if (currentHatchlings < 12) {
                spewer.hatchlingProductionTimer += dt * productionBonus
                if (spewer.hatchlingProductionTimer >= 4f) {
                    spewer.hatchlingProductionTimer = 0f
                    val angle = random.nextFloat() * 6.28318f
                    val radius = GameScale.CELL * (2.8f + random.nextFloat() * 0.7f)
                    val spawnX = spewer.x + cos(angle) * radius
                    val spawnY = spewer.y + sin(angle) * radius
                    hatchlings += Hatchling(
                        id = nextHatchlingId++,
                        homeBiospewerId = spewer.id,
                        x = spawnX,
                        y = spawnY,
                        targetX = spawnX,
                        targetY = spawnY,
                        facingDir = facingCardinal(cos(angle), sin(angle)),
                    )
                    showMessage("Four-second hatchling spawned")
                }
            }
        }
    }

    private fun updateNestWatchers(dt: Float) {
        nestWatchers.forEach { watcher ->
            val desiredUnits = watcher.level + 1
            val currentUnits = watcherUnits.count { it.homeWatcherId == watcher.id }
            if (currentUnits >= desiredUnits) return@forEach
            val productionBonus = if (isInGoo(watcher.x, watcher.y)) 1.20f else 1f
            watcher.unitProductionTimer += dt * productionBonus
            if (watcher.unitProductionTimer >= 4.8f) {
                watcher.unitProductionTimer = 0f
                val angle = random.nextFloat() * 6.28318f
                val radius = GameScale.CELL * (2.8f + random.nextFloat() * 1.4f)
                val spawnX = watcher.x + cos(angle) * radius
                val spawnY = watcher.y + sin(angle) * radius
                watcherUnits += WatcherUnit(
                    id = nextWatcherUnitId++,
                    homeWatcherId = watcher.id,
                    x = spawnX,
                    y = spawnY,
                    patrolX = spawnX,
                    patrolY = spawnY,
                    targetX = spawnX,
                    targetY = spawnY,
                    facingDir = facingCardinal(cos(angle), sin(angle)),
                )
                showMessage("NestWatcher released a watch unit")
            }
        }
    }

    private fun updateWatcherUnits(dt: Float) {
        watcherUnits.toList().forEach { unit ->
            val home = nestWatchers.firstOrNull { it.id == unit.homeWatcherId }
            if (home == null) {
                watcherUnits.remove(unit)
                return@forEach
            }

            if (unit.hasMoveOrder) {
                val gooBonus = if (isInGoo(unit.x, unit.y)) 1.22f else 1f
                val oldX = unit.x
                val oldY = unit.y
                val move = movePointAvoidingObstacles(
                    unit.x,
                    unit.y,
                    unit.targetX,
                    unit.targetY,
                    GameScale.WATCHER_TRAVEL_SPEED * gooBonus,
                    dt,
                    GameScale.CELL * 0.35f,
                )
                unit.x = move.x
                unit.y = move.y
                unit.facingDir = facingAfterMove(unit.facingDir, unit.x - oldX, unit.y - oldY)
                unit.patrolX = unit.x
                unit.patrolY = unit.y
                if (move.reached) {
                    unit.targetX = unit.x
                    unit.targetY = unit.y
                    unit.hasMoveOrder = false
                }
            } else {
                unit.targetX = unit.x
                unit.targetY = unit.y
                unit.patrolX = unit.x
                unit.patrolY = unit.y
            }

            unit.attackCooldown = max(0f, unit.attackCooldown - dt)
            val enemy = nearestEnemy(unit.x, unit.y, GameScale.CELL * 1.35f)
            if (enemy != null) {
                unit.facingDir = facingAfterMove(unit.facingDir, enemy.x - unit.x, enemy.y - unit.y)
                if (unit.attackCooldown <= 0f) {
                    unit.attackCooldown = 1.2f
                    damageEnemy(enemy, 7)
                }
            } else if (unit.attackCooldown <= 0f) {
                val camp = nearestCamp(unit.x, unit.y, GameScale.CELL * 1.45f)
                if (camp != null) {
                    unit.attackCooldown = 1.2f
                    damageCamp(camp, 5)
                }
            }
        }
    }

    private fun updateDefenders(dt: Float) {
        defenders.toList().forEach { defender ->
            val home = biospewers.firstOrNull { it.id == defender.homeBiospewerId }
            if (home == null) {
                defenders.remove(defender)
                return@forEach
            }

            if (defender.hasMoveOrder) {
                val gooBonus = if (isInGoo(defender.x, defender.y)) 1.22f else 1f
                val oldX = defender.x
                val oldY = defender.y
                val move = movePointAvoidingObstacles(
                    defender.x,
                    defender.y,
                    defender.guardTargetX,
                    defender.guardTargetY,
                    GameScale.GUARD_TRAVEL_SPEED * gooBonus,
                    dt,
                    GameScale.CELL * 0.45f,
                )
                defender.x = move.x
                defender.y = move.y
                defender.facingDir = facingAfterMove(defender.facingDir, defender.x - oldX, defender.y - oldY)
                defender.guardX = defender.x
                defender.guardY = defender.y
                if (move.reached) {
                    defender.guardTargetX = defender.x
                    defender.guardTargetY = defender.y
                    defender.hasMoveOrder = false
                }
            } else {
                defender.guardTargetX = defender.x
                defender.guardTargetY = defender.y
                defender.guardX = defender.x
                defender.guardY = defender.y
            }

            defender.attackCooldown = max(0f, defender.attackCooldown - dt)
            val enemy = primitiveEnemies
                .filter { distance(it.x, it.y, defender.guardTargetX, defender.guardTargetY) <= GameScale.CELL * 5.5f }
                .minByOrNull { distance(defender.x, defender.y, it.x, it.y) }
            if (enemy != null && distance(defender.x, defender.y, enemy.x, enemy.y) <= GameScale.CELL * 1.1f) {
                defender.facingDir = facingAfterMove(defender.facingDir, enemy.x - defender.x, enemy.y - defender.y)
                if (defender.attackCooldown <= 0f) {
                    defender.attackCooldown = 0.75f
                    damageEnemy(enemy, 13)
                }
            } else if (enemy == null && defender.attackCooldown <= 0f) {
                val camp = nearestCamp(defender.x, defender.y, GameScale.CELL * 1.35f)
                if (camp != null) {
                    defender.attackCooldown = 0.75f
                    damageCamp(camp, 10)
                }
            }
        }
    }

    private fun updateHatchlings(dt: Float) {
        hatchlings.toList().forEach { hatchling ->
            val home = biospewers.firstOrNull { it.id == hatchling.homeBiospewerId }
            if (home == null) {
                hatchlings.remove(hatchling)
                return@forEach
            }

            if (hatchling.hasMoveOrder) {
                val gooBonus = if (isInGoo(hatchling.x, hatchling.y)) 1.30f else 1f
                val oldX = hatchling.x
                val oldY = hatchling.y
                val move = movePointAvoidingObstacles(
                    hatchling.x,
                    hatchling.y,
                    hatchling.targetX,
                    hatchling.targetY,
                    GameScale.HATCHLING_SPEED * gooBonus,
                    dt,
                    GameScale.CELL * 0.30f,
                )
                hatchling.x = move.x
                hatchling.y = move.y
                hatchling.facingDir = facingAfterMove(hatchling.facingDir, hatchling.x - oldX, hatchling.y - oldY)
                if (move.reached) {
                    hatchling.targetX = hatchling.x
                    hatchling.targetY = hatchling.y
                    hatchling.hasMoveOrder = false
                }
            } else {
                hatchling.targetX = hatchling.x
                hatchling.targetY = hatchling.y
            }

            hatchling.attackCooldown = max(0f, hatchling.attackCooldown - dt)
            val enemy = nearestEnemy(hatchling.x, hatchling.y, GameScale.CELL * 0.75f)
            if (enemy != null) {
                hatchling.facingDir = facingAfterMove(hatchling.facingDir, enemy.x - hatchling.x, enemy.y - hatchling.y)
                if (hatchling.attackCooldown <= 0f) {
                    hatchling.attackCooldown = 0.45f
                    damageEnemy(enemy, 4)
                }
            } else if (hatchling.attackCooldown <= 0f) {
                val camp = nearestCamp(hatchling.x, hatchling.y, GameScale.CELL * 1.3f)
                if (camp != null) {
                    hatchling.attackCooldown = 0.45f
                    damageCamp(camp, 3)
                }
            }
        }
    }

    private fun updateSpreaders(dt: Float) {
        spreaders.forEach { spreader ->
            when (spreader.state) {
                SpreaderState.IDLE -> Unit
                SpreaderState.RELOCATING,
                SpreaderState.MOVING_TO_BURROW -> {
                    val gooBonus = if (isInGoo(spreader.x, spreader.y)) 1.25f else 1f
                    val dx = spreader.targetX - spreader.x
                    val dy = spreader.targetY - spreader.y
                    val dist = hypot(dx, dy)
                    if (dist <= 12f) {
                        if (spreader.state == SpreaderState.MOVING_TO_BURROW) {
                            spreader.state = SpreaderState.BURROWING
                            spreader.burrowTimer = 0f
                        } else {
                            spreader.state = SpreaderState.IDLE
                        }
                    } else {
                        val step = min(dist, GameScale.SPREADER_SPEED * gooBonus * dt)
                        val angle = atan2(dy, dx)
                        val attempts = floatArrayOf(0f, 0.55f, -0.55f, 1.05f, -1.05f, 1.55f, -1.55f)
                        for (offset in attempts) {
                            val nx = spreader.x + cos(angle + offset) * step
                            val ny = spreader.y + sin(angle + offset) * step
                            if (isWalkable(nx, ny, 7f)) {
                                spreader.facingDir = facingAfterMove(spreader.facingDir, nx - spreader.x, ny - spreader.y)
                                spreader.x = nx
                                spreader.y = ny
                                break
                            }
                        }
                    }
                }
                SpreaderState.BURROWING -> {
                    spreader.burrowTimer += dt
                    if (spreader.burrowTimer >= 2.1f) {
                        spreader.state = SpreaderState.BURROWED
                        spreader.selected = false
                        spreader.spreadPulseTimer = 0f
                        addConnectedGooGrowth(spreader.x, spreader.y, 16f, 190f, 3.2f)
                        showMessage("Spreader rooted permanently and began spreading")
                    }
                }
                SpreaderState.BURROWED -> {
                    spreader.spreadPulseTimer += dt
                    if (spreader.spreadPulseTimer >= 11f) {
                        spreader.spreadPulseTimer = 0f
                        val nearestPatch = gooPatches.minByOrNull {
                            distance(spreader.x, spreader.y, it.x, it.y)
                        }
                        if (nearestPatch != null && distance(spreader.x, spreader.y, nearestPatch.x, nearestPatch.y) <= 120f) {
                            nearestPatch.maxRadius = min(360f, nearestPatch.maxRadius + 24f)
                        } else {
                            addConnectedGooGrowth(spreader.x, spreader.y, 12f, 150f, 2.4f)
                        }
                    }
                }
            }
        }
    }

    private fun updateGoo(dt: Float) {
        gooPatches.forEach { patch ->
            if (patch.radius < patch.maxRadius) {
                patch.radius = min(patch.maxRadius, patch.radius + patch.growthRate * dt)
            }
        }

        gooMaintenanceAccumulator += dt
        if (gooMaintenanceAccumulator < 0.50f) return
        gooMaintenanceAccumulator = 0f

        mergeCoveredGooPatches()

        val emitters = mutableListOf<Pair<Float, Float>>()
        biospewers.forEach { emitters += Pair(it.x, it.y) }
        nestWatchers.forEach { emitters += Pair(it.x, it.y) }
        emitters.forEach { point ->
            val coveringPatch = gooPatches.firstOrNull {
                distance(point.first, point.second, it.x, it.y) <= it.radius - 14f
            }
            if (coveringPatch != null) {
                return@forEach
            }
            if (isInGoo(point.first, point.second)) {
                if (addConnectedGooGrowth(point.first, point.second, 18f, 165f, 3.2f)) {
                    showMessage("A connected building extended the biofilm")
                }
            }
        }
    }

    private fun addConnectedGooGrowth(
        requestedX: Float,
        requestedY: Float,
        initialRadius: Float,
        maxRadius: Float,
        growthRate: Float,
    ): Boolean {
        if (gooPatches.isEmpty()) {
            gooPatches += GooPatch(nextGooPatchId++, requestedX, requestedY, initialRadius, maxRadius, growthRate)
            return true
        }

        val nearest = gooPatches.minByOrNull {
            distance(requestedX, requestedY, it.x, it.y) - it.radius
        }
        var originX = requestedX
        var originY = requestedY

        if (nearest != null && distance(requestedX, requestedY, nearest.x, nearest.y) <= nearest.radius) {
            var dx = requestedX - nearest.x
            var dy = requestedY - nearest.y
            var length = hypot(dx, dy)
            if (length < 0.001f) {
                val angle = (nextGooPatchId * 1.618f) % 6.28318f
                dx = cos(angle)
                dy = sin(angle)
                length = 1f
            }
            val edgeDistance = max(0f, nearest.radius - initialRadius * 0.55f)
            originX = nearest.x + dx / length * edgeDistance
            originY = nearest.y + dy / length * edgeDistance
        }

        val fullyCovered = gooPatches.any {
            distance(originX, originY, it.x, it.y) + initialRadius <= it.radius - 4f
        }
        if (fullyCovered) return false

        gooPatches += GooPatch(nextGooPatchId++, originX, originY, initialRadius, maxRadius, growthRate)
        return true
    }

    private fun mergeCoveredGooPatches() {
        if (gooPatches.size < 2) return
        val toRemove = mutableSetOf<Int>()
        for (index in gooPatches.indices) {
            val patch = gooPatches[index]
            for (otherIndex in gooPatches.indices) {
                if (index == otherIndex) continue
                val other = gooPatches[otherIndex]
                val centerDistance = distance(patch.x, patch.y, other.x, other.y)
                if (centerDistance + patch.radius <= other.radius - 8f) {
                    toRemove += patch.id
                }
            }
        }
        if (toRemove.isNotEmpty()) gooPatches.removeAll { it.id in toRemove }
    }

    private fun updateWildAnimals(dt: Float) {
        wildAnimals.forEach { animal ->
            if (!isTileUnlocked(animal.tileKey)) return@forEach
            animal.wanderTimer -= dt
            val dist = distance(animal.x, animal.y, animal.targetX, animal.targetY)
            if (animal.wanderTimer <= 0f || dist < 8f) {
                val tile = tiles[animal.tileKey] ?: return@forEach
                val point = randomWalkablePoint(tile, 24f)
                animal.targetX = point.first
                animal.targetY = point.second
                animal.wanderTimer = 4f + random.nextFloat() * 7f
            }
            val dx = animal.targetX - animal.x
            val dy = animal.targetY - animal.y
            val length = hypot(dx, dy)
            if (length > 3f) {
                val step = min(length, animal.speed * dt)
                val angle = atan2(dy, dx)
                val nx = animal.x + cos(angle) * step
                val ny = animal.y + sin(angle) * step
                if (isWalkable(nx, ny, 9f)) {
                    animal.x = nx
                    animal.y = ny
                } else {
                    animal.wanderTimer = 0f
                }
            }
        }
    }

    private fun updateEnemyCamps(dt: Float) {
        enemyCamps.forEach { camp ->
            if (!isTileUnlocked(camp.tileKey)) return@forEach
            val currentPopulation = primitiveEnemies.count { it.campId == camp.id }
            if (currentPopulation >= camp.populationTarget) {
                camp.respawnTimer = 0f
                return@forEach
            }
            camp.respawnTimer += dt
            if (camp.respawnTimer >= 14f) {
                camp.respawnTimer = 0f
                spawnPrimitiveEnemy(camp)
                showMessage("A primitive camp replaced a fallen hunter")
            }
        }
    }

    private fun updatePrimitiveEnemies(dt: Float) {
        primitiveEnemies.toList().forEach { enemy ->
            val camp = enemyCamps.firstOrNull { it.id == enemy.campId }
            if (camp == null || !isTileUnlocked(camp.tileKey)) {
                primitiveEnemies.remove(enemy)
                return@forEach
            }

            enemy.attackCooldown = max(0f, enemy.attackCooldown - dt)
            var target = resolveColonyTarget(enemy.targetKind, enemy.targetId)

            if (target != null && distance(target.x, target.y, camp.x, camp.y) > enemyCampLeashRadius) {
                target = null
                enemy.targetKind = null
                enemy.targetId = null
            }

            if (target == null && enemy.state != EnemyState.RETURNING) {
                target = findNearestColonyTarget(enemy.x, enemy.y, enemyAggroRadius, camp)
                if (target != null) {
                    enemy.targetKind = target.kind
                    enemy.targetId = target.id
                    enemy.state = EnemyState.CHASING
                }
            }

            if (target == null && enemy.state == EnemyState.CHASING) {
                enemy.targetKind = null
                enemy.targetId = null
                enemy.state = EnemyState.WANDERING
            }

            if (target != null) {
                enemy.facingDir = facingAfterMove(enemy.facingDir, target.x - enemy.x, target.y - enemy.y)
                val distanceToTarget = distance(enemy.x, enemy.y, target.x, target.y)
                if (distance(enemy.x, enemy.y, camp.x, camp.y) > enemyCampLeashRadius) {
                    enemy.targetKind = null
                    enemy.targetId = null
                    enemy.state = EnemyState.RETURNING
                } else if (distanceToTarget > GameScale.CELL * 0.75f) {
                    movePrimitiveToward(enemy, target.x, target.y, GameScale.ENEMY_CHASE_SPEED, dt)
                } else if (enemy.attackCooldown <= 0f) {
                    enemy.attackCooldown = 1.05f
                    damageColonyTarget(target, 6)
                }
                return@forEach
            }

            val distanceFromCamp = distance(enemy.x, enemy.y, camp.x, camp.y)
            if (enemy.state == EnemyState.RETURNING || distanceFromCamp > enemyWanderRadius + 35f) {
                enemy.state = EnemyState.RETURNING
                movePrimitiveToward(enemy, camp.x, camp.y, GameScale.ENEMY_RETURN_SPEED, dt)
                if (distanceFromCamp <= GameScale.CELL * 1.5f) {
                    enemy.state = EnemyState.WANDERING
                    enemy.wanderTimer = 0f
                }
                return@forEach
            }

            enemy.state = EnemyState.WANDERING
            enemy.wanderTimer -= dt
            if (enemy.wanderTimer <= 0f || distance(enemy.x, enemy.y, enemy.targetX, enemy.targetY) <= 7f) {
                val point = randomPointAroundCamp(camp, enemyWanderRadius)
                enemy.targetX = point.first
                enemy.targetY = point.second
                enemy.wanderTimer = 2.5f + random.nextFloat() * 4.5f
            }
            movePrimitiveToward(enemy, enemy.targetX, enemy.targetY, GameScale.ENEMY_WANDER_SPEED, dt)
        }

        primitiveEnemies.removeAll { it.health <= 0 }
    }

    private fun movePrimitiveToward(enemy: PrimitiveEnemy, x: Float, y: Float, speed: Float, dt: Float) {
        val dx = x - enemy.x
        val dy = y - enemy.y
        val dist = hypot(dx, dy)
        if (dist <= 0.001f) return
        val step = min(dist, speed * dt)
        val angle = atan2(dy, dx)
        val attempts = floatArrayOf(0f, 0.55f, -0.55f, 1.05f, -1.05f)
        for (offset in attempts) {
            val nx = enemy.x + cos(angle + offset) * step
            val ny = enemy.y + sin(angle + offset) * step
            if (isWalkable(nx, ny, 8f)) {
                enemy.facingDir = facingAfterMove(enemy.facingDir, nx - enemy.x, ny - enemy.y)
                enemy.x = nx
                enemy.y = ny
                return
            }
        }
    }

    private fun randomPointAroundCamp(camp: EnemyCamp, radius: Float): Pair<Float, Float> {
        repeat(40) {
            val angle = random.nextFloat() * 6.28318f
            val minimum = GameScale.CELL * 1.5f
            val distance = minimum + random.nextFloat() * (radius - minimum).coerceAtLeast(GameScale.CELL)
            val x = camp.x + cos(angle) * distance
            val y = camp.y + sin(angle) * distance
            if (isWalkable(x, y, 9f)) return Pair(x, y)
        }
        return Pair(camp.x, camp.y)
    }

    private fun findNearestColonyTarget(
        x: Float,
        y: Float,
        radius: Float,
        camp: EnemyCamp,
    ): ColonyTarget? = allColonyTargets()
        .filter { distance(x, y, it.x, it.y) <= radius }
        .filter { distance(camp.x, camp.y, it.x, it.y) <= enemyCampLeashRadius }
        .minByOrNull { distance(x, y, it.x, it.y) }

    private fun allColonyTargets(): List<ColonyTarget> = buildList {
        drones.forEach { add(ColonyTarget(ColonyTargetKind.DRONE, it.id, it.x, it.y)) }
        watcherUnits.forEach { add(ColonyTarget(ColonyTargetKind.WATCHER, it.id, it.x, it.y)) }
        defenders.forEach { add(ColonyTarget(ColonyTargetKind.GUARD, it.id, it.x, it.y)) }
        hatchlings.forEach { add(ColonyTarget(ColonyTargetKind.HATCHLING, it.id, it.x, it.y)) }
        spreaders.forEach { add(ColonyTarget(ColonyTargetKind.SPREADER, it.id, it.x, it.y)) }
    }

    private fun resolveColonyTarget(kind: ColonyTargetKind?, id: Int?): ColonyTarget? {
        if (kind == null || id == null) return null
        return when (kind) {
            ColonyTargetKind.DRONE -> drones.firstOrNull { it.id == id }?.let { ColonyTarget(kind, id, it.x, it.y) }
            ColonyTargetKind.WATCHER -> watcherUnits.firstOrNull { it.id == id }?.let { ColonyTarget(kind, id, it.x, it.y) }
            ColonyTargetKind.GUARD -> defenders.firstOrNull { it.id == id }?.let { ColonyTarget(kind, id, it.x, it.y) }
            ColonyTargetKind.HATCHLING -> hatchlings.firstOrNull { it.id == id }?.let { ColonyTarget(kind, id, it.x, it.y) }
            ColonyTargetKind.SPREADER -> spreaders.firstOrNull { it.id == id }?.let { ColonyTarget(kind, id, it.x, it.y) }
        }
    }

    private fun damageColonyTarget(target: ColonyTarget, damage: Int) {
        when (target.kind) {
            ColonyTargetKind.DRONE -> drones.firstOrNull { it.id == target.id }?.let { drone ->
                drone.health -= damage
                if (drone.health <= 0) {
                    drones.remove(drone)
                    buildSites.forEach { it.builderDroneIds.remove(drone.id) }
                    buildSites.removeAll { it.builderDroneIds.isEmpty() }
                    showMessage("A worker drone was lost near an enemy camp")
                }
            }
            ColonyTargetKind.WATCHER -> watcherUnits.firstOrNull { it.id == target.id }?.let { unit ->
                unit.health -= damage
                if (unit.health <= 0) watcherUnits.remove(unit)
            }
            ColonyTargetKind.GUARD -> defenders.firstOrNull { it.id == target.id }?.let { unit ->
                unit.health -= damage
                if (unit.health <= 0) defenders.remove(unit)
            }
            ColonyTargetKind.HATCHLING -> hatchlings.firstOrNull { it.id == target.id }?.let { unit ->
                unit.health -= damage
                if (unit.health <= 0) hatchlings.remove(unit)
            }
            ColonyTargetKind.SPREADER -> spreaders.firstOrNull { it.id == target.id }?.let { unit ->
                unit.health -= damage
                if (unit.health <= 0) spreaders.remove(unit)
            }
        }
    }

    private fun damageEnemy(enemy: PrimitiveEnemy, damage: Int) {
        enemy.health -= damage
        if (enemy.health <= 0) {
            primitiveEnemies.remove(enemy)
            minerals += 2
            showMessage("Primitive hunter defeated: +2M")
        }
    }

    private fun damageCamp(camp: EnemyCamp, damage: Int) {
        camp.health -= damage
        if (camp.health > 0) return
        primitiveEnemies.removeAll { it.campId == camp.id }
        enemyCamps.remove(camp)
        shopGold += camp.goldReward
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        showMessage("Camp destroyed: +${camp.goldReward} shop gold")
        setInspectInfo("Camp Destroyed", "The primitive tent was eliminated. Gold was added to the standalone shop.")
    }

    private fun nearestEnemy(x: Float, y: Float, radius: Float): PrimitiveEnemy? =
        primitiveEnemies.filter { it.health > 0 && distance(x, y, it.x, it.y) <= radius }
            .minByOrNull { distance(x, y, it.x, it.y) }

    private fun nearestCamp(x: Float, y: Float, radius: Float): EnemyCamp? =
        enemyCamps.filter { it.health > 0 && distance(x, y, it.x, it.y) <= radius }
            .minByOrNull { distance(x, y, it.x, it.y) }

    private fun moveToward(
        drone: Drone,
        x: Float,
        y: Float,
        speed: Float,
        dt: Float,
        stopDistance: Float = 4f,
    ): Boolean {
        val dx = x - drone.x
        val dy = y - drone.y
        val dist = hypot(dx, dy)
        if (dist <= stopDistance + 0.5f) return true

        val step = min(dist - stopDistance, speed * dt)
        if (step <= 0.1f) return true
        val angle = atan2(dy, dx)
        val attempts = floatArrayOf(0f, 0.65f, -0.65f, 1.15f, -1.15f, 1.57f, -1.57f)
        for (offset in attempts) {
            val nx = drone.x + cos(angle + offset) * step
            val ny = drone.y + sin(angle + offset) * step
            if (isWalkable(nx, ny, 8f)) {
                drone.facingDir = facingCardinal(nx - drone.x, ny - drone.y)
                drone.x = nx
                drone.y = ny
                return false
            }
        }
        return false
    }

    private fun movePointAvoidingObstacles(
        currentX: Float,
        currentY: Float,
        targetX: Float,
        targetY: Float,
        speed: Float,
        dt: Float,
        collisionRadius: Float,
        stopDistance: Float = GameScale.CELL * 0.20f,
    ): MoveResult {
        val dx = targetX - currentX
        val dy = targetY - currentY
        val dist = hypot(dx, dy)
        if (dist <= stopDistance + 0.5f) return MoveResult(currentX, currentY, true)

        val step = min(dist - stopDistance, speed * dt)
        if (step <= 0.1f) return MoveResult(currentX, currentY, true)
        val angle = atan2(dy, dx)
        val attempts = floatArrayOf(0f, 0.55f, -0.55f, 0.95f, -0.95f, 1.35f, -1.35f, 1.57f, -1.57f)
        for (offset in attempts) {
            val nx = currentX + cos(angle + offset) * step
            val ny = currentY + sin(angle + offset) * step
            if (isWalkable(nx, ny, collisionRadius)) {
                return MoveResult(nx, ny, false)
            }
        }
        return MoveResult(currentX, currentY, false)
    }

    private fun drawWorld(canvas: Canvas) {
        val play = worldViewportRect()
        canvas.save()
        canvas.clipRect(play)
        paint.style = Paint.Style.FILL
        paint.color = worldBackgroundColor()
        canvas.drawRect(play, paint)

        drawHexWorld(canvas)
        drawGoo(canvas)
        drawWaterFeatures(canvas)
        landmarks.forEach { if (isTileUnlocked(it.tileKey)) drawLandmark(canvas, it) }
        drawCloudShadows(canvas)
        drawDepthSortedWorldObjects(canvas)
        drawBuildGhost(canvas)
        drawSelectionRing(canvas)
        drawNightOverlay(canvas)
        canvas.restore()
    }

    private fun drawDepthSortedWorldObjects(canvas: Canvas) {
        val entries = mutableListOf<RenderEntry>()

        obstacles.filter { isTileUnlocked(it.tileKey) && isWorldVisible(it.x, it.y, it.radius * 2.2f) }.forEach { obstacle ->
            entries += RenderEntry(obstacle.y, if (obstacle.type == ObstacleType.TREE) 0.10f else 0f) {
                drawObstacle(canvas, obstacle)
            }
        }
        enemyCamps.filter { isTileUnlocked(it.tileKey) && isWorldVisible(it.x, it.y, GameScale.ENEMY_CAMP_VISUAL) }.forEach { camp ->
            entries += RenderEntry(camp.y, 0.02f) { drawEnemyCamp(canvas, camp) }
        }
        wildAnimals.filter { isWorldVisible(it.x, it.y, GameScale.CELL * 2f) }.forEach { animal -> entries += RenderEntry(animal.y) { drawWildAnimal(canvas, animal) } }
        primitiveEnemies.filter { isWorldVisible(it.x, it.y, GameScale.CELL * 2f) }.forEach { enemy -> entries += RenderEntry(enemy.y) { drawPrimitiveEnemy(canvas, enemy) } }
        resourceNodes.filter { isWorldVisible(it.x, it.y, GameScale.RESOURCE_VISUAL * 1.4f) }.forEach { node -> entries += RenderEntry(node.y, -0.02f) { drawResource(canvas, node) } }
        nest?.takeIf { isWorldVisible(it.x, it.y, GameScale.NEST_STAGE_3_VISUAL) }?.let { activeNest -> entries += RenderEntry(activeNest.y, 0.03f) { drawNest(canvas, activeNest) } }
        larvae.filter { isWorldVisible(it.x, it.y, GameScale.CELL) }.forEach { larva -> entries += RenderEntry(larva.y) { drawLarva(canvas, larva) } }
        buildSites.filter { isWorldVisible(it.x, it.y, GameScale.CELL * 4f) }.forEach { site -> entries += RenderEntry(site.y) { drawBuildSite(canvas, site) } }
        biospewers.filter { isWorldVisible(it.x, it.y, GameScale.BIOSPEWER_HEIGHT) }.forEach { spewer -> entries += RenderEntry(spewer.y, 0.03f) { drawBiospewer(canvas, spewer) } }
        nestWatchers.filter { isWorldVisible(it.x, it.y, GameScale.WATCHER_HEIGHT) }.forEach { watcher -> entries += RenderEntry(watcher.y, 0.03f) { drawNestWatcher(canvas, watcher) } }
        watcherUnits.filter { isWorldVisible(it.x, it.y, GameScale.CELL * 2f) }.forEach { unit -> entries += RenderEntry(unit.y) { drawWatcherUnit(canvas, unit) } }
        defenders.filter { isWorldVisible(it.x, it.y, GameScale.CELL * 3f) }.forEach { defender -> entries += RenderEntry(defender.y) { drawDefender(canvas, defender) } }
        hatchlings.filter { isWorldVisible(it.x, it.y, GameScale.CELL * 2f) }.forEach { hatchling -> entries += RenderEntry(hatchling.y) { drawHatchling(canvas, hatchling) } }
        spreaders.filter { isWorldVisible(it.x, it.y, GameScale.CELL * 3f) }.forEach { spreader -> entries += RenderEntry(spreader.y) { drawSpreader(canvas, spreader) } }
        drones.filter { isWorldVisible(it.x, it.y, GameScale.CELL * 2f) }.forEach { drone -> entries += RenderEntry(drone.y) { drawDrone(canvas, drone) } }

        entries.sortedWith(compareBy<RenderEntry> { it.sortY }.thenBy { it.orderBias }).forEach { it.draw() }
    }

    private fun drawHexWorld(canvas: Canvas) {
        tiles.values.sortedBy { if (it.unlocked) 0 else 1 }.forEach { tile ->
            val center = hexCenter(tile.q, tile.r)
            val screen = worldToScreen(center.first, center.second)
            val radius = hexRadius * zoom
            val viewport = worldViewportRect()
            if (screen.first + radius < viewport.left || screen.first - radius > viewport.right ||
                screen.second + radius < viewport.top || screen.second - radius > viewport.bottom) return@forEach

            makeHexPath(screen.first, screen.second, radius)
            paint.style = Paint.Style.FILL
            if (tile.unlocked) {
                val biome = tileBiome(tile)
                val shade = abs(tile.seed % 19)
                paint.color = litWorldColor(
                    Color.rgb(
                        (Color.red(biomeBaseColor(biome)) + shade / 2).coerceIn(0, 255),
                        (Color.green(biomeBaseColor(biome)) + shade).coerceIn(0, 255),
                        (Color.blue(biomeBaseColor(biome)) + shade / 3).coerceIn(0, 255),
                    ),
                    biomeDarkColor(biome),
                )
                canvas.drawPath(path, paint)
                drawGroundDetails(canvas, tile, center.first, center.second, biome)
                drawBiomeTransitions(canvas, tile, screen.first, screen.second, radius, biome)
                drawCliffEdgePass(canvas, tile, screen.first, screen.second, radius, biome)
            } else {
                val biome = tileBiome(tile)
                paint.color = litWorldColor(biomeDarkColor(biome), Color.rgb(18, 22, 31))
                canvas.drawPath(path, paint)
                drawFogOfWar(canvas, tile, screen.first, screen.second, radius)
            }

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1f, 1.25f * density)
            paint.color = when {
                selectedBarrierKey == tileKey(tile.q, tile.r) -> Color.YELLOW
                tile.unlocked -> litWorldColor(Color.argb(110, 74, 135, 57), Color.argb(110, 44, 78, 65))
                hasUnlockedNeighbor(tile.q, tile.r) -> Color.argb(105, 138, 104, 220)
                else -> Color.argb(24, 50, 54, 68)
            }
            canvas.drawPath(path, paint)

            if (!tile.unlocked && hasUnlockedNeighbor(tile.q, tile.r) && radius > 105f) {
                val cost = barrierCost(tile)
                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = max(8f * density, 12f * density * min(zoom, 1.15f))
                paint.color = litWorldColor(Color.rgb(76, 102, 116), Color.rgb(202, 218, 235))
                canvas.drawText("FOG WALL", screen.first, screen.second - 6f * density, paint)
                paint.color = litWorldColor(Color.rgb(48, 72, 78), Color.rgb(235, 239, 245))
                paint.textSize = max(7f * density, 9f * density * min(zoom, 1.15f))
                canvas.drawText("${cost.first}M  ${cost.second}G", screen.first, screen.second + 12f * density, paint)
            }
        }
    }

    private fun drawFogOfWar(canvas: Canvas, tile: HexTile, cx: Float, cy: Float, radius: Float) {
        val seeded = Random(tile.seed xor 0x2F41)
        paint.style = Paint.Style.FILL
        repeat(13) { index ->
            val angle = seeded.nextFloat() * 6.28318f
            val distance = sqrt(seeded.nextFloat()) * radius * 0.72f
            val x = cx + cos(angle) * distance
            val y = cy + sin(angle) * distance
            val w = radius * (0.22f + seeded.nextFloat() * 0.28f)
            val h = w * (0.35f + seeded.nextFloat() * 0.30f)
            val alpha = 62 + (index % 4) * 18
            paint.color = Color.argb(alpha, 242, 250, 250)
            canvas.drawOval(RectF(x - w, y - h, x + w, y + h), paint)
        }

        if (radius > 90f) {
            paint.color = Color.argb(42, 43, 78, 60)
            repeat(18) {
                val angle = seeded.nextFloat() * 6.28318f
                val distance = sqrt(seeded.nextFloat()) * radius * 0.76f
                val x = cx + cos(angle) * distance
                val y = cy + sin(angle) * distance
                val tree = max(2f, radius * (0.018f + seeded.nextFloat() * 0.018f))
                canvas.drawRect(x - tree * 0.16f, y, x + tree * 0.16f, y + tree * 1.25f, paint)
                path.reset()
                path.moveTo(x, y - tree * 1.8f)
                path.lineTo(x + tree, y + tree * 0.25f)
                path.lineTo(x - tree, y + tree * 0.25f)
                path.close()
                canvas.drawPath(path, paint)
            }
        }
    }

    private fun drawGroundDetails(canvas: Canvas, tile: HexTile, centerX: Float, centerY: Float, biome: BiomeType) {
        val seeded = Random(tile.seed)
        val screen = worldToScreen(centerX, centerY)
        val screenRadius = hexRadius * zoom
        makeHexPath(screen.first, screen.second, screenRadius)
        canvas.save()
        canvas.clipPath(path)

        drawTerrainPattern(canvas, screen.first, screen.second, screenRadius, biome)

        // Large blended patches give each biome a more natural ground body and
        // use world-space placement so neighboring tiles flow together better.
        paint.style = Paint.Style.FILL
        repeat(10) { index ->
            val angle = seeded.nextFloat() * 6.28318f
            val radius = sqrt(seeded.nextFloat()) * hexRadius * 0.72f
            val wx = centerX + cos(angle) * radius
            val wy = centerY + sin(angle) * radius
            val s = worldToScreen(wx, wy)
            val patchW = (64f + seeded.nextFloat() * 110f) * zoom
            val patchH = patchW * (0.45f + seeded.nextFloat() * 0.55f)
            paint.color = terrainPatchColor(biome, index)
            canvas.drawOval(RectF(s.first - patchW * 0.5f, s.second - patchH * 0.5f,
                s.first + patchW * 0.5f, s.second + patchH * 0.5f), paint)
        }

        // Biome-specific striation / shelf details for cliffs, ruins, and other
        // terrain so the world reads less like a flat color fill.
        when (biome) {
            BiomeType.HIGHLANDS, BiomeType.CANYON, BiomeType.RUINS -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = max(1f, 2.2f * zoom)
                repeat(8) { index ->
                    val angle = seeded.nextFloat() * 6.28318f
                    val radius = (0.14f + seeded.nextFloat() * 0.54f) * hexRadius
                    val wx = centerX + cos(angle) * radius
                    val wy = centerY + sin(angle) * radius
                    val s = worldToScreen(wx, wy)
                    val length = (28f + seeded.nextFloat() * 48f) * zoom
                    val ridgeAngle = when (biome) {
                        BiomeType.CANYON -> 1.20f + seeded.nextFloat() * 0.40f
                        BiomeType.HIGHLANDS -> 0.45f + seeded.nextFloat() * 0.55f
                        else -> seeded.nextFloat() * 1.5f
                    }
                    paint.color = terrainLineColor(biome, index)
                    path.reset()
                    path.moveTo(s.first - cos(ridgeAngle) * length * 0.5f, s.second - sin(ridgeAngle) * length * 0.5f)
                    path.lineTo(s.first + cos(ridgeAngle) * length * 0.5f, s.second + sin(ridgeAngle) * length * 0.5f)
                    canvas.drawPath(path, paint)
                }
            }
            else -> Unit
        }

        // Fine detail scatter keeps tiles lively without cluttering them.
        paint.style = Paint.Style.FILL
        repeat(56) { index ->
            val angle = seeded.nextFloat() * 6.28318f
            val radius = sqrt(seeded.nextFloat()) * hexRadius * 0.84f
            val wx = centerX + cos(angle) * radius
            val wy = centerY + sin(angle) * radius
            val s = worldToScreen(wx, wy)
            val size = max(0.7f, (0.8f + seeded.nextFloat() * 2.0f) * zoom)
            paint.color = terrainDetailColor(biome, index)
            if (index % 3 == 0) {
                canvas.drawRect(s.first - size, s.second - size, s.first + size, s.second + size, paint)
            } else {
                canvas.drawOval(RectF(s.first - size, s.second - size, s.first + size, s.second + size), paint)
            }
        }

        canvas.restore()
    }

    private fun drawTerrainPattern(canvas: Canvas, cx: Float, cy: Float, radius: Float, biome: BiomeType) {
        val shader = when (biome) {
            BiomeType.VERDANT_FOREST -> terrainShaderForest
            BiomeType.MISTY_WETLAND -> terrainShaderWetland
            BiomeType.CRYSTAL_BARRENS -> terrainShaderCrystal
            BiomeType.HIGHLANDS -> terrainShaderHighlands
            BiomeType.CANYON -> terrainShaderCanyon
            BiomeType.RUINS -> terrainShaderRuins
        }
        val bitmapSize = when (biome) {
            BiomeType.VERDANT_FOREST -> terrainTileForest.width
            BiomeType.MISTY_WETLAND -> terrainTileWetland.width
            BiomeType.CRYSTAL_BARRENS -> terrainTileCrystal.width
            BiomeType.HIGHLANDS -> terrainTileHighlands.width
            BiomeType.CANYON -> terrainTileCanyon.width
            BiomeType.RUINS -> terrainTileRuins.width
        }.coerceAtLeast(1)
        val tileWorldSize = GameScale.CELL * 2f
        val scale = (tileWorldSize * zoom) / bitmapSize.toFloat()
        val origin = worldToScreen(0f, 0f)
        terrainShaderMatrix.reset()
        terrainShaderMatrix.setScale(scale, scale)
        terrainShaderMatrix.postTranslate(origin.first, origin.second)
        shader.setLocalMatrix(terrainShaderMatrix)

        paint.shader = shader
        paint.style = Paint.Style.FILL
        canvas.drawRect(cx - radius, cy - radius, cx + radius, cy + radius, paint)
        paint.shader = null
    }

    private fun terrainPatchColor(biome: BiomeType, index: Int): Int = when (biome) {
        BiomeType.VERDANT_FOREST -> when (index % 4) {
            0 -> litWorldColor(Color.argb(72, 132, 188, 86), Color.argb(72, 58, 92, 64))
            1 -> litWorldColor(Color.argb(64, 104, 166, 70), Color.argb(64, 42, 82, 54))
            2 -> litWorldColor(Color.argb(58, 175, 205, 104), Color.argb(58, 92, 102, 72))
            else -> litWorldColor(Color.argb(46, 104, 148, 66), Color.argb(46, 49, 80, 53))
        }
        BiomeType.MISTY_WETLAND -> when (index % 4) {
            0 -> litWorldColor(Color.argb(78, 90, 164, 118), Color.argb(78, 36, 80, 67))
            1 -> litWorldColor(Color.argb(62, 74, 138, 122), Color.argb(62, 30, 70, 74))
            2 -> litWorldColor(Color.argb(52, 126, 162, 136), Color.argb(52, 58, 86, 84))
            else -> litWorldColor(Color.argb(40, 82, 144, 126), Color.argb(40, 40, 76, 78))
        }
        BiomeType.CRYSTAL_BARRENS -> when (index % 4) {
            0 -> litWorldColor(Color.argb(68, 160, 176, 118), Color.argb(68, 72, 86, 68))
            1 -> litWorldColor(Color.argb(54, 132, 154, 108), Color.argb(54, 52, 68, 58))
            2 -> litWorldColor(Color.argb(44, 170, 214, 255), Color.argb(44, 84, 110, 132))
            else -> litWorldColor(Color.argb(36, 128, 142, 102), Color.argb(36, 52, 62, 56))
        }
        BiomeType.HIGHLANDS -> when (index % 4) {
            0 -> litWorldColor(Color.argb(78, 158, 168, 154), Color.argb(78, 70, 78, 74))
            1 -> litWorldColor(Color.argb(58, 136, 148, 132), Color.argb(58, 60, 68, 63))
            2 -> litWorldColor(Color.argb(52, 116, 144, 112), Color.argb(52, 50, 61, 52))
            else -> litWorldColor(Color.argb(44, 176, 186, 172), Color.argb(44, 88, 92, 90))
        }
        BiomeType.CANYON -> when (index % 4) {
            0 -> litWorldColor(Color.argb(84, 198, 138, 88), Color.argb(84, 98, 62, 48))
            1 -> litWorldColor(Color.argb(66, 176, 118, 76), Color.argb(66, 88, 52, 40))
            2 -> litWorldColor(Color.argb(50, 214, 162, 106), Color.argb(50, 120, 78, 58))
            else -> litWorldColor(Color.argb(42, 162, 102, 66), Color.argb(42, 76, 48, 38))
        }
        BiomeType.RUINS -> when (index % 4) {
            0 -> litWorldColor(Color.argb(72, 156, 168, 112), Color.argb(72, 72, 80, 58))
            1 -> litWorldColor(Color.argb(54, 120, 142, 96), Color.argb(54, 52, 62, 48))
            2 -> litWorldColor(Color.argb(48, 182, 176, 140), Color.argb(48, 98, 92, 74))
            else -> litWorldColor(Color.argb(40, 102, 134, 92), Color.argb(40, 46, 56, 46))
        }
    }

    private fun terrainDetailColor(biome: BiomeType, index: Int): Int = when (biome) {
        BiomeType.VERDANT_FOREST -> when {
            index % 17 == 0 -> litWorldColor(Color.rgb(250, 220, 92), Color.rgb(112, 102, 82))
            index % 11 == 0 -> litWorldColor(Color.rgb(224, 133, 220), Color.rgb(91, 67, 105))
            index % 5 == 0 -> litWorldColor(Color.rgb(96, 151, 58), Color.rgb(35, 66, 43))
            else -> litWorldColor(Color.rgb(65, 132, 55), Color.rgb(26, 59, 39))
        }
        BiomeType.MISTY_WETLAND -> if (index % 6 == 0) litWorldColor(Color.rgb(86, 176, 124), Color.rgb(34, 71, 56)) else litWorldColor(Color.rgb(72, 128, 98), Color.rgb(28, 57, 49))
        BiomeType.CRYSTAL_BARRENS -> if (index % 7 == 0) litWorldColor(Color.rgb(118, 196, 255), Color.rgb(52, 89, 110)) else litWorldColor(Color.rgb(112, 128, 84), Color.rgb(44, 61, 44))
        BiomeType.HIGHLANDS -> if (index % 5 == 0) litWorldColor(Color.rgb(177, 177, 182), Color.rgb(76, 82, 88)) else litWorldColor(Color.rgb(119, 142, 116), Color.rgb(51, 61, 56))
        BiomeType.CANYON -> if (index % 5 == 0) litWorldColor(Color.rgb(212, 158, 101), Color.rgb(116, 77, 55)) else litWorldColor(Color.rgb(176, 114, 78), Color.rgb(87, 54, 41))
        BiomeType.RUINS -> if (index % 8 == 0) litWorldColor(Color.rgb(197, 193, 160), Color.rgb(104, 94, 78)) else litWorldColor(Color.rgb(112, 138, 96), Color.rgb(45, 58, 47))
    }

    private fun terrainLineColor(biome: BiomeType, index: Int): Int = when (biome) {
        BiomeType.CANYON -> if (index % 2 == 0) litWorldColor(Color.argb(168, 235, 186, 118), Color.argb(168, 142, 96, 70)) else litWorldColor(Color.argb(126, 150, 92, 64), Color.argb(126, 74, 49, 38))
        BiomeType.HIGHLANDS -> if (index % 2 == 0) litWorldColor(Color.argb(160, 218, 220, 226), Color.argb(160, 96, 100, 110)) else litWorldColor(Color.argb(122, 142, 150, 156), Color.argb(122, 70, 76, 82))
        BiomeType.RUINS -> if (index % 2 == 0) litWorldColor(Color.argb(148, 188, 182, 144), Color.argb(148, 104, 96, 78)) else litWorldColor(Color.argb(118, 112, 126, 102), Color.argb(118, 60, 68, 58))
        else -> litWorldColor(Color.argb(128, 180, 180, 180), Color.argb(128, 88, 88, 88))
    }

    private fun drawBiomeTransitions(
        canvas: Canvas,
        tile: HexTile,
        screenX: Float,
        screenY: Float,
        radius: Float,
        biome: BiomeType,
    ) {
        val corners = hexCorners(screenX, screenY, radius)
        hexDirections.forEachIndexed { index, dir ->
            val neighbor = tiles[tileKey(tile.q + dir.first, tile.r + dir.second)] ?: return@forEachIndexed
            if (!neighbor.unlocked) return@forEachIndexed
            val neighborBiome = tileBiome(neighbor)
            if (neighborBiome == biome) return@forEachIndexed

            val p1 = corners[index]
            val p2 = corners[(index + 1) % corners.size]
            val in1x = p1.first + (screenX - p1.first) * 0.16f
            val in1y = p1.second + (screenY - p1.second) * 0.16f
            val in2x = p2.first + (screenX - p2.first) * 0.16f
            val in2y = p2.second + (screenY - p2.second) * 0.16f

            path.reset()
            path.moveTo(p1.first, p1.second)
            path.lineTo(p2.first, p2.second)
            path.lineTo(in2x, in2y)
            path.lineTo(in1x, in1y)
            path.close()
            paint.style = Paint.Style.FILL
            paint.color = biomeTransitionColor(biome, neighborBiome)
            canvas.drawPath(path, paint)

            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1f, 1.4f * zoom)
            paint.color = biomeTransitionLineColor(biome, neighborBiome)
            canvas.drawLine(p1.first, p1.second, p2.first, p2.second, paint)
        }
    }

    private fun drawCliffEdgePass(
        canvas: Canvas,
        tile: HexTile,
        screenX: Float,
        screenY: Float,
        radius: Float,
        biome: BiomeType,
    ) {
        if (biome != BiomeType.HIGHLANDS && biome != BiomeType.CANYON) return
        val corners = hexCorners(screenX, screenY, radius)
        hexDirections.forEachIndexed { index, dir ->
            val neighbor = tiles[tileKey(tile.q + dir.first, tile.r + dir.second)]
            val neighborBiome = neighbor?.takeIf { it.unlocked }?.let(::tileBiome)
            val shouldDraw = when (biome) {
                BiomeType.HIGHLANDS -> neighborBiome != BiomeType.HIGHLANDS
                BiomeType.CANYON -> neighborBiome != BiomeType.CANYON
                else -> false
            }
            if (!shouldDraw) return@forEachIndexed

            val start = corners[index]
            val end = corners[(index + 1) % corners.size]
            val insetFactor = if (biome == BiomeType.CANYON) 0.17f else 0.13f
            val innerStartX = start.first + (screenX - start.first) * insetFactor
            val innerStartY = start.second + (screenY - start.second) * insetFactor
            val innerEndX = end.first + (screenX - end.first) * insetFactor
            val innerEndY = end.second + (screenY - end.second) * insetFactor

            path.reset()
            path.moveTo(start.first, start.second)
            path.lineTo(end.first, end.second)
            path.lineTo(innerEndX, innerEndY)
            path.lineTo(innerStartX, innerStartY)
            path.close()
            paint.style = Paint.Style.FILL
            paint.color = if (biome == BiomeType.CANYON) {
                litWorldColor(Color.argb(56, 126, 84, 62), Color.argb(56, 54, 34, 28))
            } else {
                litWorldColor(Color.argb(54, 132, 138, 146), Color.argb(54, 62, 68, 78))
            }
            canvas.drawPath(path, paint)

            val steps = if (biome == BiomeType.CANYON) 4 else 3
            repeat(steps) { layer ->
                val inset = (0.05f + layer * 0.045f) * radius
                val sx = start.first + (screenX - start.first) * (inset / radius)
                val sy = start.second + (screenY - start.second) * (inset / radius)
                val ex = end.first + (screenX - end.first) * (inset / radius)
                val ey = end.second + (screenY - end.second) * (inset / radius)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = max(1f, (if (layer == 0) 2.4f else 1.6f) * zoom)
                paint.color = if (biome == BiomeType.CANYON) {
                    if (layer % 2 == 0) litWorldColor(Color.argb(148, 120, 74, 52), Color.argb(148, 66, 38, 32))
                    else litWorldColor(Color.argb(122, 214, 164, 114), Color.argb(122, 122, 78, 62))
                } else {
                    if (layer == 0) litWorldColor(Color.argb(142, 122, 128, 136), Color.argb(142, 70, 76, 84))
                    else litWorldColor(Color.argb(110, 204, 208, 214), Color.argb(110, 104, 108, 118))
                }
                canvas.drawLine(sx, sy, ex, ey, paint)
            }
        }
    }

    private fun biomeTransitionColor(from: BiomeType, to: BiomeType): Int {
        val mix = Color.rgb(
            ((Color.red(biomeBaseColor(from)) + Color.red(biomeBaseColor(to))) / 2),
            ((Color.green(biomeBaseColor(from)) + Color.green(biomeBaseColor(to))) / 2),
            ((Color.blue(biomeBaseColor(from)) + Color.blue(biomeBaseColor(to))) / 2),
        )
        return Color.argb(46, Color.red(mix), Color.green(mix), Color.blue(mix))
    }

    private fun biomeTransitionLineColor(from: BiomeType, to: BiomeType): Int {
        val mix = Color.rgb(
            ((Color.red(biomeDarkColor(from)) + Color.red(biomeDarkColor(to))) / 2),
            ((Color.green(biomeDarkColor(from)) + Color.green(biomeDarkColor(to))) / 2),
            ((Color.blue(biomeDarkColor(from)) + Color.blue(biomeDarkColor(to))) / 2),
        )
        return Color.argb(90, Color.red(mix), Color.green(mix), Color.blue(mix))
    }

    private fun hexCorners(cx: Float, cy: Float, radius: Float): List<Pair<Float, Float>> =
        (0 until 6).map { i ->
            val angle = Math.toRadians((60.0 * i).toDouble())
            Pair(cx + cos(angle).toFloat() * radius, cy + sin(angle).toFloat() * radius)
        }

    private fun drawLandmark(canvas: Canvas, landmark: Landmark) {
        val s = worldToScreen(landmark.x, landmark.y)
        val r = landmark.radius * zoom
        if (!isScreenVisible(s.first, s.second, r + 16f)) return
        when (landmark.type) {
            LandmarkType.RUIN -> {
                paint.style = Paint.Style.FILL
                paint.color = litWorldColor(Color.argb(88, 168, 166, 148), Color.argb(88, 82, 76, 66))
                canvas.drawOval(RectF(s.first - r * 0.95f, s.second + r * 0.18f, s.first + r * 0.95f, s.second + r * 0.72f), paint)
                paint.color = litWorldColor(Color.argb(155, 172, 170, 156), Color.argb(155, 86, 84, 76))
                repeat(4) { idx ->
                    val off = (idx - 1.5f) * r * 0.23f
                    canvas.drawRect(s.first + off - r * 0.10f, s.second + r * 0.20f,
                        s.first + off + r * 0.10f, s.second + r * 0.34f, paint)
                }
                drawBitmapCentered(canvas, ruinsSprite, s.first, s.second + r * 0.02f, r * 1.7f, r * 1.7f)
            }
            LandmarkType.MOUNTAIN -> {
                paint.style = Paint.Style.FILL
                paint.color = litWorldColor(Color.argb(86, 134, 144, 122), Color.argb(86, 58, 68, 64))
                canvas.drawOval(RectF(s.first - r * 1.05f, s.second + r * 0.18f, s.first + r * 1.05f, s.second + r * 0.70f), paint)
                drawBitmapCentered(canvas, mountainSprite, s.first, s.second + r * 0.06f, r * 1.95f, r * 1.95f)
            }
            LandmarkType.CANYON -> {
                paint.style = Paint.Style.FILL
                paint.color = litWorldColor(Color.argb(82, 176, 126, 82), Color.argb(82, 86, 56, 44))
                canvas.drawOval(RectF(s.first - r * 1.10f, s.second + r * 0.12f, s.first + r * 1.10f, s.second + r * 0.62f), paint)
                drawBitmapCentered(canvas, canyonSprite, s.first, s.second + r * 0.08f, r * 1.7f, r * 1.7f)
            }
            LandmarkType.GROVE -> {
                paint.style = Paint.Style.FILL
                paint.color = litWorldColor(Color.argb(68, 144, 198, 116), Color.argb(68, 72, 90, 68))
                canvas.drawOval(RectF(s.first - r * 0.92f, s.second + r * 0.18f, s.first + r * 0.92f, s.second + r * 0.70f), paint)
                drawBitmapCentered(canvas, sacredGroveSprite, s.first, s.second + r * 0.04f, r * 1.8f, r * 1.8f)
            }
        }
    }

    private fun drawObstacle(canvas: Canvas, obstacle: Obstacle) {
        val s = worldToScreen(obstacle.x, obstacle.y)
        val r = obstacle.radius * zoom
        if (!isScreenVisible(s.first, s.second, r + 12f)) return
        val biome = tiles[obstacle.tileKey]?.let(::tileBiome)
        when (obstacle.type) {
            ObstacleType.TREE -> {
                val variants = when (biome) {
                    BiomeType.MISTY_WETLAND -> terrainTreeWetlandVariants
                    BiomeType.HIGHLANDS -> terrainTreePineVariants
                    BiomeType.CANYON -> terrainTreeSavannaVariants
                    BiomeType.CRYSTAL_BARRENS -> terrainTreeJungleVariants
                    BiomeType.RUINS -> if (obstacle.id % 2 == 0) terrainTreeForestVariants else terrainTreePineVariants
                    BiomeType.VERDANT_FOREST, null -> if (obstacle.id % 3 == 0) terrainTreeJungleVariants else terrainTreeForestVariants
                }
                val sprite = pickVariant(variants, obstacle.id)
                drawBitmapAnchored(canvas, sprite, s.first, s.second, r * 2.95f, r * 2.95f, normalizedAnchorY = 0.94f)
            }
            ObstacleType.ROCK -> {
                val sprite = if (biome == BiomeType.CRYSTAL_BARRENS) terrainCrystalCluster else terrainRock
                drawBitmapAnchored(canvas, sprite, s.first, s.second, r * 2.2f, r * 2.2f, normalizedAnchorY = 0.82f)
            }
            ObstacleType.BUSH -> {
                drawBitmapAnchored(canvas, terrainBush, s.first, s.second, r * 2.3f, r * 2.0f, normalizedAnchorY = 0.80f)
            }
        }
    }

    private fun drawGoo(canvas: Canvas) {
        if (gooPatches.isEmpty()) return

        // Render the biofilm through one shared world-space pixel mask. Each
        // covered cell is drawn once, so connected colonies become one surface
        // instead of darker translucent circles stacked on top of each other.
        val cellWorld = 14f
        val filledCells = HashSet<Long>()

        gooPatches.forEach { patch ->
            val screenCenter = worldToScreen(patch.x, patch.y)
            if (!isScreenVisible(screenCenter.first, screenCenter.second, patch.radius * zoom + 28f)) return@forEach
            val minGX = floor((patch.x - patch.radius - cellWorld) / cellWorld).toInt()
            val maxGX = floor((patch.x + patch.radius + cellWorld) / cellWorld).toInt()
            val minGY = floor((patch.y - patch.radius - cellWorld) / cellWorld).toInt()
            val maxGY = floor((patch.y + patch.radius + cellWorld) / cellWorld).toInt()

            for (gy in minGY..maxGY) {
                for (gx in minGX..maxGX) {
                    val worldX = (gx + 0.5f) * cellWorld
                    val worldY = (gy + 0.5f) * cellWorld
                    val edgeNoise = gooCellNoise(gx, gy) * 7f
                    if (distance(worldX, worldY, patch.x, patch.y) <= patch.radius + edgeNoise) {
                        val tile = tileAtWorld(worldX, worldY)
                        if (tile?.unlocked == true) filledCells += gooCellKey(gx, gy)
                    }
                }
            }
        }

        if (filledCells.isEmpty()) return

        paint.style = Paint.Style.FILL
        paint.color = Color.argb(66, 126, 63, 179)
        filledCells.forEach { key ->
            val gx = (key shr 32).toInt()
            val gy = key.toInt()
            val topLeft = worldToScreen(gx * cellWorld, gy * cellWorld)
            val bottomRight = worldToScreen((gx + 1) * cellWorld, (gy + 1) * cellWorld)
            val left = min(topLeft.first, bottomRight.first)
            val top = min(topLeft.second, bottomRight.second)
            val right = max(topLeft.first, bottomRight.first)
            val bottom = max(topLeft.second, bottomRight.second)
            if (!isScreenVisible((left + right) * 0.5f, (top + bottom) * 0.5f, max(right - left, bottom - top))) return@forEach
            canvas.drawRect(left, top, right + 0.5f, bottom + 0.5f, paint)
        }

        // Draw only exposed edges. This gives the whole connected network one
        // outer border rather than outlining every overlapping growth source.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(1f, 1.3f * zoom)
        paint.color = Color.argb(125, 183, 100, 222)
        filledCells.forEach { key ->
            val gx = (key shr 32).toInt()
            val gy = key.toInt()
            val topLeft = worldToScreen(gx * cellWorld, gy * cellWorld)
            val bottomRight = worldToScreen((gx + 1) * cellWorld, (gy + 1) * cellWorld)
            val left = min(topLeft.first, bottomRight.first)
            val top = min(topLeft.second, bottomRight.second)
            val right = max(topLeft.first, bottomRight.first)
            val bottom = max(topLeft.second, bottomRight.second)
            if (gooCellKey(gx, gy - 1) !in filledCells) canvas.drawLine(left, top, right, top, paint)
            if (gooCellKey(gx, gy + 1) !in filledCells) canvas.drawLine(left, bottom, right, bottom, paint)
            if (gooCellKey(gx - 1, gy) !in filledCells) canvas.drawLine(left, top, left, bottom, paint)
            if (gooCellKey(gx + 1, gy) !in filledCells) canvas.drawLine(right, top, right, bottom, paint)
        }

        // Sparse deterministic orange cells keep the biofilm speckled without
        // becoming denser where two growth sources overlap.
        paint.style = Paint.Style.FILL
        filledCells.forEach { key ->
            val gx = (key shr 32).toInt()
            val gy = key.toInt()
            val hash = gooCellHash(gx, gy)
            if (kotlin.math.abs(hash) % 13 != 0) return@forEach
            val center = worldToScreen((gx + 0.5f) * cellWorld, (gy + 0.5f) * cellWorld)
            val size = max(1f, 2.1f * zoom)
            paint.color = Color.argb(155, 255, 154 + kotlin.math.abs(hash % 24), 52)
            canvas.drawRect(center.first - size, center.second - size, center.first + size, center.second + size, paint)
        }
    }

    private fun gooCellKey(x: Int, y: Int): Long =
        (x.toLong() shl 32) xor (y.toLong() and 0xFFFFFFFFL)

    private fun gooCellHash(x: Int, y: Int): Int =
        (x * 73856093) xor (y * 19349663)

    private fun gooCellNoise(x: Int, y: Int): Float {
        val normalized = (kotlin.math.abs(gooCellHash(x, y)) % 1000) / 999f
        return normalized * 2f - 1f
    }

    private fun drawWaterFeatures(canvas: Canvas) {
        waterFeatures.forEach { water ->
            if (!isTileUnlocked(water.tileKey)) return@forEach
            val a = worldToScreen(water.x1, water.y1)
            val b = worldToScreen(water.x2, water.y2)
            val r = water.radius * zoom
            val dx = b.first - a.first
            val dy = b.second - a.second
            val length = hypot(dx, dy).coerceAtLeast(1f)
            val nx = -dy / length
            val ny = dx / length
            val midX = (a.first + b.first) * 0.5f
            val midY = (a.second + b.second) * 0.5f
            val curve = ((water.id % 3) - 1) * r * 0.55f
            if (water.type == WaterType.LAKE) {
                // Soft shoreline blend under the lake for cleaner transitions.
                paint.style = Paint.Style.FILL
                paint.color = litWorldColor(Color.argb(70, 192, 214, 174), Color.argb(70, 72, 92, 74))
                canvas.drawOval(RectF(a.first - r * 1.18f, a.second - r * 0.96f,
                    a.first + r * 1.18f, a.second + r * 0.96f), paint)
                drawBitmapCentered(canvas, terrainLake, a.first, a.second, r * 2.5f, r * 2.1f)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = max(1f, 2.3f * zoom)
                paint.color = Color.argb(122, 208, 246, 255)
                canvas.drawOval(RectF(a.first - r * 0.82f, a.second - r * 0.64f,
                    a.first + r * 0.72f, a.second - r * 0.04f), paint)
                return@forEach
            }

            val controlX = midX + nx * curve
            val controlY = midY + ny * curve

            // Outer bank / shoreline blend so rivers and oceans feel seated
            // into the land instead of painted on top.
            if (water.type == WaterType.RIVER) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = max(5f, r * 2.4f + 12f * zoom)
                paint.color = litWorldColor(Color.argb(96, 182, 204, 150), Color.argb(96, 66, 84, 62))
                path.reset()
                path.moveTo(a.first, a.second)
                path.quadTo(controlX, controlY, b.first, b.second)
                canvas.drawPath(path, paint)
            } else {
                paint.style = Paint.Style.FILL
                paint.color = litWorldColor(Color.argb(90, 182, 204, 170), Color.argb(90, 72, 88, 78))
                canvas.drawCircle(a.first, a.second, r + 10f * zoom, paint)
            }

            paint.color = when (water.type) {
                WaterType.OCEAN -> litWorldColor(Color.rgb(35, 136, 201), Color.rgb(10, 35, 72))
                WaterType.RIVER -> litWorldColor(Color.rgb(65, 174, 218), Color.rgb(15, 48, 80))
                WaterType.LAKE -> litWorldColor(Color.rgb(54, 164, 210), Color.rgb(14, 45, 76))
            }
            if (water.type == WaterType.RIVER) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = max(2f, r * 2f)
                path.reset()
                path.moveTo(a.first, a.second)
                path.quadTo(controlX, controlY, b.first, b.second)
                canvas.drawPath(path, paint)
                paint.strokeWidth = max(1f, 2f * zoom)
                paint.color = Color.argb(120, 185, 238, 255)
                path.reset()
                path.moveTo(a.first - nx * 2.2f * zoom, a.second - ny * 2.2f * zoom)
                path.quadTo(controlX - nx * 1.8f * zoom, controlY - ny * 1.8f * zoom,
                    b.first - nx * 2.2f * zoom, b.second - ny * 2.2f * zoom)
                canvas.drawPath(path, paint)
                // Pixel-ish flow segments and shoreline sparkles.
                paint.style = Paint.Style.FILL
                val segments = 6
                repeat(segments) { index ->
                    val t = (index + 1) / (segments + 1f)
                    val px = quadPoint(a.first, controlX, b.first, t)
                    val py = quadPoint(a.second, controlY, b.second, t)
                    val off = if (index % 2 == 0) 1.8f * zoom else -1.8f * zoom
                    paint.color = Color.argb(126, 222, 248, 255)
                    canvas.drawRect(px - 2.2f * zoom + nx * off, py - 1.2f * zoom + ny * off,
                        px + 2.2f * zoom + nx * off, py + 1.2f * zoom + ny * off, paint)
                }
            } else {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(a.first, a.second, r, paint)
                paint.color = Color.argb(110, 175, 235, 255)
                canvas.drawOval(RectF(a.first - r * 0.55f, a.second - r * 0.52f,
                    a.first + r * 0.18f, a.second - r * 0.25f), paint)
                if (water.type == WaterType.OCEAN) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = max(2f, 3.2f * zoom)
                    paint.color = Color.argb(105, 195, 235, 255)
                    canvas.drawCircle(a.first, a.second, r * 0.82f, paint)
                    paint.color = litWorldColor(Color.argb(86, 224, 222, 178), Color.argb(86, 90, 100, 84))
                    canvas.drawCircle(a.first, a.second, r * 1.16f, paint)
                }
            }
        }
    }

    private fun quadPoint(a: Float, b: Float, c: Float, t: Float): Float {
        val inv = 1f - t
        return inv * inv * a + 2f * inv * t * b + t * t * c
    }

    private fun drawWildAnimal(canvas: Canvas, animal: WildAnimal) {
        if (!isTileUnlocked(animal.tileKey)) return
        val s = worldToScreen(animal.x, animal.y)
        val bob = sin(worldElapsedSeconds * 3f + animal.phase) * 2f * zoom
        when (animal.type) {
            AlienAnimalType.GRAZER -> {
                val size = max(24f, GameScale.CELL * 2.8f * zoom)
                drawBitmapCentered(canvas, wildGrazerSprite, s.first, s.second + bob, size, size)
            }
            AlienAnimalType.HOPPER -> {
                val size = max(22f, GameScale.CELL * 2.2f * zoom)
                drawBitmapCentered(canvas, wildHopperSprite, s.first, s.second + bob, size, size)
            }
            AlienAnimalType.STRIDER -> {
                val width = max(24f, GameScale.CELL * 2.8f * zoom)
                val height = max(28f, GameScale.CELL * 3.2f * zoom)
                drawBitmapCentered(canvas, wildStriderSprite, s.first, s.second + bob, width, height)
            }
        }
    }

    private fun drawEnemyCamp(canvas: Canvas, camp: EnemyCamp) {
        val s = worldToScreen(camp.x, camp.y)
        val drawSize = max(72f, GameScale.ENEMY_CAMP_VISUAL * zoom)
        val r = drawSize * 0.5f
        if (!isScreenVisible(s.first, s.second, drawSize)) return
        drawBitmapCentered(canvas, enemyCampSprite, s.first, s.second + r * 0.08f, drawSize, drawSize * 0.86f)

        if (zoom >= 0.45f) {
            val population = primitiveEnemies.count { it.campId == camp.id }
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = max(7f * density, 8f * density * min(zoom, 1f))
            paint.color = Color.WHITE
            canvas.drawText("CAMP $population/${camp.populationTarget}  ${camp.goldReward}G", s.first, s.second - r * 1.52f, paint)
        }

        val barWidth = r * 2.1f
        val barTop = s.second - r * 1.30f
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(40, 22, 20)
        canvas.drawRect(s.first - barWidth / 2f, barTop, s.first + barWidth / 2f, barTop + max(2f, 4f * zoom), paint)
        paint.color = Color.rgb(224, 92, 58)
        val healthRatio = (camp.health.toFloat() / camp.maxHealth.coerceAtLeast(1)).coerceIn(0f, 1f)
        canvas.drawRect(s.first - barWidth / 2f, barTop,
            s.first - barWidth / 2f + barWidth * healthRatio, barTop + max(2f, 4f * zoom), paint)
    }

    private fun drawPrimitiveEnemy(canvas: Canvas, enemy: PrimitiveEnemy) {
        val s = worldToScreen(enemy.x, enemy.y)
        val size = max(20f, GameScale.SMALL_UNIT_VISUAL * zoom)
        if (!isScreenVisible(s.first, s.second, size)) return
        val dir = enemy.facingDir
        val bob = sin(worldElapsedSeconds * 5f + enemy.phase) * max(0.5f, 1.0f * zoom)
        drawSheetFrame(canvas, primitiveEnemySheet, dir, 4, s.first, s.second + bob, size * 1.15f, size * 1.15f, mirrorX = false)

        if (enemy.state == EnemyState.CHASING || enemy.health < enemy.maxHealth) {
            val barW = max(12f, 24f * zoom)
            val barH = max(2f, 3f * zoom)
            paint.color = Color.rgb(45, 24, 24)
            canvas.drawRect(s.first - barW / 2f, s.second - size * 0.86f,
                s.first + barW / 2f, s.second - size * 0.86f + barH, paint)
            paint.color = Color.rgb(232, 74, 65)
            val healthRatio = (enemy.health.toFloat() / enemy.maxHealth).coerceIn(0f, 1f)
            canvas.drawRect(s.first - barW / 2f, s.second - size * 0.86f,
                s.first - barW / 2f + barW * healthRatio, s.second - size * 0.86f + barH, paint)
        }
    }

    private fun drawCloudShadows(canvas: Canvas) {
        val daylight = daylightStrength()
        if (daylight < 0.08f) return

        val viewport = worldViewportRect()
        val worldLeft = cameraX - viewport.width() / (2f * zoom) - 900f
        val worldRight = cameraX + viewport.width() / (2f * zoom) + 900f
        val worldTop = cameraY - viewport.height() / (2f * zoom) - 650f
        val worldBottom = cameraY + viewport.height() / (2f * zoom) + 650f
        val cellW = 780f
        val cellH = 560f
        val drift = worldElapsedSeconds * 38f
        val startCol = floor((worldLeft - drift) / cellW).toInt() - 1
        val endCol = floor((worldRight - drift) / cellW).toInt() + 1
        val startRow = floor(worldTop / cellH).toInt() - 1
        val endRow = floor(worldBottom / cellH).toInt() + 1

        paint.style = Paint.Style.FILL
        for (row in startRow..endRow) {
            for (col in startCol..endCol) {
                val seed = (col * 73856093) xor (row * 19349663)
                if (abs(seed) % 3 == 0) continue
                val seeded = Random(seed)
                val wx = col * cellW + seeded.nextFloat() * 310f + drift
                val wy = row * cellH + seeded.nextFloat() * 270f + sin(worldElapsedSeconds * 0.10f + seed) * 65f
                if (wy < worldTop - cellH || wy > worldBottom + cellH) continue

                val screen = worldToScreen(wx, wy)
                val worldSize = 155f + seeded.nextFloat() * 150f
                val widthPx = worldSize * zoom
                val heightPx = worldSize * 0.42f * zoom
                val alpha = (32f * daylight).roundToInt().coerceIn(0, 42)
                paint.color = Color.argb(alpha, 38, 67, 77)
                canvas.drawOval(RectF(screen.first - widthPx, screen.second - heightPx,
                    screen.first + widthPx, screen.second + heightPx), paint)
                canvas.drawOval(RectF(screen.first - widthPx * 0.58f, screen.second - heightPx * 1.55f,
                    screen.first + widthPx * 0.12f, screen.second + heightPx * 0.65f), paint)
                canvas.drawOval(RectF(screen.first - widthPx * 0.05f, screen.second - heightPx * 1.30f,
                    screen.first + widthPx * 0.72f, screen.second + heightPx * 0.72f), paint)
            }
        }
    }

    private fun drawNightOverlay(canvas: Canvas) {
        val night = 1f - daylightStrength()
        if (night <= 0.04f) return
        paint.style = Paint.Style.FILL
        val alpha = (night * 138f).roundToInt().coerceIn(0, 150)
        paint.color = Color.argb(alpha, 12, 24, 56)
        canvas.drawRect(worldViewportRect(), paint)
    }

    private fun dayPhase(): Float = (startingDayPhase + worldElapsedSeconds / dayLengthSeconds) % 1f

    private fun daylightStrength(): Float {
        val raw = ((sin(dayPhase() * 6.28318f - 1.5708f) + 1f) * 0.5f).coerceIn(0f, 1f)
        return raw * raw * (3f - 2f * raw)
    }

    private fun worldBackgroundColor(): Int = litWorldColor(
        Color.rgb(146, 211, 116),
        Color.rgb(10, 22, 37),
    )

    private fun litWorldColor(dayColor: Int, nightColor: Int): Int =
        blendColor(nightColor, dayColor, 0.12f + daylightStrength() * 0.88f)

    private fun blendColor(from: Int, to: Int, amount: Float): Int {
        val t = amount.coerceIn(0f, 1f)
        val r = (Color.red(from) + (Color.red(to) - Color.red(from)) * t).roundToInt()
        val g = (Color.green(from) + (Color.green(to) - Color.green(from)) * t).roundToInt()
        val b = (Color.blue(from) + (Color.blue(to) - Color.blue(from)) * t).roundToInt()
        return Color.rgb(r, g, b)
    }

    private fun drawBuildGhost(canvas: Canvas) {
        val type = buildPlacementType ?: return
        val x = ghostBuildX ?: return
        val y = ghostBuildY ?: return
        val screen = worldToScreen(x, y)
        val radius = when (type) {
            BuildingType.BIOSPEWER -> GameScale.BIOSPEWER_FOOTPRINT_RADIUS
            BuildingType.NEST_WATCHER -> GameScale.WATCHER_FOOTPRINT_RADIUS
        } * zoom
        val valid = ghostPlacementValid()
        val accent = if (valid) Color.rgb(70, 255, 120) else Color.rgb(255, 75, 75)

        paint.style = Paint.Style.FILL
        paint.color = if (valid) Color.argb(112, 85, 245, 125) else Color.argb(112, 245, 70, 70)
        canvas.drawCircle(screen.first, screen.second, radius, paint)
        if (type == BuildingType.BIOSPEWER) {
            canvas.drawRect(screen.first - radius * 0.52f, screen.second - radius * 0.76f,
                screen.first + radius * 0.52f, screen.second + radius * 0.22f, paint)
        } else {
            canvas.drawRect(screen.first - radius * 0.62f, screen.second - radius * 0.52f,
                screen.first + radius * 0.62f, screen.second + radius * 0.52f, paint)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(2f, 3f * density)
        paint.color = accent
        canvas.drawCircle(screen.first, screen.second, radius + 6f * zoom, paint)
        canvas.drawLine(screen.first - radius * 0.9f, screen.second, screen.first + radius * 0.9f, screen.second, paint)
        canvas.drawLine(screen.first, screen.second - radius * 0.9f, screen.first, screen.second + radius * 0.9f, paint)
    }

    private fun drawWatcherUnit(canvas: Canvas, unit: WatcherUnit) {
        val screen = worldToScreen(unit.x, unit.y)
        val size = max(20f, GameScale.SMALL_UNIT_VISUAL * zoom)
        val dir = unit.facingDir
        if (unit.selected) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1.5f, 2f * density)
            paint.color = Color.YELLOW
            canvas.drawCircle(screen.first, screen.second, size * 0.68f, paint)
        }
        drawSheetFrame(canvas, watcherSheet, dir, 4, screen.first, screen.second, size, size)
    }

    private fun drawNest(canvas: Canvas, activeNest: Nest) {
        val s = worldToScreen(activeNest.x, activeNest.y)
        val visualSize = when {
            activeNest.level >= 5 -> GameScale.NEST_STAGE_3_VISUAL
            activeNest.level >= 3 -> GameScale.NEST_STAGE_2_VISUAL
            else -> GameScale.NEST_STAGE_1_VISUAL
        }
        val drawSize = visualSize * zoom
        val animated = activeNest.level <= 1
        if (animated) {
            val frame = movementFrame(4f, frames = 4)
            drawSheetFrameAnchored(canvas, nestIdleSheet, frame, 4, s.first, s.second, drawSize, drawSize, normalizedAnchorY = 0.92f)
        } else {
            val stageSprite = when {
                activeNest.level >= 5 -> nestStage3Sprite
                activeNest.level >= 3 -> nestStage2Sprite
                else -> nestStage1Sprite
            }
            drawBitmapCentered(canvas, stageSprite, s.first, s.second + drawSize * 0.04f, drawSize, drawSize)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(1.5f, 2f * density)
        paint.color = if (nestMenuOpen) Color.YELLOW else Color.rgb(255, 155, 55)
        canvas.drawCircle(s.first, s.second, GameScale.NEST_SELECTION_RADIUS * zoom, paint)
    }

    private fun drawLarva(canvas: Canvas, larva: Larva) {
        val s = worldToScreen(larva.x, larva.y)
        val size = max(2f, 4f * zoom)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(232, 220, 140)
        canvas.drawRect(s.first - size, s.second - size * 0.65f,
            s.first + size, s.second + size * 0.65f, paint)
    }

    private fun drawDrone(canvas: Canvas, drone: Drone) {
        val activeBuildSite = drone.buildSiteId?.let(::findBuildSite)
        val siteMorphing = activeBuildSite?.let { site ->
            val builders = site.builderDroneIds.mapNotNull(::findDrone)
            builders.isNotEmpty() && builders.all { it.state == DroneState.BUILDING }
        } == true
        if (drone.state == DroneState.BUILDING && siteMorphing) return

        val s = worldToScreen(drone.x, drone.y)
        val directionRow = when (drone.facingDir) {
            0 -> 0 // north
            2 -> 1 // south
            1 -> 2 // east
            else -> 3 // west
        }
        val harvestingTravel = if (drone.state == DroneState.HARVESTING) {
            val node = drone.targetResourceId?.let(::findResource)
            node != null && distance(drone.x, drone.y, node.x, node.y) > resourcePatchRadius(node) * 0.80f
        } else false
        val animationRow = when {
            drone.carryingAmount > 0f && drone.state != DroneState.IDLE -> 12 + directionRow
            drone.state == DroneState.HARVESTING && !harvestingTravel || drone.state == DroneState.BUILDING -> 8 + directionRow
            harvestingTravel || drone.state == DroneState.MOVING || drone.state == DroneState.RETURNING || drone.state == DroneState.MOVING_TO_BUILD -> 4 + directionRow
            else -> directionRow
        }
        val animationSpeed = when {
            animationRow >= 12 -> 5.5f
            animationRow >= 8 -> 7.5f
            animationRow >= 4 -> 7f
            else -> 3.2f
        }
        val frame = ((worldElapsedSeconds * animationSpeed + drone.id * 0.41f).toInt()).mod(6)
        val spriteSize = max(36f, GameScale.DRONE_VISUAL * 1.60f * zoom)
        paint.style = Paint.Style.FILL
        drawGridSheetFrameAnchored(
            canvas,
            workerDroneSheet,
            frame,
            animationRow,
            columns = 7,
            rows = 18,
            anchorX = s.first,
            anchorY = s.second,
            widthPx = spriteSize,
            heightPx = spriteSize,
        )

        if (drone.carryingAmount > 0f) {
            paint.color = if (drone.carryingType == ResourceType.MINERAL)
                Color.rgb(50, 135, 255) else Color.rgb(55, 220, 90)
            val cargo = max(2f, 4f * zoom)
            canvas.drawRect(s.first - cargo, s.second - spriteSize * 0.54f - cargo,
                s.first + cargo, s.second - spriteSize * 0.54f + cargo, paint)
        }
        if (drone.selected) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1f, density)
            paint.color = Color.YELLOW
            canvas.drawCircle(s.first, s.second, spriteSize * 0.48f, paint)
        }
    }

    private fun drawResource(canvas: Canvas, node: ResourceNode) {
        val s = worldToScreen(node.x, node.y)
        val fullness = (node.amount / node.maxAmount.coerceAtLeast(1f)).coerceIn(0.18f, 1f)
        val tierScale = if (node.richnessTier >= 2) 1.28f else 1f
        val baseSize = GameScale.RESOURCE_VISUAL * zoom * tierScale * (0.82f + fullness * 0.18f)
        val r = baseSize * 0.5f
        val sprite = if (node.type == ResourceType.MINERAL) mineralFieldSprite else gasFieldSprite
        paint.style = Paint.Style.FILL
        val groundColor = when (node.type) {
            ResourceType.MINERAL -> litWorldColor(Color.argb(74, 88, 104, 118), Color.argb(74, 44, 54, 66))
            ResourceType.GAS -> litWorldColor(Color.argb(86, 78, 70, 118), Color.argb(86, 34, 28, 66))
        }
        paint.color = groundColor
        canvas.drawOval(RectF(s.first - r * 1.05f, s.second + r * 0.30f, s.first + r * 1.05f, s.second + r * 0.88f), paint)
        if (node.type == ResourceType.GAS) {
            paint.color = litWorldColor(Color.argb(72, 90, 255, 210), Color.argb(72, 44, 120, 102))
            canvas.drawOval(RectF(s.first - r * 0.95f, s.second - r * 0.12f, s.first + r * 0.95f, s.second + r * 0.58f), paint)
        }
        drawBitmapCentered(canvas, sprite, s.first, s.second + r * 0.06f, baseSize, baseSize)

        if (zoom >= 0.34f && (!node.clustered || zoom >= 0.82f)) {
            val amountText = node.amount.roundToInt().coerceAtLeast(0).toString()
            val top = s.second - r - 12f * density
            val textSize = max(8.5f * density, 12f * zoom)
            drawOutlinedText(canvas, amountText, s.first, top, textSize, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 2f * density)
            if (node.richnessTier >= 2 && zoom >= 0.58f) {
                drawOutlinedText(canvas, "RICH", s.first, top - 12f * density, max(6.8f * density, 8.6f * zoom), fillColor = Color.rgb(255, 206, 74), align = Paint.Align.CENTER, strokeWidth = 1.7f * density)
            }
        }
    }

    private fun drawBuildSite(canvas: Canvas, site: BuildSite) {
        val s = worldToScreen(site.x, site.y)
        val footprint = when (site.type) {
            BuildingType.BIOSPEWER -> GameScale.BIOSPEWER_FOOTPRINT_RADIUS
            BuildingType.NEST_WATCHER -> GameScale.WATCHER_FOOTPRINT_RADIUS
        }
        val r = footprint * zoom
        val builders = site.builderDroneIds.mapNotNull(::findDrone)
        val allReady = builders.isNotEmpty() && builders.all { it.state == DroneState.BUILDING }

        if (allReady) {
            val frame = (site.progress.coerceIn(0f, 0.999f) * 7f).toInt().coerceIn(0, 6)
            val morphSize = when (site.type) {
                BuildingType.BIOSPEWER -> max(GameScale.BIOSPEWER_WIDTH, GameScale.BIOSPEWER_HEIGHT) * 1.08f * zoom
                BuildingType.NEST_WATCHER -> max(GameScale.WATCHER_WIDTH, GameScale.WATCHER_HEIGHT) * 1.08f * zoom
            }
            drawGridSheetFrameAnchored(
                canvas,
                workerDroneSheet,
                column = frame,
                row = 17,
                columns = 7,
                rows = 18,
                anchorX = s.first,
                anchorY = s.second,
                widthPx = morphSize,
                heightPx = morphSize,
            )
        } else {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1.5f, 2f * density)
            paint.color = if (site.type == BuildingType.BIOSPEWER)
                Color.rgb(245, 80, 180) else Color.rgb(135, 205, 255)
            canvas.drawLine(s.first - r, s.second - r, s.first + r, s.second + r, paint)
            canvas.drawLine(s.first + r, s.second - r, s.first - r, s.second + r, paint)
        }

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(1.5f, 2f * density)
        paint.color = if (site.type == BuildingType.BIOSPEWER)
            Color.rgb(245, 80, 180) else Color.rgb(135, 205, 255)
        canvas.drawCircle(s.first, s.second, r, paint)
        paint.style = Paint.Style.FILL
        paint.color = if (site.type == BuildingType.BIOSPEWER)
            Color.rgb(245, 80, 180) else Color.rgb(135, 205, 255)
        val width = footprint * 1.8f * zoom
        paint.color = Color.argb(180, 16, 18, 24)
        canvas.drawRect(s.first - width / 2f, s.second + r + 4f * zoom,
            s.first + width / 2f, s.second + r + 8f * zoom, paint)
        paint.color = if (site.type == BuildingType.BIOSPEWER)
            Color.rgb(245, 80, 180) else Color.rgb(135, 205, 255)
        canvas.drawRect(s.first - width / 2f, s.second + r + 4f * zoom,
            s.first - width / 2f + width * site.progress.coerceIn(0f, 1f),
            s.second + r + 8f * zoom, paint)
    }

    private fun drawBiospewer(canvas: Canvas, spewer: Biospewer) {
        val s = worldToScreen(spewer.x, spewer.y)
        val frame = movementFrame(4f, phase = spewer.id * 0.13f, frames = 4)
        drawSheetFrameAnchored(
            canvas,
            biospewerIdleSheet,
            frame,
            4,
            s.first,
            s.second,
            GameScale.BIOSPEWER_WIDTH * zoom,
            GameScale.BIOSPEWER_HEIGHT * zoom,
            normalizedAnchorY = 0.92f,
        )
    }

    private fun drawNestWatcher(canvas: Canvas, watcher: NestWatcher) {
        val s = worldToScreen(watcher.x, watcher.y)
        val drawW = GameScale.WATCHER_WIDTH * zoom
        val drawH = GameScale.WATCHER_HEIGHT * zoom
        drawBitmapCentered(canvas, nestWatcherSprite, s.first, s.second + drawH * 0.05f, drawW, drawH)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = max(1.5f, density)
        paint.color = if (selectedWatcherId == watcher.id) Color.YELLOW else Color.rgb(135, 215, 255)
        canvas.drawCircle(s.first, s.second, GameScale.WATCHER_FOOTPRINT_RADIUS * zoom, paint)
    }

    private fun drawDefender(canvas: Canvas, defender: Defender) {
        val s = worldToScreen(defender.x, defender.y)
        val dir = animationDirectionRow(defender.facingDir)
        val size = max(22f, GameScale.GUARD_VISUAL * zoom)
        val row = if (defender.hasMoveOrder) 4 + dir else dir
        val frame = ((worldElapsedSeconds * (if (defender.hasMoveOrder) 6.5f else 3.6f) + defender.id * 0.23f).toInt()).mod(6)
        drawGridSheetFrameAnchored(
            canvas,
            spitterSheet,
            frame,
            row,
            columns = 6,
            rows = 9,
            anchorX = s.first,
            anchorY = s.second,
            widthPx = size * 1.18f,
            heightPx = size * 1.18f,
            normalizedAnchorY = 0.90f,
        )
        if (defender.selected) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1f, density)
            paint.color = Color.YELLOW
            canvas.drawCircle(s.first, s.second, size * 0.62f, paint)
        }
    }

    private fun drawHatchling(canvas: Canvas, hatchling: Hatchling) {
        val s = worldToScreen(hatchling.x, hatchling.y)
        val size = max(18f, GameScale.SMALL_UNIT_VISUAL * zoom)
        val dir = animationDirectionRow(hatchling.facingDir)
        val bob = if (hatchling.hasMoveOrder) {
            sin(worldElapsedSeconds * 7f + hatchling.id) * max(0.5f, 0.8f * zoom)
        } else 0f
        val attacking = hatchling.attackCooldown > 0.18f
        val row = when {
            attacking -> 7 + dir
            hatchling.hasMoveOrder -> 4 + if (dir == 3) 2 else dir
            else -> dir
        }
        val frame = if (attacking) {
            (((0.45f - hatchling.attackCooldown).coerceIn(0f, 0.44f) / 0.45f) * 6f).toInt().coerceIn(0, 5)
        } else {
            ((worldElapsedSeconds * (if (hatchling.hasMoveOrder) 7f else 4f) + hatchling.id * 0.37f).toInt()).mod(6)
        }
        drawGridSheetFrameAnchored(
            canvas,
            hatchlingSheet,
            frame,
            row,
            columns = 8,
            rows = 14,
            anchorX = s.first,
            anchorY = s.second + bob,
            widthPx = size * 1.22f,
            heightPx = size * 1.22f,
            normalizedAnchorY = 0.90f,
            mirrorX = hatchling.hasMoveOrder && dir == 3,
        )
        if (hatchling.selected) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1f, density)
            paint.color = Color.YELLOW
            canvas.drawCircle(s.first, s.second, size * 0.65f, paint)
        }
    }

    private fun drawSpreader(canvas: Canvas, spreader: Spreader) {
        val s = worldToScreen(spreader.x, spreader.y)
        val r = max(20f, GameScale.SPREADER_VISUAL * zoom)
        val dir = animationDirectionRow(spreader.facingDir)
        val mobileSize = r * 1.12f
        val rootedSize = r * 1.55f
        val bob = if (spreader.state == SpreaderState.RELOCATING || spreader.state == SpreaderState.MOVING_TO_BURROW) {
            sin(worldElapsedSeconds * 6.5f + spreader.id) * max(0.4f, 0.8f * zoom)
        } else 0f

        when (spreader.state) {
            SpreaderState.IDLE -> {
                val frame = ((worldElapsedSeconds * 3.6f + spreader.id * 0.31f).toInt()).mod(6)
                drawGridSheetFrameAnchored(
                    canvas,
                    spreaderIdleSheet,
                    frame,
                    dir,
                    columns = 6,
                    rows = 4,
                    anchorX = s.first,
                    anchorY = s.second,
                    widthPx = mobileSize,
                    heightPx = mobileSize,
                    normalizedAnchorY = 0.90f,
                )
            }
            SpreaderState.RELOCATING, SpreaderState.MOVING_TO_BURROW -> {
                val row = 4 + if (dir == 3) 2 else dir
                val frame = ((worldElapsedSeconds * 6.6f + spreader.id * 0.29f).toInt()).mod(6)
                drawGridSheetFrameAnchored(
                    canvas,
                    spreaderMoveSheet,
                    frame,
                    row - 4,
                    columns = 6,
                    rows = 3,
                    anchorX = s.first,
                    anchorY = s.second + bob,
                    widthPx = mobileSize,
                    heightPx = mobileSize,
                    normalizedAnchorY = 0.90f,
                    mirrorX = dir == 3,
                )
            }
            SpreaderState.BURROWING -> {
                val frame = ((spreader.burrowTimer / 2.1f) * 7f).toInt().coerceIn(0, 6)
                drawSheetFrameAnchored(
                    canvas,
                    spreaderBurrowSheet,
                    frame,
                    7,
                    s.first,
                    s.second + r * 0.06f,
                    rootedSize,
                    rootedSize,
                    normalizedAnchorY = 0.90f,
                )
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = max(1f, 2f * zoom)
                paint.color = Color.rgb(255, 170, 70)
                canvas.drawCircle(s.first, s.second, r * (1.28f + spreader.burrowTimer * 0.18f), paint)
            }
            SpreaderState.BURROWED -> {
                val pulsing = spreader.spreadPulseTimer < 1.45f
                val sheet = if (pulsing) spreaderPulseSheet else spreaderRootedIdleSheet
                val frame = if (pulsing) {
                    ((spreader.spreadPulseTimer / 1.45f) * 5f).toInt().coerceIn(0, 4)
                } else {
                    ((worldElapsedSeconds * 2.2f + spreader.id * 0.17f).toInt()).mod(5)
                }
                drawSheetFrameAnchored(
                    canvas,
                    sheet,
                    frame,
                    5,
                    s.first,
                    s.second + r * 0.08f,
                    rootedSize,
                    rootedSize,
                    normalizedAnchorY = 0.90f,
                )
            }
        }
        if (spreader.selected) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = max(1f, density)
            paint.color = Color.YELLOW
            canvas.drawCircle(s.first, s.second, r * 0.72f, paint)
        }
    }

    private fun drawSelectionRing(canvas: Canvas) {
        if (!selectionRingActive) return
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f * density
        paint.color = Color.YELLOW
        canvas.drawCircle(touchDownX, touchDownY, selectionRingRadius, paint)
    }

    private fun drawUi(canvas: Canvas) {
        if (appScreen == AppScreen.MAIN_MENU) {
            drawMainMenu(canvas)
            return
        }
        if (appScreen == AppScreen.WORLD_SETUP) {
            drawWorldSetupMenu(canvas)
            return
        }
        if (appScreen == AppScreen.BIOBOOK) {
            drawBioBookMenu(canvas)
            return
        }
        if (appScreen == AppScreen.SETTINGS) {
            drawSettingsMenu(canvas)
            return
        }
        drawSidebar(canvas)
        drawZoomControls(canvas)
        drawTimeIndicator(canvas)
        drawInspectCard(canvas)
        when {
            nestMenuOpen && nest != null -> drawNestMenu(canvas)
            selectedWatcherId != null -> drawWatcherMenu(canvas)
            selectedBarrierKey != null -> drawBarrierMenu(canvas)
            buildPlacementType != null -> drawBuildPlacementMenu(canvas)
            buildMenuOpen -> drawBuildCatalogMenu(canvas)
            shopMenuOpen -> drawShopMenu(canvas)
            anyUnitsSelected() -> drawUnitSelectionMenu(canvas)
        }
        drawMessage(canvas)
    }

    private fun drawMainMenu(canvas: Canvas) {
        canvas.drawColor(Color.rgb(6, 7, 10))

        val titleWidth = width * if (isPortrait) 0.72f else 0.48f
        val titleHeight = titleWidth * uiTitleSprite.height / uiTitleSprite.width.toFloat()
        val titleRect = RectF(
            width * 0.5f - titleWidth * 0.5f,
            height * 0.055f,
            width * 0.5f + titleWidth * 0.5f,
            height * 0.055f + titleHeight,
        )
        drawBitmapContain(canvas, uiTitleSprite, titleRect)
        drawOutlinedText(canvas, "Seeded bio-colony strategy prototype", width * 0.5f, titleRect.bottom + 7f * density, 8.5f * density, fillColor = Color.LTGRAY, align = Paint.Align.CENTER, strokeWidth = 1.8f * density)

        val buttons = mainMenuButtonRects()
        buttons.forEachIndexed { index, rect ->
            when (index) {
                0 -> drawBitmapContain(canvas, uiPlayIdleSprite, rect)
                1 -> {
                    drawBitmapFit(canvas, uiDayStripV2, rect)
                    drawOutlinedText(canvas, "BIOBOOK", rect.centerX(), rect.centerY() + 5f * density, 12f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 2.2f * density)
                }
                2 -> drawBitmapContain(canvas, uiSettingsIdleSprite, rect)
                else -> drawBitmapContain(canvas, uiExitIdleSprite, rect)
            }
        }

        val seedWidth = min(width * 0.70f, 300f * density)
        val seedHeight = max(30f * density, seedWidth * uiDayStripV2.height / uiDayStripV2.width.toFloat())
        val seedRect = RectF(width * 0.5f - seedWidth * 0.5f, buttons.last().bottom + 10f * density, width * 0.5f + seedWidth * 0.5f, buttons.last().bottom + 10f * density + seedHeight)
        drawBitmapContain(canvas, uiDayStripV2, seedRect)
        drawOutlinedText(canvas, "NEXT WORLD  $setupSeedText", seedRect.centerX(), seedRect.centerY() + 3f * density, 9f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 1.8f * density)
        drawOutlinedText(canvas, prototypeVersionLabel, width * 0.5f, seedRect.bottom + 18f * density, 8f * density, fillColor = Color.rgb(210, 220, 230), align = Paint.Align.CENTER, strokeWidth = 1.6f * density)
    }

    private fun drawWorldSetupMenu(canvas: Canvas) {
        canvas.drawColor(Color.rgb(6, 7, 10))
        val panel = worldSetupPanelRect()
        drawReadablePanel(
            canvas,
            panel,
            Color.rgb(138, 104, 220),
            fillColor = Color.argb(245, 8, 10, 16),
            corner = 14f * density,
            lineWidth = 2.2f * density,
        )

        val titleWidth = panel.width() * 0.66f
        val titleHeight = titleWidth * uiTitleSprite.height / uiTitleSprite.width.toFloat()
        val titleRect = RectF(
            panel.centerX() - titleWidth * 0.5f,
            panel.top + 10f * density,
            panel.centerX() + titleWidth * 0.5f,
            panel.top + 10f * density + titleHeight,
        )
        drawBitmapContain(canvas, uiTitleSprite, titleRect)
        drawOutlinedText(canvas, "CREATE WORLD", panel.centerX(), titleRect.bottom + 14f * density, 13f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 2.3f * density)

        val rects = worldSetupRects()
        drawOutlinedText(canvas, "MAP NAME", rects.nameField.left, rects.nameField.top - 6f * density, 8.2f * density, fillColor = Color.rgb(202, 190, 244), strokeWidth = 1.7f * density)
        drawReadablePanel(canvas, rects.nameField, Color.rgb(138, 104, 220), Color.argb(236, 10, 12, 18), corner = 9f * density)
        drawOutlinedText(canvas, setupWorldName, rects.nameField.left + 12f * density, rects.nameField.centerY() + 4f * density, 10f * density, fillColor = Color.WHITE, strokeWidth = 1.9f * density)

        drawOutlinedText(canvas, "MAP SIZE", rects.sizeButtons.first().left, rects.sizeButtons.first().top - 6f * density, 8.2f * density, fillColor = Color.rgb(202, 190, 244), strokeWidth = 1.7f * density)
        rects.sizeButtons.forEachIndexed { index, rect ->
            val size = MapSize.entries[index]
            val selected = size == selectedMapSize
            drawReadablePanel(
                canvas,
                rect,
                if (selected) Color.rgb(255, 174, 76) else Color.rgb(126, 174, 230),
                if (selected) Color.argb(242, 31, 19, 13) else Color.argb(230, 10, 12, 18),
                corner = 9f * density,
            )
            drawOutlinedText(canvas, size.label, rect.centerX(), rect.top + rect.height() * 0.42f, 9.2f * density, fillColor = if (selected) Color.rgb(255, 202, 106) else Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 1.9f * density)
            drawOutlinedText(canvas, size.note, rect.centerX(), rect.top + rect.height() * 0.73f, 6.8f * density, fillColor = Color.LTGRAY, align = Paint.Align.CENTER, strokeWidth = 1.4f * density)
        }

        drawOutlinedText(canvas, "WORLD SEED", rects.seedField.left, rects.seedField.top - 6f * density, 8.2f * density, fillColor = Color.rgb(202, 190, 244), strokeWidth = 1.7f * density)
        drawReadablePanel(canvas, rects.seedField, Color.rgb(138, 104, 220), Color.argb(236, 10, 12, 18), corner = 9f * density)
        drawOutlinedText(canvas, setupSeedText, rects.seedField.left + 12f * density, rects.seedField.centerY() + 4f * density, 10f * density, fillColor = Color.WHITE, strokeWidth = 1.9f * density)
        drawReadablePanel(canvas, rects.randomButton, Color.rgb(255, 174, 76), Color.argb(238, 20, 15, 10), corner = 9f * density)
        drawOutlinedText(canvas, "RANDOM", rects.randomButton.centerX(), rects.randomButton.centerY() + 4f * density, 8.2f * density, fillColor = Color.rgb(255, 210, 112), align = Paint.Align.CENTER, strokeWidth = 1.8f * density)

        drawBitmapContain(canvas, uiPlayIdleSprite, rects.createButton)
        drawBitmapContain(canvas, uiBtnBackV2, rects.backButton)

        drawOutlinedText(
            canvas,
            "${selectedMapSize.label}  •  ${selectedMapSize.note}  •  HEX RADIUS 3072U",
            panel.centerX(),
            panel.bottom - 11f * density,
            7.2f * density,
            fillColor = Color.rgb(190, 220, 255),
            align = Paint.Align.CENTER,
            strokeWidth = 1.5f * density,
        )
    }

    private fun drawBioBookMenu(canvas: Canvas) {
        canvas.drawColor(Color.rgb(6, 7, 10))
        val panel = bioBookPanelRect()
        drawReadablePanel(canvas, panel, Color.rgb(132, 104, 220), Color.argb(244, 8, 10, 16), corner = 14f * density, lineWidth = 2.2f * density)
        val decoration = RectF(panel.left + 6f * density, panel.top + 4f * density, panel.right - 6f * density, panel.top + panel.height() * 0.40f)
        drawBitmapContain(canvas, uiPanelLargeV2, decoration, 205)

        drawOutlinedText(
            canvas,
            "BIOBOOK",
            panel.centerX(),
            panel.top + 22f * density,
            16f * density,
            fillColor = Color.WHITE,
            align = Paint.Align.CENTER,
            strokeWidth = 2.6f * density,
        )
        drawOutlinedText(
            canvas,
            "Colony records, wildlife, flora, and inhabitants",
            panel.centerX(),
            panel.top + 39f * density,
            8f * density,
            fillColor = Color.LTGRAY,
            align = Paint.Align.CENTER,
            strokeWidth = 1.6f * density,
        )

        val tabs = bioBookTabRects()
        BioBookSection.entries.forEachIndexed { index, section ->
            val rect = tabs[index]
            val selected = section == bioBookSection
            drawReadablePanel(
                canvas,
                rect,
                if (selected) Color.rgb(255, 174, 76) else Color.rgb(132, 104, 220),
                if (selected) Color.argb(244, 31, 19, 13) else Color.argb(232, 10, 12, 18),
                corner = 8f * density,
            )
            drawOutlinedText(
                canvas,
                section.label,
                rect.centerX(),
                rect.centerY() + 3f * density,
                if (section.label.length > 9) 6.7f * density else 7.8f * density,
                fillColor = if (selected) Color.rgb(255, 210, 112) else Color.WHITE,
                align = Paint.Align.CENTER,
                strokeWidth = 1.6f * density,
            )
        }

        val entries = bioBookEntries(bioBookSection)
        val cards = bioBookCardRects(entries.size)
        entries.forEachIndexed { index, entry ->
            drawBioBookEntry(canvas, cards[index], entry)
        }

        val back = bioBookBackRect()
        drawBitmapContain(canvas, uiBtnBackV2, back)
        drawOutlinedText(canvas, prototypeVersionLabel, panel.right - 10f * density, panel.bottom - 10f * density, 7.6f * density, fillColor = Color.LTGRAY, align = Paint.Align.RIGHT, strokeWidth = 1.4f * density)
    }

    private fun bioBookEntries(section: BioBookSection): List<BioBookEntry> = when (section) {
        BioBookSection.UNITS -> listOf(
            BioBookEntry("Worker Drone", "Harvests, builds, and carries resources.", workerDroneSheet, 1),
            BioBookEntry("Watch Unit", "Fast scout produced by a NestWatcher.", watcherSheet, 2),
            BioBookEntry("Spitter Guard", "Ranged colony defender.", spitterSheet, 3),
            BioBookEntry("Hatchling", "Fast and fragile swarm attacker.", hatchlingSheet, 4),
            BioBookEntry("Spreader", "Mobile unit that roots into biofilm.", spreaderIdleSheet, 5),
        )
        BioBookSection.STRUCTURES -> listOf(
            BioBookEntry("Bionest", "Colony heart and resource drop-off.", nestIdleSheet, 6),
            BioBookEntry("Biospewer", "Produces guards and hatchlings.", biospewerIdleSheet, 7),
            BioBookEntry("NestWatcher", "Raises worker capacity and scouts.", nestWatcherSprite, 0),
            BioBookEntry("Rooted Spreader", "Permanent biofilm growth node.", spreaderRootedIdleSheet, 9),
        )
        BioBookSection.FAUNA -> listOf(
            BioBookEntry("Alien Grazer", "Peaceful roaming herbivore.", wildGrazerSprite, 0),
            BioBookEntry("Alien Hopper", "Small energetic native animal.", wildHopperSprite, 0),
            BioBookEntry("Reed Strider", "Tall wetland roaming creature.", wildStriderSprite, 0),
        )
        BioBookSection.FLORA -> listOf(
            BioBookEntry("Forest Tree", "Dense trunk blocks movement.", terrainTreeForest, 0),
            BioBookEntry("Wetland Tree", "Water-loving native growth.", terrainTreeWetland, 0),
            BioBookEntry("Brush Cluster", "Low organic ground cover.", terrainBush, 0),
            BioBookEntry("Stone Outcrop", "Hard natural terrain obstacle.", terrainRock, 0),
            BioBookEntry("Crystal Cluster", "Mineral-rich alien formation.", terrainCrystalCluster, 0),
        )
        BioBookSection.INHABITANTS -> listOf(
            BioBookEntry("Primitive Hunter", "Defends native camps from the colony.", primitiveEnemySheet, 8),
            BioBookEntry("Primitive Camp", "Hostile settlement and gold reward.", enemyCampSprite, 0),
        )
    }

    private fun drawBioBookEntry(canvas: Canvas, rect: RectF, entry: BioBookEntry) {
        drawReadablePanel(canvas, rect, Color.rgb(132, 104, 220), Color.argb(234, 9, 11, 17), corner = 9f * density)
        val artRect = RectF(rect.left + 7f * density, rect.top + 6f * density, rect.right - 7f * density, rect.top + rect.height() * 0.62f)
        val artSize = min(artRect.width(), artRect.height()) * 0.86f
        when (entry.artMode) {
            1 -> drawGridSheetFrameAnchored(canvas, entry.art, 0, 0, 7, 18, artRect.centerX(), artRect.bottom - 2f * density, artSize, artSize, normalizedAnchorY = 0.90f)
            2 -> drawSheetFrameAnchored(canvas, entry.art, 0, 4, artRect.centerX(), artRect.bottom - 2f * density, artSize, artSize, normalizedAnchorY = 0.90f)
            3 -> drawGridSheetFrameAnchored(canvas, entry.art, 0, 0, 6, 9, artRect.centerX(), artRect.bottom - 2f * density, artSize, artSize, normalizedAnchorY = 0.90f)
            4 -> drawGridSheetFrameAnchored(canvas, entry.art, 0, 0, 8, 14, artRect.centerX(), artRect.bottom - 2f * density, artSize, artSize, normalizedAnchorY = 0.90f)
            5 -> drawGridSheetFrameAnchored(canvas, entry.art, 0, 0, 6, 4, artRect.centerX(), artRect.bottom - 2f * density, artSize, artSize, normalizedAnchorY = 0.90f)
            6, 7 -> drawSheetFrameAnchored(canvas, entry.art, 0, 4, artRect.centerX(), artRect.bottom - 2f * density, artSize, artSize, normalizedAnchorY = 0.92f)
            8 -> drawSheetFrameAnchored(canvas, entry.art, 0, 4, artRect.centerX(), artRect.bottom - 2f * density, artSize, artSize, normalizedAnchorY = 0.90f)
            9 -> drawGridSheetFrameAnchored(canvas, entry.art, 0, 0, 5, 1, artRect.centerX(), artRect.bottom - 2f * density, artSize, artSize, normalizedAnchorY = 0.90f)
            else -> drawBitmapContain(canvas, entry.art, artRect)
        }
        drawOutlinedText(canvas, entry.title.uppercase(), rect.centerX(), rect.top + rect.height() * 0.73f, 8.3f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 1.7f * density)
        wrapText(entry.subtitle, if (isPortrait) 23 else 28, 2).forEachIndexed { lineIndex, line ->
            drawOutlinedText(canvas, line, rect.centerX(), rect.top + rect.height() * 0.84f + lineIndex * 8f * density, 6.6f * density, fillColor = Color.LTGRAY, align = Paint.Align.CENTER, strokeWidth = 1.3f * density)
        }
    }

    private fun drawSettingsMenu(canvas: Canvas) {
        canvas.drawColor(Color.rgb(6, 7, 10))
        val panel = settingsPanelRect()
        drawBitmapContain(canvas, uiPanelLargeV2, panel)

        drawOutlinedText(canvas, "SETTINGS", panel.centerX(), panel.top + panel.height() * 0.16f, 14f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 2.4f * density)
        drawOutlinedText(canvas, worldName.uppercase(), panel.centerX(), panel.top + panel.height() * 0.31f, 9.4f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 1.8f * density)
        drawOutlinedText(canvas, "SEED $worldSeed", panel.centerX(), panel.top + panel.height() * 0.41f, 7.8f * density, fillColor = Color.LTGRAY, align = Paint.Align.CENTER, strokeWidth = 1.5f * density)
        drawOutlinedText(canvas, "${selectedMapSize.label} MAP  •  ${selectedMapSize.note}  •  HEX 3072U", panel.centerX(), panel.top + panel.height() * 0.50f, 7.1f * density, fillColor = Color.rgb(190, 220, 255), align = Paint.Align.CENTER, strokeWidth = 1.4f * density)

        val buttons = settingsButtonRects()
        drawBitmapFit(canvas, uiDayStripV2, buttons[0])
        drawOutlinedText(canvas, "WORLD SETUP", buttons[0].centerX(), buttons[0].centerY() + 4f * density, 9.2f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 1.8f * density)
        drawBitmapContain(canvas, uiBtnBackV2, buttons[1])

        drawOutlinedText(canvas, prototypeVersionLabel, panel.right - 10f * density, panel.bottom - 8f * density, 7.4f * density, fillColor = Color.rgb(215, 226, 235), align = Paint.Align.RIGHT, strokeWidth = 1.4f * density)
    }

    private fun drawPanel(canvas: Canvas, rect: RectF, accent: Int) {
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(220, 15, 18, 20)
        canvas.drawRect(rect, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.8f * density
        paint.color = accent
        canvas.drawRect(rect, paint)
    }

    private fun drawReadablePanel(
        canvas: Canvas,
        rect: RectF,
        accent: Int,
        fillColor: Int = Color.argb(235, 10, 12, 18),
        corner: Float = 10f * density,
        lineWidth: Float = 1.8f * density,
    ) {
        paint.style = Paint.Style.FILL
        paint.color = fillColor
        canvas.drawRoundRect(rect, corner, corner, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = lineWidth
        paint.color = accent
        canvas.drawRoundRect(rect, corner, corner, paint)
        paint.color = Color.argb(120, 235, 240, 250)
        paint.strokeWidth = max(1f, lineWidth * 0.6f)
        val inner = RectF(rect.left + 3f * density, rect.top + 3f * density, rect.right - 3f * density, rect.bottom - 3f * density)
        canvas.drawRoundRect(inner, max(4f * density, corner - 2f * density), max(4f * density, corner - 2f * density), paint)
    }

    private fun drawOutlinedText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        textSize: Float,
        fillColor: Int = Color.WHITE,
        outlineColor: Int = Color.rgb(8, 10, 18),
        align: Paint.Align = Paint.Align.LEFT,
        strokeWidth: Float = 2.2f * density,
    ) {
        if (text.isBlank()) return
        paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        paint.isFakeBoldText = true
        paint.textAlign = align
        paint.textSize = textSize
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = strokeWidth
        paint.color = outlineColor
        canvas.drawText(text, x, y, paint)
        paint.style = Paint.Style.FILL
        paint.color = fillColor
        canvas.drawText(text, x, y, paint)
        paint.isFakeBoldText = false
    }

    private fun drawLabelValueCentered(
        canvas: Canvas,
        rect: RectF,
        label: String,
        value: String,
        labelColor: Int,
        valueColor: Int = Color.WHITE,
    ) {
        drawOutlinedText(
            canvas,
            label,
            rect.centerX(),
            rect.top + rect.height() * 0.33f,
            if (rect.height() < 48f * density) 9.8f * density else 11.2f * density,
            fillColor = labelColor,
            align = Paint.Align.CENTER,
            strokeWidth = 2f * density,
        )
        drawOutlinedText(
            canvas,
            value,
            rect.centerX(),
            rect.top + rect.height() * 0.72f,
            if (rect.height() < 48f * density) 11f * density else 12.8f * density,
            fillColor = valueColor,
            align = Paint.Align.CENTER,
            strokeWidth = 2.1f * density,
        )
    }

    private fun wrapText(text: String, maxCharsPerLine: Int, maxLines: Int = 2): List<String> {
        val words = text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        val lines = mutableListOf<String>()
        var current = ""
        for (word in words) {
            val candidate = if (current.isBlank()) word else "$current $word"
            if (candidate.length <= maxCharsPerLine) {
                current = candidate
            } else {
                if (current.isNotBlank()) lines += current
                current = word
                if (lines.size == maxLines - 1) break
            }
        }
        if (lines.size < maxLines && current.isNotBlank()) lines += current
        if (lines.size > maxLines) return lines.take(maxLines)
        if (words.joinToString(" ").length > lines.joinToString(" ").length && lines.isNotEmpty()) {
            val last = lines.last()
            lines[lines.lastIndex] = if (last.length > maxCharsPerLine - 3) last.take(maxCharsPerLine - 3) + "..." else "$last..."
        }
        return lines
    }

    private fun drawBitmapFit(canvas: Canvas, bitmap: android.graphics.Bitmap, rect: RectF, alpha: Int = 255) {
        val oldAlpha = paint.alpha
        paint.alpha = alpha
        canvas.drawBitmap(bitmap, null, rect, paint)
        paint.alpha = oldAlpha
    }

    private fun drawBitmapContain(canvas: Canvas, bitmap: android.graphics.Bitmap, rect: RectF, alpha: Int = 255) {
        val scale = min(rect.width() / bitmap.width.toFloat(), rect.height() / bitmap.height.toFloat())
        val drawW = bitmap.width * scale
        val drawH = bitmap.height * scale
        val left = rect.centerX() - drawW / 2f
        val top = rect.centerY() - drawH / 2f
        drawBitmapFit(canvas, bitmap, RectF(left, top, left + drawW, top + drawH), alpha)
    }

    private fun drawBitmapCentered(
        canvas: Canvas,
        bitmap: android.graphics.Bitmap,
        centerX: Float,
        centerY: Float,
        widthPx: Float,
        heightPx: Float = widthPx,
        alpha: Int = 255,
    ) {
        drawBitmapFit(canvas, bitmap, RectF(centerX - widthPx / 2f, centerY - heightPx / 2f, centerX + widthPx / 2f, centerY + heightPx / 2f), alpha)
    }

    private fun drawBitmapAnchored(
        canvas: Canvas,
        bitmap: android.graphics.Bitmap,
        anchorX: Float,
        anchorY: Float,
        widthPx: Float,
        heightPx: Float = widthPx,
        normalizedAnchorX: Float = 0.5f,
        normalizedAnchorY: Float = 0.92f,
        alpha: Int = 255,
    ) {
        val left = anchorX - widthPx * normalizedAnchorX
        val top = anchorY - heightPx * normalizedAnchorY
        drawBitmapFit(canvas, bitmap, RectF(left, top, left + widthPx, top + heightPx), alpha)
    }

    private fun drawSheetFrame(
        canvas: Canvas,
        bitmap: android.graphics.Bitmap,
        frameIndex: Int,
        frameCount: Int,
        centerX: Float,
        centerY: Float,
        widthPx: Float,
        heightPx: Float = widthPx,
        mirrorX: Boolean = false,
        alpha: Int = 255,
    ) {
        if (frameCount <= 0) return
        val frameWidth = bitmap.width / frameCount
        val index = frameIndex.coerceIn(0, frameCount - 1)
        val src = Rect(index * frameWidth, 0, (index + 1) * frameWidth, bitmap.height)
        val left = centerX - widthPx / 2f
        val top = centerY - heightPx / 2f
        val right = centerX + widthPx / 2f
        val bottom = centerY + heightPx / 2f
        val oldAlpha = paint.alpha
        paint.alpha = alpha
        if (!mirrorX) {
            canvas.drawBitmap(bitmap, src, RectF(left, top, right, bottom), paint)
        } else {
            canvas.save()
            canvas.scale(-1f, 1f, centerX, centerY)
            canvas.drawBitmap(bitmap, src, RectF(left, top, right, bottom), paint)
            canvas.restore()
        }
        paint.alpha = oldAlpha
    }

    private fun drawGridSheetFrameAnchored(
        canvas: Canvas,
        bitmap: android.graphics.Bitmap,
        column: Int,
        row: Int,
        columns: Int,
        rows: Int,
        anchorX: Float,
        anchorY: Float,
        widthPx: Float,
        heightPx: Float = widthPx,
        normalizedAnchorY: Float = 0.90625f,
        mirrorX: Boolean = false,
        alpha: Int = 255,
    ) {
        if (columns <= 0 || rows <= 0) return
        val frameWidth = bitmap.width / columns
        val frameHeight = bitmap.height / rows
        val safeColumn = column.coerceIn(0, columns - 1)
        val safeRow = row.coerceIn(0, rows - 1)
        val src = Rect(
            safeColumn * frameWidth,
            safeRow * frameHeight,
            (safeColumn + 1) * frameWidth,
            (safeRow + 1) * frameHeight,
        )
        val left = anchorX - widthPx * 0.5f
        val top = anchorY - heightPx * normalizedAnchorY
        val oldAlpha = paint.alpha
        paint.alpha = alpha
        val dest = RectF(left, top, left + widthPx, top + heightPx)
        if (!mirrorX) {
            canvas.drawBitmap(bitmap, src, dest, paint)
        } else {
            canvas.save()
            canvas.scale(-1f, 1f, anchorX, anchorY)
            canvas.drawBitmap(bitmap, src, dest, paint)
            canvas.restore()
        }
        paint.alpha = oldAlpha
    }

    private fun animationDirectionRow(cardinal: Int): Int = when (cardinal) {
        0 -> 0 // north
        2 -> 1 // south
        1 -> 2 // east
        else -> 3 // west
    }

    private fun drawSheetFrameAnchored(
        canvas: Canvas,
        bitmap: android.graphics.Bitmap,
        frameIndex: Int,
        frameCount: Int,
        anchorX: Float,
        anchorY: Float,
        widthPx: Float,
        heightPx: Float = widthPx,
        normalizedAnchorX: Float = 0.5f,
        normalizedAnchorY: Float = 0.92f,
        mirrorX: Boolean = false,
        alpha: Int = 255,
    ) {
        if (frameCount <= 0) return
        val frameWidth = bitmap.width / frameCount
        val index = frameIndex.coerceIn(0, frameCount - 1)
        val src = Rect(index * frameWidth, 0, (index + 1) * frameWidth, bitmap.height)
        val left = anchorX - widthPx * normalizedAnchorX
        val top = anchorY - heightPx * normalizedAnchorY
        val dest = RectF(left, top, left + widthPx, top + heightPx)
        val oldAlpha = paint.alpha
        paint.alpha = alpha
        if (!mirrorX) {
            canvas.drawBitmap(bitmap, src, dest, paint)
        } else {
            canvas.save()
            canvas.scale(-1f, 1f, anchorX, anchorY)
            canvas.drawBitmap(bitmap, src, dest, paint)
            canvas.restore()
        }
        paint.alpha = oldAlpha
    }

    private fun facingCardinal(dx: Float, dy: Float): Int {
        return if (abs(dx) > abs(dy)) {
            if (dx >= 0f) 1 else 3 // east, west
        } else {
            if (dy >= 0f) 2 else 0 // south, north
        }
    }

    private fun facingAfterMove(currentFacing: Int, dx: Float, dy: Float): Int {
        return if (abs(dx) + abs(dy) < 0.01f) currentFacing else facingCardinal(dx, dy)
    }

    private fun movementFrame(speed: Float, phase: Float = 0f, frames: Int = 2): Int {
        return ((worldElapsedSeconds * speed + phase).toInt()).mod(frames)
    }

    private fun menuIconForLabel(label: String): android.graphics.Bitmap? {
        val upper = label.uppercase()
        return when {
            upper.startsWith("MINERAL") -> uiIconMineralsV2
            upper.startsWith("GAS") -> uiIconGasV2
            upper.startsWith("EMERGENCY") -> uiIconGoldV2
            upper.startsWith("BIOSPEWER") || upper.startsWith("NESTWATCHER") -> uiIconBuildV2
            upper.startsWith("SPREADER") -> uiBtnBurrowV2
            upper.startsWith("SPEED+") || upper.startsWith("HARVEST+") || upper.startsWith("NEST HP+") -> uiBtnSpreadV2
            upper == "CLOSE" || upper == "BACK" || upper == "CLEAR" -> uiBtnBackV2
            upper == "STOP" -> uiBtnStopV2
            upper == "SPREAD" -> uiBtnSpreadV2
            upper == "GUARD" -> uiBtnGuardV2
            upper == "FOLLOW" -> uiBtnFollowV2
            upper == "BURROW" -> uiBtnBurrowV2
            else -> null
        }
    }

    private fun drawUiButtonSprite(canvas: Canvas, rect: RectF, icon: android.graphics.Bitmap?, label: String, dimmed: Boolean = false, accentOverride: Int? = null) {
        val accent = accentOverride ?: when {
            label.startsWith("MINERAL", true) -> Color.rgb(70, 145, 255)
            label.startsWith("GAS", true) -> Color.rgb(80, 225, 110)
            label.startsWith("EMERGENCY", true) -> Color.rgb(235, 220, 120)
            label.startsWith("BIOSPEWER", true) -> Color.rgb(235, 110, 180)
            label.startsWith("NESTWATCHER", true) -> Color.rgb(140, 215, 255)
            label.startsWith("SPREADER", true) || label.startsWith("BURROW", true) -> Color.rgb(215, 138, 72)
            label.startsWith("SPEED", true) || label.startsWith("HARVEST", true) || label.startsWith("UPGRADE", true) -> Color.rgb(245, 220, 110)
            label.startsWith("NEST HP", true) -> Color.rgb(255, 150, 92)
            label.startsWith("STOP", true) || label.startsWith("CLOSE", true) || label.startsWith("BACK", true) || label.startsWith("CLEAR", true) -> Color.rgb(185, 195, 212)
            label.startsWith("SPREAD", true) -> Color.rgb(250, 210, 105)
            label.startsWith("GUARD", true) -> Color.rgb(250, 124, 124)
            label.startsWith("FOLLOW", true) -> Color.rgb(145, 215, 255)
            label.startsWith("ALL DRONES", true) -> Color.rgb(82, 225, 230)
            else -> Color.rgb(176, 148, 230)
        }
        drawReadablePanel(canvas, rect, accent, if (dimmed) Color.argb(210, 18, 20, 28) else Color.argb(236, 10, 12, 18), corner = 12f * density)

        val lines = label.split("\n")
        val wide = rect.width() > rect.height() * 1.15f
        val showIcon = icon != null && lines.size <= 2 && rect.height() >= 34f * density && rect.width() >= 60f * density && label.length <= 18
        if (showIcon) {
            icon?.let { safeIcon ->
                val iconSize = min(rect.width(), rect.height()) * if (wide) 0.18f else 0.22f
                val iconX = if (wide) rect.left + 14f * density else rect.centerX()
                val iconY = if (wide) rect.centerY() else rect.top + 12f * density
                drawBitmapCentered(canvas, safeIcon, iconX, iconY, iconSize, iconSize, if (dimmed) 200 else 255)
            }
        }
        val textSize = when {
            lines.size >= 3 -> 8.2f * density
            rect.height() >= 54f * density -> 9.6f * density
            else -> 9.5f * density
        }
        val lineHeight = if (lines.size >= 3) 8.6f * density else 10.6f * density
        val textCenterX = if (showIcon && wide) rect.centerX() + 10f * density else rect.centerX()
        val startY = when {
            showIcon && wide -> rect.centerY() - (lines.size - 1) * lineHeight / 2f + 3f * density
            showIcon -> rect.top + rect.height() * 0.46f
            lines.size >= 3 -> rect.centerY() - (lines.size - 1) * lineHeight / 2f + 1f * density
            else -> rect.centerY() - (lines.size - 1) * lineHeight / 2f + 3f * density
        }
        lines.forEachIndexed { index, line ->
            drawOutlinedText(
                canvas,
                line,
                textCenterX,
                startY + index * lineHeight,
                textSize,
                fillColor = if (dimmed) Color.rgb(150, 150, 150) else Color.WHITE,
                align = Paint.Align.CENTER,
                strokeWidth = 2f * density,
            )
        }
    }

    private fun drawSidebar(canvas: Canvas) {
        if (!sidebarExpanded) {
            drawCollapsedSidebar(canvas)
            drawSidebarToggle(canvas)
            return
        }

        val panelRect = RectF(0f, 0f, sidebarWidth, height.toFloat())
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(5, 6, 10)
        canvas.drawRect(panelRect, paint)
        drawReadablePanel(canvas, RectF(2f * density, 2f * density, panelRect.right - 2f * density, panelRect.bottom - 2f * density), Color.rgb(133, 104, 215))
        drawSidebarToggle(canvas)

        val slots = sidebarSlots()
        val rects = sidebarSlotRects(slots.size)
        slots.forEachIndexed { index, slot ->
            val rect = rects[index]
            val accent = if (slot.active) Color.rgb(255, 214, 110) else slot.accent
            drawReadablePanel(canvas, rect, accent, if (slot.active) Color.argb(240, 24, 18, 16) else Color.argb(228, 10, 12, 18), corner = 8f * density)
            drawLabelValueCentered(canvas, rect, slot.label, slot.value, slot.accent)
        }

        drawOutlinedText(canvas, prototypeVersionLabel, panelRect.centerX(), panelRect.bottom - 10f * density, 8.8f * density, fillColor = Color.rgb(225, 230, 240), align = Paint.Align.CENTER, strokeWidth = 1.8f * density)
    }

    private fun drawSidebarToggle(canvas: Canvas) {
        val rect = sidebarToggleRect()
        drawBitmapFit(canvas, if (sidebarExpanded) uiToggleLeftV2 else uiToggleRightV2, rect)
    }

    private fun drawCollapsedSidebar(canvas: Canvas) {
        val panelRect = RectF(0f, 0f, sidebarWidth, height.toFloat())
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(5, 6, 10)
        canvas.drawRect(panelRect, paint)
        drawReadablePanel(canvas, RectF(2f * density, 2f * density, panelRect.right - 2f * density, panelRect.bottom - 2f * density), Color.rgb(133, 104, 215), corner = 8f * density)
        val center = sidebarWidth / 2f
        val entries = listOf(
            Triple("M", minerals.toString(), Color.rgb(55, 135, 255)),
            Triple("G", gas.toString(), Color.rgb(55, 220, 90)),
            Triple("D", drones.size.toString(), Color.rgb(70, 220, 235)),
            Triple("C", "${drones.size}/${droneCapacity()}", Color.rgb(140, 210, 255)),
        )
        entries.forEachIndexed { index, entry ->
            val y = 62f * density + index * 56f * density
            drawOutlinedText(canvas, entry.first, center, y, 12f * density, fillColor = entry.third, align = Paint.Align.CENTER, strokeWidth = 1.8f * density)
            drawOutlinedText(canvas, entry.second, center, y + 17f * density, 10f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 1.8f * density)
        }

        drawOutlinedText(canvas, prototypeVersionLabel.removePrefix("v"), center, height - 10f * density, 7.8f * density, fillColor = Color.rgb(225, 230, 240), align = Paint.Align.CENTER, strokeWidth = 1.6f * density)
    }

    private fun sidebarSlots(): List<SlotData> = listOf(
        SlotData("M", minerals.toString(), Color.rgb(55, 135, 255), false),
        SlotData("G", gas.toString(), Color.rgb(55, 220, 90), false),
        SlotData("D", drones.size.toString(), Color.rgb(70, 220, 235), drones.any { it.selected }),
        SlotData("CAP", "${drones.size}/${droneCapacity()}", Color.rgb(135, 215, 255), false),
        SlotData("NEST", if (nestMenuOpen) "OPEN" else "MENU", Color.rgb(235, 130, 45), nestMenuOpen),
        SlotData("BUILD", if (buildMenuOpen || buildPlacementType != null) "OPEN" else "TAB", Color.rgb(255, 210, 90), buildMenuOpen || buildPlacementType != null),
        SlotData("UNITS", selectedUnitCount().toString(), Color.rgb(255, 188, 74), anyUnitsSelected()),
        SlotData("SHOP", "${shopGold}G", Color.rgb(245, 194, 66), shopMenuOpen),
    )

    private fun sidebarSlotRects(count: Int): List<RectF> {
        val margin = 6f * density
        val top = 38f * density
        val bottom = 7f * density
        val gap = 4f * density
        val columns = if (!isPortrait && count >= 10) 2 else 1
        val rows = (count + columns - 1) / columns
        val horizontalAvailable = sidebarWidth - margin * 2f - gap * (columns - 1)
        val slotWidth = horizontalAvailable / columns
        val verticalAvailable = max(1f, height - top - bottom - gap * (rows - 1))
        val slotHeight = min(56f * density, verticalAvailable / rows)
        return (0 until count).map { index ->
            val row = index / columns
            val column = index % columns
            val x = margin + column * (slotWidth + gap)
            val y = top + row * (slotHeight + gap)
            RectF(x, y, x + slotWidth, y + slotHeight)
        }
    }

    private fun drawZoomControls(canvas: Canvas) {
        val buttons = zoomButtonRects()
        buttons.forEachIndexed { index, rect ->
            drawBitmapFit(canvas, if (index == 0) uiZoomPlusV2 else uiZoomMinusV2, rect)
        }
    }

    private fun drawNestMenu(canvas: Canvas) {
        drawMenuBackground(canvas, Color.rgb(235, 130, 45))
        val activeNest = nest ?: return
        val top = menuTop()
        drawOutlinedText(canvas, "BIONEST  HP ${activeNest.health}/${activeNest.maxHealth}", sidebarWidth + 10f * density, top + 15f * density, 10.6f * density, fillColor = Color.WHITE, strokeWidth = 2.2f * density)
        drawOutlinedText(canvas, "DRONES ${drones.size}/${droneCapacity()}   BIOFILM BONUS ACTIVE", sidebarWidth + 10f * density, top + 28f * density, 8.8f * density, fillColor = Color.LTGRAY, strokeWidth = 1.8f * density)
        val labels = listOf(
            "ALL DRONES",
            "SPEED+\n${speedUpgradeCost()}M",
            "HARVEST+\n${harvestUpgradeCost()}G",
            "NEST HP+\n${healthUpgradeCost()}M",
            "SPREADER\n${spreaderMineralCost}M ${spreaderGasCost}G\nBURROW+GROW",
        )
        val accents = listOf(Color.rgb(70, 220, 235), Color.WHITE,
            Color.rgb(55, 220, 90), Color.rgb(235, 130, 45), Color.rgb(188, 95, 235))
        menuButtonRects(5).forEachIndexed { index, rect -> drawMenuButton(canvas, rect, labels[index], accents[index]) }
    }

    private fun drawBuildCatalogMenu(canvas: Canvas) {
        drawMenuBackground(canvas, Color.rgb(255, 210, 90))
        val top = menuTop()
        drawOutlinedText(canvas, "BUILDINGS", sidebarWidth + 10f * density, top + 15f * density, 10.6f * density, fillColor = Color.WHITE, strokeWidth = 2.2f * density)
        drawOutlinedText(canvas, "AVAILABLE DRONES ${availableBuilderDrones().size}", sidebarWidth + 10f * density, top + 28f * density, 8.8f * density, fillColor = Color.LTGRAY, strokeWidth = 1.8f * density)
        val labels = listOf(
            "BIOSPEWER\n${biospewerDroneCost}D ${biospewerMineralCost}M ${biospewerGasCost}G\nGUARDS+HATCH",
            "NESTWATCHER\n${watcherDroneCost}D ${watcherMineralCost}M ${watcherGasCost}G\nRAISES CAP",
            "CLOSE",
        )
        val accents = listOf(Color.rgb(245, 80, 180), Color.rgb(135, 215, 255), Color.GRAY)
        menuButtonRects(3).forEachIndexed { index, rect -> drawMenuButton(canvas, rect, labels[index], accents[index]) }
    }

    private fun drawShopMenu(canvas: Canvas) {
        drawMenuBackground(canvas, Color.rgb(245, 194, 66))
        val top = menuTop()
        drawOutlinedText(canvas, "HIVE SHOP   GOLD $shopGold", sidebarWidth + 10f * density, top + 15f * density, 10.6f * density, fillColor = Color.WHITE, strokeWidth = 2.2f * density)
        drawOutlinedText(canvas, "DESTROY ENEMY CAMPS TO EARN MORE GOLD", sidebarWidth + 10f * density, top + 28f * density, 8.4f * density, fillColor = Color.LTGRAY, strokeWidth = 1.8f * density)
        val labels = listOf(
            "MINERAL CACHE\n8G\n+120M",
            "GAS CACHE\n8G\n+120G",
            "EMERGENCY LARVA\n12G\n+1 LARVA",
            "CLOSE",
        )
        val accents = listOf(
            Color.rgb(55, 135, 255),
            Color.rgb(55, 220, 90),
            Color.rgb(232, 220, 140),
            Color.GRAY,
        )
        menuButtonRects(4).forEachIndexed { index, rect ->
            drawMenuButton(canvas, rect, labels[index], accents[index])
        }
    }

    private fun drawBuildPlacementMenu(canvas: Canvas) {
        val type = buildPlacementType ?: return
        val valid = ghostPlacementValid()
        drawMenuBackground(canvas, if (valid) Color.rgb(70, 235, 115) else Color.rgb(235, 80, 80))
        val top = menuTop()
        val typeName = if (type == BuildingType.BIOSPEWER) "BIOSPEWER" else "NESTWATCHER"
        val status = when {
            ghostBuildX == null -> "TAP THE WORLD TO POSITION THE GHOST"
            valid -> "VALID POSITION - CONFIRM WHEN READY"
            else -> "BLOCKED OR MISSING COST/DRONES"
        }
        drawOutlinedText(canvas, "PLACE $typeName", sidebarWidth + 10f * density, top + 15f * density, 10.6f * density, fillColor = Color.WHITE, strokeWidth = 2.2f * density)
        drawOutlinedText(canvas, status, sidebarWidth + 10f * density, top + 28f * density, 8.4f * density, fillColor = Color.LTGRAY, strokeWidth = 1.8f * density)
        val rects = menuButtonRects(2)
        drawPlacementActionButton(canvas, rects[0], confirm = true, enabled = valid)
        drawPlacementActionButton(canvas, rects[1], confirm = false, enabled = true)
    }

    private fun drawPlacementActionButton(canvas: Canvas, rect: RectF, confirm: Boolean, enabled: Boolean) {
        drawReadablePanel(canvas, rect, if (confirm) Color.rgb(86, 225, 122) else Color.rgb(235, 108, 108), if (enabled || !confirm) Color.argb(232, 10, 12, 18) else Color.argb(200, 26, 28, 35), corner = 10f * density)
        drawOutlinedText(canvas, if (confirm) "CONFIRM" else "CANCEL", rect.centerX(), rect.centerY() + 4f * density, 10.2f * density, fillColor = if (enabled || !confirm) Color.WHITE else Color.GRAY, align = Paint.Align.CENTER, strokeWidth = 2f * density)
    }

    private fun drawUnitSelectionMenu(canvas: Canvas) {
        val menuAccent = when (commandMode) {
            CommandMode.GUARD_TARGET -> Color.rgb(245, 125, 125)
            CommandMode.BURROW_TARGET -> Color.rgb(188, 95, 235)
            CommandMode.NONE -> Color.rgb(220, 170, 90)
        }
        drawMenuBackground(canvas, menuAccent)
        val top = menuTop()
        val summaries = selectedUnitSummaries()
        val total = summaries.sumOf { it.count }
        val singleSelection = total == 1

        paint.textAlign = Paint.Align.LEFT
        paint.textSize = 9.8f * density
        paint.color = Color.WHITE
        val headline = when {
            commandMode == CommandMode.GUARD_TARGET -> "GUARD COMMAND - TAP A BUILDING OR GROUND POST"
            commandMode == CommandMode.BURROW_TARGET -> "BURROW COMMAND - TAP OPEN EXPLORED GROUND"
            singleSelection -> singleSelectedUnitTitle()
            else -> "$total UNITS SELECTED - HOLD A TYPE TILE TO ISOLATE IT"
        }
        wrapText(headline, if (isPortrait) 34 else 56, 2).forEachIndexed { idx, line ->
            drawOutlinedText(canvas, line, sidebarWidth + 10f * density, top + (15f + idx * 11f) * density, 9.8f * density, fillColor = Color.WHITE, strokeWidth = 2f * density)
        }

        if (singleSelection) {
            drawSingleUnitCard(canvas)
        } else {
            drawMultiUnitSummary(canvas, summaries)
        }

        val labels = unitCommandLabels()
        val commandRects = unitCommandButtonRects(labels.size)
        if (commandRects.isNotEmpty()) {
            val bounds = RectF(commandRects.first())
            commandRects.drop(1).forEach { rect -> bounds.union(rect) }
            bounds.inset(-6f * density, -5f * density)
            drawReadablePanel(canvas, bounds, Color.rgb(220, 170, 90), Color.argb(224, 10, 12, 18), corner = 12f * density)
        }
        commandRects.forEachIndexed { index, rect ->
            val accent = when (labels[index]) {
                "STOP" -> Color.LTGRAY
                "SPREAD" -> Color.rgb(255, 214, 110)
                "GUARD" -> Color.rgb(245, 125, 125)
                "BURROW" -> Color.rgb(190, 105, 52)
                "FOLLOW" -> Color.rgb(135, 215, 255)
                else -> Color.GRAY
            }
            drawMenuButton(canvas, rect, labels[index], accent)
        }
    }

    private fun unitCommandLabels(): List<String> {
        val total = selectedUnitCount()
        if (total <= 0) return emptyList()
        val spreaderOnly = spreaders.count { it.selected } == total
        val hasCombat = watcherUnits.any { it.selected } || defenders.any { it.selected } || hatchlings.any { it.selected }
        return when {
            total == 1 && spreaderOnly -> listOf("STOP", "BURROW", "FOLLOW")
            total == 1 && hasCombat -> listOf("STOP", "SPREAD", "GUARD", "FOLLOW")
            total == 1 -> listOf("STOP", "SPREAD", "FOLLOW")
            spreaderOnly -> listOf("STOP", "BURROW", "CLEAR")
            hasCombat -> listOf("STOP", "SPREAD", "GUARD", "CLEAR")
            else -> listOf("STOP", "SPREAD", "CLEAR")
        }
    }

    private fun drawSingleUnitCard(canvas: Canvas) {
        val rect = unitCardRect()
        val info = singleSelectedUnitInfo()
        drawReadablePanel(canvas, rect, info.third, Color.argb(226, 12, 15, 22), corner = 10f * density)

        val portrait = RectF(rect.left + 12f * density, rect.top + 6f * density, rect.left + 48f * density, rect.top + 42f * density)
        drawBitmapFit(canvas, uiPortraitFrameV2, portrait)
        paint.style = Paint.Style.FILL
        paint.color = info.third
        canvas.drawCircle(portrait.centerX(), portrait.centerY(), portrait.width() * 0.24f, paint)
        paint.color = Color.rgb(18, 26, 19)
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 14f * density
        canvas.drawText(info.first.take(1), portrait.centerX(), portrait.centerY() + 5f * density, paint)

        drawOutlinedText(canvas, info.first, portrait.right + 10f * density, rect.top + 19f * density, 11.5f * density, fillColor = Color.WHITE, strokeWidth = 2f * density)
        drawOutlinedText(canvas, info.second, portrait.right + 10f * density, rect.top + 33f * density, 8.7f * density, fillColor = Color.LTGRAY, strokeWidth = 1.7f * density)
    }

    private fun drawMultiUnitSummary(canvas: Canvas, summaries: List<UnitTypeSummary>) {
        val rects = unitTypeChipRects(summaries.size)
        summaries.forEachIndexed { index, summary ->
            val rect = rects[index]
            drawReadablePanel(canvas, rect, summary.accent, Color.argb(220, 12, 15, 20), corner = 8f * density)
            drawOutlinedText(canvas, summary.label, rect.centerX(), rect.top + rect.height() * 0.40f, 9.6f * density, fillColor = summary.accent, align = Paint.Align.CENTER, strokeWidth = 1.8f * density)
            drawOutlinedText(canvas, summary.count.toString(), rect.centerX(), rect.top + rect.height() * 0.76f, 9.6f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 1.8f * density)
        }
    }

    private fun drawTimeIndicator(canvas: Canvas) {
        val phase = dayPhase()
        val totalMinutes = (phase * 24f * 60f).roundToInt() % (24 * 60)
        val hour = totalMinutes / 60
        val minute = totalMinutes % 60
        val displayHour = when (val h = hour % 12) { 0 -> 12; else -> h }
        val suffix = if (hour < 12) "AM" else "PM"
        val day = floor(worldElapsedSeconds / dayLengthSeconds).toInt() + 1
        val play = playfieldRect()
        val boxW = 138f * density
        val boxH = 32f * density
        val rect = RectF(play.centerX() - boxW / 2f, 6f * density, play.centerX() + boxW / 2f, 6f * density + boxH)
        drawReadablePanel(canvas, rect, Color.rgb(244, 204, 95), Color.argb(228, 15, 17, 24), corner = 10f * density)
        paint.style = Paint.Style.FILL
        paint.color = if (daylightStrength() > 0.45f) Color.rgb(255, 224, 90) else Color.rgb(190, 210, 255)
        canvas.drawCircle(rect.left + 18f * density, rect.centerY(), 5f * density, paint)
        drawOutlinedText(canvas, "DAY $day  $displayHour:${minute.toString().padStart(2, '0')} $suffix", rect.left + 29f * density, rect.centerY() + 3f * density, 10.5f * density, fillColor = Color.WHITE, strokeWidth = 2f * density)
    }

    private fun drawInspectCard(canvas: Canvas) {
        if (inspectTitle.isBlank()) return
        val play = playfieldRect()
        val widthPx = min(play.width() - 92f * density, 280f * density).coerceAtLeast(150f * density)
        val rect = RectF(play.centerX() - widthPx / 2f, 42f * density, play.centerX() + widthPx / 2f, 88f * density)
        drawReadablePanel(canvas, rect, Color.rgb(135, 215, 255), Color.argb(225, 14, 18, 26), corner = 10f * density)
        drawOutlinedText(canvas, inspectTitle, rect.left + 12f * density, rect.top + 15f * density, 11f * density, fillColor = Color.WHITE, strokeWidth = 2f * density)
        wrapText(inspectBody, if (isPortrait) 38 else 56, 2).forEachIndexed { idx, line ->
            drawOutlinedText(canvas, line, rect.left + 12f * density, rect.top + (29f + idx * 10f) * density, 8.2f * density, fillColor = Color.LTGRAY, strokeWidth = 1.6f * density)
        }
    }

    private fun drawWatcherMenu(canvas: Canvas) {
        val watcher = selectedWatcherId?.let(::findWatcher) ?: return
        drawMenuBackground(canvas, Color.rgb(135, 215, 255))
        val top = menuTop()
        drawOutlinedText(canvas, "NESTWATCHER  LEVEL ${watcher.level}", sidebarWidth + 10f * density, top + 15f * density, 10.6f * density, fillColor = Color.WHITE, strokeWidth = 2.2f * density)
        drawOutlinedText(canvas, "SUPPORT +${watcherCapacityBonus(watcher)}   WATCH UNITS ${watcherUnits.count { it.homeWatcherId == watcher.id }}/${watcher.level + 1}", sidebarWidth + 10f * density, top + 28f * density, 8.4f * density, fillColor = Color.LTGRAY, strokeWidth = 1.8f * density)
        val cost = watcherUpgradeCost(watcher)
        val label = if (watcher.level >= 4) "MAX LEVEL" else "UPGRADE\n${cost.first}M ${cost.second}G\n+4 CAP"
        val labels = listOf(label, "CLOSE")
        val accents = listOf(Color.rgb(135, 215, 255), Color.GRAY)
        menuButtonRects(2).forEachIndexed { index, rect -> drawMenuButton(canvas, rect, labels[index], accents[index]) }
    }

    private fun drawBarrierMenu(canvas: Canvas) {
        val tile = selectedBarrierKey?.let(tiles::get) ?: return
        drawMenuBackground(canvas, Color.rgb(190, 130, 225))
        val top = menuTop()
        val cost = barrierCost(tile)
        drawOutlinedText(canvas, "FOREST BARRIER  REGION ${tile.q},${tile.r}", sidebarWidth + 10f * density, top + 15f * density, 10.6f * density, fillColor = Color.WHITE, strokeWidth = 2.2f * density)
        drawOutlinedText(canvas, "BREAK THIS BORDER TO EXPAND THE HIVE", sidebarWidth + 10f * density, top + 28f * density, 8.4f * density, fillColor = Color.LTGRAY, strokeWidth = 1.8f * density)
        val labels = listOf("BREAK BARRIER\n${cost.first}M ${cost.second}G", "CLOSE")
        val accents = listOf(Color.rgb(205, 145, 235), Color.GRAY)
        menuButtonRects(2).forEachIndexed { index, rect -> drawMenuButton(canvas, rect, labels[index], accents[index]) }
    }

    private fun drawMenuBackground(canvas: Canvas, accent: Int) {
        val top = menuTop()
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(8, 9, 14)
        canvas.drawRect(sidebarWidth, top, width.toFloat(), height.toFloat(), paint)
        val rect = RectF(sidebarWidth + 4f * density, top + 2f * density, width - 4f * density, height - 3f * density)
        drawReadablePanel(canvas, rect, accent, Color.argb(236, 8, 10, 16), corner = 12f * density)
    }

    private fun drawMenuButton(canvas: Canvas, rect: RectF, label: String, accent: Int) {
        drawUiButtonSprite(canvas, rect, menuIconForLabel(label), label, accentOverride = accent)
    }

    private fun drawMessage(canvas: Canvas) {
        if (message.isBlank()) return
        val play = playfieldRect()
        drawOutlinedText(canvas, message, play.centerX(), play.top + 100f * density, if (isPortrait) 10f * density else 12f * density, fillColor = Color.WHITE, align = Paint.Align.CENTER, strokeWidth = 2f * density)
        if (nest != null && messageTimer < 98f) return
        val instruction = when {
            buildPlacementType != null -> "Tap to position the ghost, then use the checkmark or X below."
            buildMenuOpen -> "Choose a building. Drones and resources are only spent after confirmation."
            anyUnitsSelected() -> "Use the bottom command bar. Hold a unit-type tile to isolate that unit type."
            else -> "Drag to move the camera. Pinch or use +/- to zoom. Hold to ring-select units."
        }
        drawOutlinedText(canvas, instruction, play.centerX(), play.top + 114f * density, 8f * density, fillColor = Color.LTGRAY, align = Paint.Align.CENTER, strokeWidth = 1.6f * density)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchDown = true
                touchDownX = event.x
                touchDownY = event.y
                touchCurrentX = event.x
                touchCurrentY = event.y
                previousTouchX = event.x
                previousTouchY = event.y
                touchDownTimeMs = SystemClock.uptimeMillis()
                touchStartedInPlayfield = playfieldRect().contains(event.x, event.y)
                selectionRingActive = false
                panning = false
                pinching = false
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= 2) startPinch(event)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                touchCurrentX = event.x
                touchCurrentY = event.y
                if (event.pointerCount >= 2) {
                    if (!pinching) startPinch(event)
                    updatePinch(event)
                    return true
                }
                if (pinching) return true

                if (touchStartedInPlayfield && !selectionRingActive && buildPlacementType == null && !placementMode) {
                    val moved = distance(touchDownX, touchDownY, event.x, event.y)
                    if (moved > 12f * density) panning = true
                    if (panning) {
                        val dx = event.x - previousTouchX
                        val dy = event.y - previousTouchY
                        cameraX -= dx / zoom
                        cameraY -= dy / zoom
                        clampCameraToMap()
                    }
                }
                previousTouchX = event.x
                previousTouchY = event.y
                return true
            }

            MotionEvent.ACTION_POINTER_UP -> {
                // Keep the pinch marked active until the final finger lifts so the
                // gesture cannot accidentally become a world tap or selection.
                return true
            }

            MotionEvent.ACTION_UP -> {
                val x = event.x
                val y = event.y
                if (appScreen != AppScreen.PLAYING) {
                    handleFrontEndTap(x, y)
                    resetTouchState()
                    return true
                }
                if (pinching || panning) {
                    resetTouchState()
                    return true
                }
                if (handleUiTap(x, y)) {
                    resetTouchState()
                    return true
                }
                if (!playfieldRect().contains(x, y)) {
                    resetTouchState()
                    return true
                }

                if (placementMode) {
                    val w = screenToWorld(x, y)
                    placeNest(w.first, w.second)
                    resetTouchState()
                    return true
                }

                if (buildPlacementType != null) {
                    val w = screenToWorld(x, y)
                    positionBuildGhost(w.first, w.second)
                    resetTouchState()
                    return true
                }

                if (selectionRingActive) {
                    val center = screenToWorld(touchDownX, touchDownY)
                    selectUnitsInRing(center.first, center.second, selectionRingRadius / zoom)
                    resetTouchState()
                    return true
                }

                val w = screenToWorld(x, y)
                handleWorldTap(w.first, w.second)
                resetTouchState()
                return true
            }

            MotionEvent.ACTION_CANCEL -> {
                resetTouchState()
                return true
            }
        }
        return true
    }

    private fun handleFrontEndTap(x: Float, y: Float) {
        when (appScreen) {
            AppScreen.MAIN_MENU -> {
                val index = mainMenuButtonRects().indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> appScreen = AppScreen.WORLD_SETUP
                    1 -> appScreen = AppScreen.BIOBOOK
                    2 -> appScreen = AppScreen.SETTINGS
                    3 -> (context as? android.app.Activity)?.finish()
                }
            }
            AppScreen.WORLD_SETUP -> {
                val rects = worldSetupRects()
                when {
                    rects.nameField.contains(x, y) -> promptForWorldName()
                    rects.sizeButtons.any { it.contains(x, y) } -> {
                        val index = rects.sizeButtons.indexOfFirst { it.contains(x, y) }
                        if (index >= 0) {
                            selectedMapSize = MapSize.entries[index]
                            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                            invalidate()
                        }
                    }
                    rects.seedField.contains(x, y) -> promptForWorldSeed()
                    rects.randomButton.contains(x, y) -> {
                        randomizeSetupSeed()
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    }
                    rects.createButton.contains(x, y) -> beginConfiguredWorld()
                    rects.backButton.contains(x, y) -> appScreen = AppScreen.MAIN_MENU
                }
            }
            AppScreen.SETTINGS -> {
                val index = settingsButtonRects().indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> appScreen = AppScreen.WORLD_SETUP
                    1 -> appScreen = AppScreen.MAIN_MENU
                }
            }
            AppScreen.BIOBOOK -> {
                val tabIndex = bioBookTabRects().indexOfFirst { it.contains(x, y) }
                when {
                    tabIndex >= 0 -> {
                        bioBookSection = BioBookSection.entries[tabIndex]
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    }
                    bioBookBackRect().contains(x, y) -> appScreen = AppScreen.MAIN_MENU
                }
            }
            AppScreen.PLAYING -> Unit
        }
    }

    private fun promptForWorldName() {
        val input = EditText(context).apply {
            setText(setupWorldName)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            selectAll()
        }
        AlertDialog.Builder(context)
            .setTitle("Map Name")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                setupWorldName = input.text.toString().trim().ifBlank { "New Colony" }.take(24)
                invalidate()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun promptForWorldSeed() {
        val input = EditText(context).apply {
            setText(setupSeedText)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_NUMBER
            selectAll()
        }
        AlertDialog.Builder(context)
            .setTitle("World Seed")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                val parsed = input.text.toString().trim().toLongOrNull()
                setupSeedText = parsed?.coerceIn(1L, 999_999_999L)?.toString()
                    ?: Random(System.currentTimeMillis().toInt()).nextInt(100000, 999999999).toString()
                invalidate()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun randomizeSetupSeed() {
        setupSeedText = Random(System.currentTimeMillis().toInt()).nextInt(100000, 999999999).toString()
        invalidate()
    }

    private fun beginConfiguredWorld() {
        val seed = setupSeedText.toLongOrNull()?.coerceIn(1L, 999_999_999L)?.toInt()
        if (seed == null) {
            randomizeSetupSeed()
            return
        }
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        startNewWorld(seed, setupWorldName, selectedMapSize, enterPlay = true)
    }

    private fun handleUiTap(x: Float, y: Float): Boolean {
        if (sidebarToggleRect().contains(x, y)) {
            sidebarExpanded = !sidebarExpanded
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            return true
        }
        if (x < sidebarWidth) return handleSidebarTap(x, y)
        val zoomRects = zoomButtonRects()
        if (zoomRects[0].contains(x, y)) {
            setZoomAroundScreen((zoom * 1.22f).coerceAtMost(maxZoom), playfieldRect().centerX(), playfieldRect().centerY())
            return true
        }
        if (zoomRects[1].contains(x, y)) {
            setZoomAroundScreen((zoom / 1.22f).coerceAtLeast(minZoom), playfieldRect().centerX(), playfieldRect().centerY())
            return true
        }
        if (hasBottomMenu && y >= menuTop()) return handleBottomMenuTap(x, y)
        return false
    }

    private fun handleSidebarTap(x: Float, y: Float): Boolean {
        if (!sidebarExpanded) return true
        val rects = sidebarSlotRects(sidebarSlots().size)
        val index = rects.indexOfFirst { it.contains(x, y) }
        when (index) {
            4 -> {
                nest?.let {
                    clearMenusAndSelection()
                    nestMenuOpen = true
                    showMessage("Bionest controls")
                }
                return true
            }
            5 -> {
                if (nest != null) {
                    clearMenusAndSelection()
                    buildMenuOpen = true
                    showMessage("Choose a biological structure")
                }
                return true
            }
            6 -> {
                if (drones.isNotEmpty()) selectAllDrones()
                return true
            }
            7 -> {
                clearMenusAndSelection()
                shopMenuOpen = true
                showMessage("Shop opened. Camp gold is spent here.")
                return true
            }
        }
        return true
    }

    private fun handleBottomMenuTap(x: Float, y: Float): Boolean {
        when {
            nestMenuOpen -> {
                val index = menuButtonRects(5).indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> selectAllDrones()
                    1 -> buySpeedUpgrade()
                    2 -> buyHarvestUpgrade()
                    3 -> buyNestHealthUpgrade()
                    4 -> spawnSpreader()
                }
                return true
            }
            selectedWatcherId != null -> {
                val index = menuButtonRects(2).indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> upgradeSelectedWatcher()
                    1 -> selectedWatcherId = null
                }
                return true
            }
            selectedBarrierKey != null -> {
                val index = menuButtonRects(2).indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> unlockSelectedBarrier()
                    1 -> selectedBarrierKey = null
                }
                return true
            }
            buildPlacementType != null -> {
                val index = menuButtonRects(2).indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> confirmBuildGhost()
                    1 -> cancelBuildPlacement(returnToCatalog = true)
                }
                return true
            }
            buildMenuOpen -> {
                val index = menuButtonRects(3).indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> startBuildPlacement(BuildingType.BIOSPEWER)
                    1 -> startBuildPlacement(BuildingType.NEST_WATCHER)
                    2 -> buildMenuOpen = false
                }
                return true
            }
            shopMenuOpen -> {
                val index = menuButtonRects(4).indexOfFirst { it.contains(x, y) }
                when (index) {
                    0 -> buyShopMinerals()
                    1 -> buyShopGas()
                    2 -> buyShopLarva()
                    3 -> shopMenuOpen = false
                }
                return true
            }
            anyUnitsSelected() -> {
                val heldMs = SystemClock.uptimeMillis() - touchDownTimeMs
                val summaries = selectedUnitSummaries()
                val chipIndex = unitTypeChipRects(summaries.size).indexOfFirst { it.contains(x, y) }
                if (chipIndex >= 0 && heldMs >= longPressMs) {
                    isolateSelectionTo(summaries[chipIndex].kind)
                    return true
                }
                val labels = unitCommandLabels()
                val index = unitCommandButtonRects(labels.size).indexOfFirst { it.contains(x, y) }
                when (labels.getOrNull(index)) {
                    "STOP" -> stopSelectedUnits()
                    "SPREAD" -> spreadOutSelectedUnits()
                    "GUARD", "BURROW" -> beginContextCommand()
                    "FOLLOW" -> toggleFollowSelectedUnit()
                    "CLEAR" -> clearAllUnitSelection()
                }
                return true
            }
        }
        return true
    }

    private fun handleWorldTap(worldX: Float, worldY: Float) {
        val selectedDrones = drones.filter { it.selected }
        val selectedWatcherUnits = watcherUnits.filter { it.selected }
        val selectedDefenders = defenders.filter { it.selected }
        val selectedHatchlings = hatchlings.filter { it.selected }
        val selectedSpreaders = spreaders.filter { it.selected }
        val selectedCombatCount = selectedWatcherUnits.size + selectedDefenders.size + selectedHatchlings.size

        if (commandMode == CommandMode.GUARD_TARGET && selectedCombatCount == 0) {
            commandMode = CommandMode.NONE
        }
        if (commandMode == CommandMode.BURROW_TARGET && selectedSpreaders.isEmpty()) {
            commandMode = CommandMode.NONE
        }

        val tappedResource = findResourceAt(worldX, worldY)
        if (tappedResource != null && selectedDrones.isNotEmpty()) {
            issueHarvestOrder(selectedDrones, tappedResource)
            clearAllUnitSelection()
            return
        }

        findDroneAt(worldX, worldY)?.let {
            selectSingleDrone(it)
            setInspectInfo("Worker Drone", "Carries resources, builds structures, and can be reassigned.")
            return
        }
        findWatcherUnitAt(worldX, worldY)?.let {
            selectSingleWatcherUnit(it)
            setInspectInfo("Watch Unit", "A quick NestWatcher scout that can patrol or guard a chosen location.")
            return
        }
        findDefenderAt(worldX, worldY)?.let {
            selectSingleDefender(it)
            setInspectInfo("Guard", "A tougher snake guard that can protect buildings or guard posts.")
            return
        }
        findHatchlingAt(worldX, worldY)?.let {
            selectSingleHatchling(it)
            setInspectInfo("Hatchling", "Fast, fragile swarm unit. Great for overwhelming threats.")
            return
        }
        findSpreaderAt(worldX, worldY)?.let {
            selectSingleSpreader(it)
            val body = if (it.state == SpreaderState.BURROWED)
                "Permanently rooted. It cannot move again and now expands biofilm automatically."
            else "Burrows into open ground and starts a permanent biofilm growth point."
            setInspectInfo("Spreader", body)
            return
        }

        enemyCamps.asReversed().firstOrNull {
            isTileUnlocked(it.tileKey) && distance(worldX, worldY, it.x, it.y) <= GameScale.ENEMY_CAMP_RADIUS
        }?.let { camp ->
            if (selectedCombatCount > 0) {
                issueGuardOrder(camp.x, camp.y, "enemy camp")
                clearAllUnitSelection()
                commandMode = CommandMode.NONE
                showMessage("Combat units ordered to destroy the camp")
            } else {
                val current = primitiveEnemies.count { it.campId == camp.id }
                setInspectInfo(
                    "Primitive Camp",
                    "HP ${camp.health}/${camp.maxHealth}. Hunters $current/${camp.populationTarget}. Reward ${camp.goldReward} gold.",
                )
                clearMenusAndSelection()
            }
            return
        }

        if (!anyUnitsSelected()) {
            primitiveEnemies.asReversed().firstOrNull {
                distance(worldX, worldY, it.x, it.y) <= 20f / zoom.coerceAtLeast(0.65f)
            }?.let { enemy ->
                val behavior = when (enemy.state) {
                    EnemyState.WANDERING -> "patrolling its camp"
                    EnemyState.CHASING -> "chasing a colony unit"
                    EnemyState.RETURNING -> "retreating to its tent"
                }
                setInspectInfo("Primitive Hunter", "HP ${enemy.health}/${enemy.maxHealth}. Currently $behavior.")
                clearMenusAndSelection()
                return
            }
        }

        val tappedNest = nest?.takeIf { distance(worldX, worldY, it.x, it.y) <= GameScale.NEST_SELECTION_RADIUS }
        if (tappedNest != null) {
            if (commandMode == CommandMode.GUARD_TARGET && selectedCombatCount > 0) {
                issueGuardOrder(tappedNest.x, tappedNest.y, "Bionest")
                clearAllUnitSelection()
                commandMode = CommandMode.NONE
            } else {
                clearMenusAndSelection()
                nestMenuOpen = true
                showMessage("Bionest controls")
            }
            setInspectInfo("Bionest", "Main colony heart. Produces larvae and serves as the resource drop-off point.")
            return
        }

        val tappedSpewer = biospewers.firstOrNull {
            distance(worldX, worldY, it.x, it.y) <= GameScale.BIOSPEWER_FOOTPRINT_RADIUS + GameScale.CELL
        }
        if (tappedSpewer != null) {
            if (commandMode == CommandMode.GUARD_TARGET && selectedCombatCount > 0) {
                issueGuardOrder(tappedSpewer.x, tappedSpewer.y, "Biospewer")
                clearAllUnitSelection()
                commandMode = CommandMode.NONE
            } else {
                clearMenusAndSelection()
                showMessage("Biospewer: ${defenders.count { it.homeBiospewerId == tappedSpewer.id }}/5 guards, ${hatchlings.count { it.homeBiospewerId == tappedSpewer.id }}/12 hatchlings")
            }
            setInspectInfo("Biospewer", "Consumes workers to grow guards and hatchlings for colony defense.")
            return
        }

        val watcher = nestWatchers.firstOrNull {
            distance(worldX, worldY, it.x, it.y) <= GameScale.WATCHER_FOOTPRINT_RADIUS + GameScale.CELL
        }
        if (watcher != null) {
            if (commandMode == CommandMode.GUARD_TARGET && selectedCombatCount > 0) {
                issueGuardOrder(watcher.x, watcher.y, "NestWatcher")
                clearAllUnitSelection()
                commandMode = CommandMode.NONE
            } else {
                clearMenusAndSelection()
                selectedWatcherId = watcher.id
                showMessage("NestWatcher supports ${watcherCapacityBonus(watcher)} drones")
            }
            setInspectInfo("NestWatcher", "Raises drone capacity and releases small watch units to patrol nearby.")
            return
        }

        val tile = tileAtWorld(worldX, worldY)
        if (tile != null && !tile.unlocked) {
            if (anyUnitsSelected()) {
                showMessage("Units cannot cross the fog wall")
            } else {
                clearMenusAndSelection()
                selectedBarrierKey = tileKey(tile.q, tile.r)
                showMessage("Barrier selected")
            }
            setInspectInfo("Fog Barrier", "Spend resources to break through and reveal another hex region.")
            return
        }

        val node = tappedResource

        if (commandMode == CommandMode.BURROW_TARGET && selectedSpreaders.isNotEmpty()) {
            if (tile?.unlocked == true && isWalkable(worldX, worldY, 10f)) {
                issueSpreaderOrder(selectedSpreaders, worldX, worldY)
                clearAllUnitSelection()
            } else {
                showMessage("Spreaders need open explored land")
            }
            commandMode = CommandMode.NONE
            return
        }

        if (selectedCombatCount > 0 && commandMode == CommandMode.GUARD_TARGET) {
            if (tile?.unlocked == true && isWalkable(worldX, worldY, 8f)) {
                issueGuardOrder(worldX, worldY, "ground post")
                clearAllUnitSelection()
            } else {
                showMessage("That guard position is blocked")
            }
            commandMode = CommandMode.NONE
            return
        }

        if (anyUnitsSelected()) {
            if (tile?.unlocked == true && isWalkable(worldX, worldY, 8f)) {
                issueDirectMoveOrder(worldX, worldY)
            } else {
                showMessage("That destination is blocked or behind a barrier")
            }
            clearAllUnitSelection()
            return
        }

        if (node != null) {
            val richness = if (node.richnessTier >= 2) "Rich" else "Field"
            val typeName = if (node.type == ResourceType.MINERAL) "Mineral" else "Gas"
            setInspectInfo("$richness $typeName Patch", "${node.amount.roundToInt()} remaining. Drones assigned here will keep harvesting this resource type.")
            clearMenusAndSelection()
            return
        }

        val landmark = landmarks.asReversed().firstOrNull { isTileUnlocked(it.tileKey) && distance(worldX, worldY, it.x, it.y) <= it.radius + 10f }
        if (landmark != null) {
            val title = when (landmark.type) {
                LandmarkType.RUIN -> "Ancient Ruin"
                LandmarkType.MOUNTAIN -> "Mountain"
                LandmarkType.CANYON -> "Canyon Formation"
                LandmarkType.GROVE -> "Sacred Grove"
            }
            val body = when (landmark.type) {
                LandmarkType.RUIN -> "Broken structures from an older civilization. Great map flavor and future event hooks."
                LandmarkType.MOUNTAIN -> "A highland peak shaping terrain and nearby river routes."
                LandmarkType.CANYON -> "Layered stone columns split the land into tighter paths."
                LandmarkType.GROVE -> "Dense living growth. A peaceful landmark in the biome."
            }
            setInspectInfo(title, body)
            clearMenusAndSelection()
            return
        }

        val obstacle = obstacles.asReversed().firstOrNull { isTileUnlocked(it.tileKey) && distance(worldX, worldY, it.x, it.y) <= it.radius + 8f }
        if (obstacle != null) {
            val title = when (obstacle.type) {
                ObstacleType.TREE -> "Forest Tree"
                ObstacleType.ROCK -> "Stone Outcrop"
                ObstacleType.BUSH -> "Brush Cluster"
            }
            val body = when (obstacle.type) {
                ObstacleType.TREE -> "Dense growth blocks building placement and changes unit paths."
                ObstacleType.ROCK -> "Hard terrain obstacle. Units walk around it."
                ObstacleType.BUSH -> "Soft terrain cover that helps the forest feel alive."
            }
            setInspectInfo(title, body)
            clearMenusAndSelection()
            return
        }

        val water = waterFeatures.asReversed().firstOrNull {
            isTileUnlocked(it.tileKey) && distance(worldX, worldY, it.x1, it.y1) <= it.radius + 18f
        }
        if (water != null) {
            val title = when (water.type) {
                WaterType.LAKE -> "Lake"
                WaterType.RIVER -> "River"
                WaterType.OCEAN -> "Ocean Edge"
            }
            setInspectInfo(title, "Water blocks buildings and redirects movement across the hex.")
            clearMenusAndSelection()
            return
        }

        val animal = wildAnimals.asReversed().firstOrNull { distance(worldX, worldY, it.x, it.y) <= 18f / zoom.coerceAtLeast(0.7f) }
        if (animal != null) {
            val title = when (animal.type) {
                AlienAnimalType.GRAZER -> "Alien Grazer"
                AlienAnimalType.HOPPER -> "Alien Hopper"
                AlienAnimalType.STRIDER -> "Reed Strider"
            }
            setInspectInfo(title, "A roaming wild creature. Peaceful for now, but it gives the world more life.")
            clearMenusAndSelection()
            return
        }

        clearMenusAndSelection()
    }

    private fun placeNest(worldX: Float, worldY: Float) {
        val tile = tileAtWorld(worldX, worldY)
        if (tile?.unlocked != true || !isBuildable(worldX, worldY, GameScale.NEST_FOOTPRINT_RADIUS)) {
            showMessage("Place the Bionest in open ground inside the clearing")
            return
        }
        nest = Nest(worldX, worldY)
        gooPatches += GooPatch(
            nextGooPatchId++,
            worldX,
            worldY,
            GameScale.CELL * 1.5f,
            GameScale.CELL * 9f,
            GameScale.CELL * 0.18f,
        )
        placementMode = false
        cameraX = worldX
        cameraY = worldY
        minerals = 0
        gas = 0
        spawnStarterResourceBasin(tile, worldX, worldY)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        showMessage("Bionest deployed. Larvae production started")
    }

    private fun spawnStarterResourceBasin(tile: HexTile, nestX: Float, nestY: Float) {
        val key = tileKey(tile.q, tile.r)
        resourceNodes.removeAll { it.tileKey == key }
        resourceCycleByTile[key] = max(1, resourceCycleByTile[key] ?: 0)

        val candidateAngles = List(8) { index -> index * (Math.PI.toFloat() / 4f) }
        val startIndex = abs(tile.seed) % candidateAngles.size
        var chosenAngle = candidateAngles[startIndex]
        var mineralCenterX = nestX + cos(chosenAngle) * GameScale.CELL * 10f
        var mineralCenterY = nestY + sin(chosenAngle) * GameScale.CELL * 10f
        var gasCenterX = mineralCenterX + cos(chosenAngle + Math.PI.toFloat() / 2f) * GameScale.CELL * 12f
        var gasCenterY = mineralCenterY + sin(chosenAngle + Math.PI.toFloat() / 2f) * GameScale.CELL * 12f

        for (step in candidateAngles.indices) {
            val angle = candidateAngles[(startIndex + step) % candidateAngles.size]
            val testMineralX = nestX + cos(angle) * GameScale.CELL * 10f
            val testMineralY = nestY + sin(angle) * GameScale.CELL * 10f
            val testGasX = testMineralX + cos(angle + Math.PI.toFloat() / 2f) * GameScale.CELL * 12f
            val testGasY = testMineralY + sin(angle + Math.PI.toFloat() / 2f) * GameScale.CELL * 12f
            val clearOfWater = !isPointInWater(testMineralX, testMineralY, GameScale.CELL * 8f) &&
                !isPointInWater(testGasX, testGasY, GameScale.CELL * 4f)
            val insideTile = pointInsideHex(testMineralX, testMineralY, hexCenter(tile.q, tile.r).first, hexCenter(tile.q, tile.r).second, hexRadius - GameScale.CELL * 9f) &&
                pointInsideHex(testGasX, testGasY, hexCenter(tile.q, tile.r).first, hexCenter(tile.q, tile.r).second, hexRadius - GameScale.CELL * 5f)
            val clearOfLandmarks = landmarks.none {
                it.tileKey == key && (distance(testMineralX, testMineralY, it.x, it.y) < it.radius + GameScale.CELL * 8f ||
                    distance(testGasX, testGasY, it.x, it.y) < it.radius + GameScale.CELL * 5f)
            }
            if (clearOfWater && insideTile && clearOfLandmarks) {
                chosenAngle = angle
                mineralCenterX = testMineralX
                mineralCenterY = testMineralY
                gasCenterX = testGasX
                gasCenterY = testGasY
                break
            }
        }

        obstacles.removeAll {
            it.tileKey == key && (
                distance(it.x, it.y, nestX, nestY) < GameScale.CELL * 5f ||
                    distance(it.x, it.y, mineralCenterX, mineralCenterY) < GameScale.CELL * 9.5f ||
                    distance(it.x, it.y, gasCenterX, gasCenterY) < GameScale.CELL * 6.5f
                )
        }

        val arcRadius = GameScale.CELL * 6.75f
        repeat(5) { index ->
            val arc = chosenAngle - Math.PI.toFloat() / 2f + index * (Math.PI.toFloat() / 4f)
            val x = mineralCenterX + cos(arc) * arcRadius
            val y = mineralCenterY + sin(arc) * arcRadius
            val amount = 250f + index * 20f
            resourceNodes += ResourceNode(nextResourceId++, key, x, y, ResourceType.MINERAL, 1, amount, amount, clustered = true)
        }

        val gasOffsetX = cos(chosenAngle) * GameScale.CELL * 2.5f
        val gasOffsetY = sin(chosenAngle) * GameScale.CELL * 2.5f
        repeat(2) { index ->
            val sign = if (index == 0) -1f else 1f
            val x = gasCenterX + gasOffsetX * sign
            val y = gasCenterY + gasOffsetY * sign
            val amount = 560f
            resourceNodes += ResourceNode(nextResourceId++, key, x, y, ResourceType.GAS, 1, amount, amount, clustered = true)
        }
    }

    private fun spawnResourceSetForTile(tile: HexTile) {
        if (!tile.unlocked) return

        val key = tileKey(tile.q, tile.r)
        if (resourceNodes.any { it.tileKey == key && it.amount > 0.05f }) return

        if (tile.q == 0 && tile.r == 0) {
            nest?.let {
                spawnStarterResourceBasin(tile, it.x, it.y)
                return
            }
        }

        resourceNodes.removeAll { it.tileKey == key }
        val cycle = (resourceCycleByTile[key] ?: 0) + 1
        resourceCycleByTile[key] = cycle

        val profile = resourceFieldProfile(tile)
        val seeded = Random(tile.seed xor (cycle * 0x45D9F3B))
        val types = when (profile) {
            ResourceFieldProfile.BALANCED ->
                mutableListOf(ResourceType.MINERAL, ResourceType.GAS)
            ResourceFieldProfile.MINERAL_RICH ->
                mutableListOf(ResourceType.MINERAL, ResourceType.MINERAL, ResourceType.GAS)
            ResourceFieldProfile.GAS_RICH ->
                mutableListOf(ResourceType.GAS, ResourceType.GAS, ResourceType.MINERAL)
            ResourceFieldProfile.ABUNDANT ->
                mutableListOf(
                    ResourceType.MINERAL,
                    ResourceType.GAS,
                    ResourceType.MINERAL,
                    ResourceType.GAS,
                )
        }
        types.shuffle(seeded)

        types.forEach { type ->
            val primaryRichType = when (profile) {
                ResourceFieldProfile.MINERAL_RICH -> type == ResourceType.MINERAL
                ResourceFieldProfile.GAS_RICH -> type == ResourceType.GAS
                ResourceFieldProfile.ABUNDANT -> true
                ResourceFieldProfile.BALANCED -> false
            }
            val tier = if (primaryRichType) 2 else 1
            val amount = when {
                profile == ResourceFieldProfile.ABUNDANT ->
                    760f + seeded.nextFloat() * 320f
                tier == 2 ->
                    900f + seeded.nextFloat() * 360f
                else ->
                    420f + seeded.nextFloat() * 210f
            }

            var placed = false
            repeat(120) {
                if (placed) return@repeat
                val point = randomPointInTile(tile, margin = GameScale.CELL * 3f, seeded)
                if (isBuildable(point.first, point.second, if (tier == 2) GameScale.RICH_RESOURCE_RADIUS else GameScale.RESOURCE_RADIUS)) {
                    resourceNodes += ResourceNode(
                        id = nextResourceId++,
                        tileKey = key,
                        x = point.first,
                        y = point.second,
                        type = type,
                        richnessTier = tier,
                        amount = amount,
                        maxAmount = amount,
                    )
                    placed = true
                }
            }
        }

        if (resourceNodes.none { it.tileKey == key }) {
            resourceRespawnTimers[key] = 2f
        }
    }

    private fun resourceFieldProfile(tile: HexTile): ResourceFieldProfile {
        var mixed = tile.seed xor 0x2F6E2B1
        mixed = mixed xor (mixed ushr 16)
        mixed *= 0x45D9F3B
        mixed = mixed xor (mixed ushr 16)
        val roll = ((mixed.toLong() and 0x7FFFFFFF) % 100L).toInt()
        return when {
            roll < 4 -> ResourceFieldProfile.MINERAL_RICH
            roll < 8 -> ResourceFieldProfile.GAS_RICH
            roll == 8 -> ResourceFieldProfile.ABUNDANT
            else -> ResourceFieldProfile.BALANCED
        }
    }

    private fun resourceFieldLabel(tile: HexTile): String = when (resourceFieldProfile(tile)) {
        ResourceFieldProfile.MINERAL_RICH -> "Rich mineral field"
        ResourceFieldProfile.GAS_RICH -> "Dense gas field"
        ResourceFieldProfile.ABUNDANT -> "Abundant resource basin"
        ResourceFieldProfile.BALANCED -> "Resource fields"
    }

    private fun startBuildPlacement(type: BuildingType) {
        val droneCost = buildingDroneCost(type)
        val mineralCost = buildingMineralCost(type)
        val gasCost = buildingGasCost(type)
        if (availableBuilderDrones().size < droneCost || minerals < mineralCost || gas < gasCost) {
            showMessage("Need $droneCost available drone(s), ${mineralCost}M and ${gasCost}G")
            return
        }
        buildMenuOpen = false
        buildPlacementType = type
        clearDroneSelection()
        val center = screenToWorld(playfieldRect().centerX(), playfieldRect().centerY())
        ghostBuildX = center.first
        ghostBuildY = center.second
        showMessage("Tap the world to move the ghost, then confirm or cancel")
    }

    private fun positionBuildGhost(worldX: Float, worldY: Float) {
        ghostBuildX = worldX
        ghostBuildY = worldY
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        showMessage(if (ghostPlacementValid()) "Valid building position" else "That placement is blocked or unavailable")
    }

    private fun ghostPlacementValid(): Boolean {
        val type = buildPlacementType ?: return false
        val x = ghostBuildX ?: return false
        val y = ghostBuildY ?: return false
        val radius = when (type) {
            BuildingType.BIOSPEWER -> GameScale.BIOSPEWER_FOOTPRINT_RADIUS
            BuildingType.NEST_WATCHER -> GameScale.WATCHER_FOOTPRINT_RADIUS
        }
        return isBuildable(x, y, radius) &&
            availableBuilderDrones().size >= buildingDroneCost(type) &&
            minerals >= buildingMineralCost(type) &&
            gas >= buildingGasCost(type)
    }

    private fun confirmBuildGhost() {
        val type = buildPlacementType ?: return
        val x = ghostBuildX ?: run {
            showMessage("Tap the world to position the building first")
            return
        }
        val y = ghostBuildY ?: return
        if (!ghostPlacementValid()) {
            showMessage("Cannot confirm: position, drones, or resources are invalid")
            return
        }
        val droneCost = buildingDroneCost(type)
        val builders = availableBuilderDrones()
            .sortedBy { distance(it.x, it.y, x, y) }
            .take(droneCost)
        if (builders.size < droneCost) {
            showMessage("Not enough available builder drones")
            return
        }

        minerals -= buildingMineralCost(type)
        gas -= buildingGasCost(type)
        val site = BuildSite(nextBuildingId++, type, builders.map { it.id }.toMutableList(), x, y)
        buildSites += site
        builders.forEach { drone ->
            drone.selected = false
            drone.preferredResourceType = null
            drone.targetResourceId = null
            drone.buildSiteId = site.id
            drone.targetX = x
            drone.targetY = y
            drone.state = DroneState.MOVING_TO_BUILD
        }
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        showMessage("Placement confirmed. Builders are moving to the site")
        cancelBuildPlacement(returnToCatalog = true)
    }

    private fun cancelBuildPlacement(returnToCatalog: Boolean) {
        buildPlacementType = null
        ghostBuildX = null
        ghostBuildY = null
        buildMenuOpen = returnToCatalog
    }

    private fun buildingDroneCost(type: BuildingType): Int =
        if (type == BuildingType.BIOSPEWER) biospewerDroneCost else watcherDroneCost

    private fun buildingMineralCost(type: BuildingType): Int =
        if (type == BuildingType.BIOSPEWER) biospewerMineralCost else watcherMineralCost

    private fun buildingGasCost(type: BuildingType): Int =
        if (type == BuildingType.BIOSPEWER) biospewerGasCost else watcherGasCost

    private fun availableBuilderDrones(): List<Drone> = drones.filter { it.buildSiteId == null }

    private fun completeBuildSite(siteId: Int) {
        val site = findBuildSite(siteId) ?: return
        site.builderDroneIds.forEach { id -> drones.removeAll { it.id == id } }
        when (site.type) {
            BuildingType.BIOSPEWER -> biospewers += Biospewer(nextBuildingId++, site.x, site.y)
            BuildingType.NEST_WATCHER -> nestWatchers += NestWatcher(nextBuildingId++, site.x, site.y)
        }
        if (isInGoo(site.x, site.y)) {
            addConnectedGooGrowth(site.x, site.y, 18f, 150f, 3.2f)
        }
        buildSites.remove(site)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        showMessage(if (site.type == BuildingType.BIOSPEWER) "Biospewer complete" else "NestWatcher online: drone capacity increased")
    }

    private fun selectUnitsInRing(worldX: Float, worldY: Float, radius: Float) {
        clearMenusAndSelection()
        val chosenDrones = drones.filter { it.buildSiteId == null && distance(worldX, worldY, it.x, it.y) <= radius }
        val chosenWatchers = watcherUnits.filter { distance(worldX, worldY, it.x, it.y) <= radius }
        val chosenGuards = defenders.filter { distance(worldX, worldY, it.x, it.y) <= radius }
        val chosenHatchlings = hatchlings.filter { distance(worldX, worldY, it.x, it.y) <= radius }
        val chosenSpreaders = spreaders.filter {
            it.state != SpreaderState.BURROWING && it.state != SpreaderState.BURROWED &&
                distance(worldX, worldY, it.x, it.y) <= radius
        }
        chosenDrones.forEach { it.selected = true }
        chosenWatchers.forEach { it.selected = true }
        chosenGuards.forEach { it.selected = true }
        chosenHatchlings.forEach { it.selected = true }
        chosenSpreaders.forEach { it.selected = true }
        val total = chosenDrones.size + chosenWatchers.size + chosenGuards.size + chosenHatchlings.size + chosenSpreaders.size
        if (total == 0) showMessage("No controllable units inside the ring") else {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            showMessage("$total unit(s) selected")
        }
    }

    private fun selectSingleDrone(drone: Drone) {
        clearMenusAndSelection()
        if (drone.buildSiteId == null) {
            drone.selected = true
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            showMessage("Worker drone selected")
        }
    }

    private fun selectSingleDefender(defender: Defender) {
        clearMenusAndSelection()
        defender.selected = true
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        showMessage("Guard selected - use the bottom command bar")
    }

    private fun selectSingleWatcherUnit(unit: WatcherUnit) {
        clearMenusAndSelection()
        unit.selected = true
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        showMessage("Watch unit selected - use the bottom command bar")
    }

    private fun selectSingleHatchling(hatchling: Hatchling) {
        clearMenusAndSelection()
        hatchling.selected = true
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        showMessage("Hatchling selected - use the bottom command bar")
    }

    private fun selectSingleSpreader(spreader: Spreader) {
        clearMenusAndSelection()
        if (spreader.state != SpreaderState.BURROWING && spreader.state != SpreaderState.BURROWED) {
            spreader.selected = true
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            showMessage("Spreader selected - use the bottom command bar or tap land to move")
        }
    }

    private fun selectAllDrones() {
        clearMenusAndSelection()
        drones.filter { it.buildSiteId == null }.forEach { it.selected = true }
        showMessage("${drones.count { it.selected }} drone(s) selected")
    }

    private fun clearDroneSelection() {
        drones.forEach { it.selected = false }
    }

    private fun selectedUnitCount(): Int =
        drones.count { it.selected } + watcherUnits.count { it.selected } + defenders.count { it.selected } +
            hatchlings.count { it.selected } + spreaders.count { it.selected }

    private fun selectedUnitSummaries(): List<UnitTypeSummary> {
        val list = mutableListOf<UnitTypeSummary>()
        val droneCount = drones.count { it.selected }
        val watcherCount = watcherUnits.count { it.selected }
        val guardCount = defenders.count { it.selected }
        val hatchCount = hatchlings.count { it.selected }
        val spreaderCount = spreaders.count { it.selected }
        if (droneCount > 0) list += UnitTypeSummary(UnitKind.DRONE, "DRONE", droneCount, Color.rgb(70, 220, 235))
        if (watcherCount > 0) list += UnitTypeSummary(UnitKind.WATCHER, "WATCH", watcherCount, Color.rgb(112, 222, 255))
        if (guardCount > 0) list += UnitTypeSummary(UnitKind.GUARD, "GUARD", guardCount, Color.rgb(255, 105, 155))
        if (hatchCount > 0) list += UnitTypeSummary(UnitKind.HATCHLING, "HATCH", hatchCount, Color.rgb(255, 188, 74))
        if (spreaderCount > 0) list += UnitTypeSummary(UnitKind.SPREADER, "SPREAD", spreaderCount, Color.rgb(188, 95, 235))
        return list
    }

    private fun singleSelectedUnitKind(): UnitKind? = when {
        drones.count { it.selected } == 1 && selectedUnitCount() == 1 -> UnitKind.DRONE
        watcherUnits.count { it.selected } == 1 && selectedUnitCount() == 1 -> UnitKind.WATCHER
        defenders.count { it.selected } == 1 && selectedUnitCount() == 1 -> UnitKind.GUARD
        hatchlings.count { it.selected } == 1 && selectedUnitCount() == 1 -> UnitKind.HATCHLING
        spreaders.count { it.selected } == 1 && selectedUnitCount() == 1 -> UnitKind.SPREADER
        else -> null
    }

    private fun singleSelectedUnitTitle(): String = singleSelectedUnitInfo().first.uppercase()

    private fun singleSelectedUnitInfo(): Triple<String, String, Int> {
        drones.firstOrNull { it.selected }?.let { drone ->
            val status = when (drone.state) {
                DroneState.IDLE -> "Idle worker"
                DroneState.MOVING -> "Moving"
                DroneState.HARVESTING -> "Harvesting"
                DroneState.RETURNING -> "Returning cargo"
                DroneState.MOVING_TO_BUILD -> "Heading to build"
                DroneState.BUILDING -> "Constructing"
            }
            return Triple("Worker Drone", "$status  HP ${drone.health}/${drone.maxHealth}", Color.rgb(70, 220, 235))
        }
        watcherUnits.firstOrNull { it.selected }?.let {
            return Triple("Watch Unit", "Patrol scout  HP ${it.health}/${it.maxHealth}", Color.rgb(112, 222, 255))
        }
        defenders.firstOrNull { it.selected }?.let {
            return Triple("Guard", "Defense unit  HP ${it.health}/${it.maxHealth}", Color.rgb(255, 105, 155))
        }
        hatchlings.firstOrNull { it.selected }?.let {
            return Triple("Hatchling", "Fast swarm unit  HP ${it.health}/${it.maxHealth}", Color.rgb(255, 188, 74))
        }
        spreaders.firstOrNull { it.selected }?.let {
            val status = if (it.state == SpreaderState.IDLE) "Waiting for an order" else "Executing spread order"
            return Triple("Spreader", "$status  HP ${it.health}/${it.maxHealth}", Color.rgb(188, 95, 235))
        }
        return Triple("Unit", "No active selection", Color.LTGRAY)
    }

    private fun setInspectInfo(title: String, body: String) {
        inspectTitle = title
        inspectBody = body
    }

    private fun clearAllUnitSelection() {
        drones.forEach { it.selected = false }
        watcherUnits.forEach { it.selected = false }
        defenders.forEach { it.selected = false }
        hatchlings.forEach { it.selected = false }
        spreaders.forEach { it.selected = false }
        commandMode = CommandMode.NONE
        clearFollowTarget()
    }

    private fun anyUnitsSelected(): Boolean =
        drones.any { it.selected } || watcherUnits.any { it.selected } || defenders.any { it.selected } ||
            hatchlings.any { it.selected } || spreaders.any { it.selected }

    private fun clearMenusAndSelection() {
        nestMenuOpen = false
        selectedWatcherId = null
        selectedBarrierKey = null
        buildMenuOpen = false
        shopMenuOpen = false
        if (buildPlacementType != null) cancelBuildPlacement(returnToCatalog = false)
        clearAllUnitSelection()
    }

    private fun clearFollowTarget() {
        followUnitKind = null
        followUnitId = null
    }

    private fun currentFollowTarget(): Pair<Float, Float>? = when (followUnitKind) {
        UnitKind.DRONE -> followUnitId?.let(::findDrone)?.let { Pair(it.x, it.y) }
        UnitKind.WATCHER -> followUnitId?.let { id -> watcherUnits.firstOrNull { it.id == id } }?.let { Pair(it.x, it.y) }
        UnitKind.GUARD -> followUnitId?.let { id -> defenders.firstOrNull { it.id == id } }?.let { Pair(it.x, it.y) }
        UnitKind.HATCHLING -> followUnitId?.let { id -> hatchlings.firstOrNull { it.id == id } }?.let { Pair(it.x, it.y) }
        UnitKind.SPREADER -> followUnitId?.let { id -> spreaders.firstOrNull { it.id == id } }?.let { Pair(it.x, it.y) }
        null -> null
    }

    private fun toggleFollowSelectedUnit() {
        val kind = singleSelectedUnitKind() ?: return
        val id = when (kind) {
            UnitKind.DRONE -> drones.firstOrNull { it.selected }?.id
            UnitKind.WATCHER -> watcherUnits.firstOrNull { it.selected }?.id
            UnitKind.GUARD -> defenders.firstOrNull { it.selected }?.id
            UnitKind.HATCHLING -> hatchlings.firstOrNull { it.selected }?.id
            UnitKind.SPREADER -> spreaders.firstOrNull { it.selected }?.id
        } ?: return
        if (followUnitKind == kind && followUnitId == id) {
            clearFollowTarget()
            showMessage("Camera follow disabled")
        } else {
            followUnitKind = kind
            followUnitId = id
            showMessage("Camera following selected unit")
        }
    }

    private fun isolateSelectionTo(kind: UnitKind) {
        drones.forEach { it.selected = kind == UnitKind.DRONE && it.selected }
        watcherUnits.forEach { it.selected = kind == UnitKind.WATCHER && it.selected }
        defenders.forEach { it.selected = kind == UnitKind.GUARD && it.selected }
        hatchlings.forEach { it.selected = kind == UnitKind.HATCHLING && it.selected }
        spreaders.forEach { it.selected = kind == UnitKind.SPREADER && it.selected }
        commandMode = CommandMode.NONE
        showMessage("Selection isolated to ${selectedUnitCount()} ${kind.name.lowercase()} unit(s)")
    }

    private fun stopSelectedUnits() {
        drones.filter { it.selected }.forEach { drone ->
            drone.state = DroneState.IDLE
            drone.targetResourceId = null
            drone.preferredResourceType = null
            drone.carryingAmount = 0f
            drone.carryingType = null
            drone.targetX = drone.x
            drone.targetY = drone.y
        }
        watcherUnits.filter { it.selected }.forEach {
            it.targetX = it.x
            it.targetY = it.y
            it.hasMoveOrder = false
        }
        defenders.filter { it.selected }.forEach {
            it.guardTargetX = it.x
            it.guardTargetY = it.y
            it.hasMoveOrder = false
        }
        hatchlings.filter { it.selected }.forEach {
            it.targetX = it.x
            it.targetY = it.y
            it.hasMoveOrder = false
        }
        spreaders.filter { it.selected }.forEach {
            it.state = SpreaderState.IDLE
            it.targetX = it.x
            it.targetY = it.y
        }
        commandMode = CommandMode.NONE
        showMessage("Selected units stopped")
    }

    private fun spreadOutSelectedUnits() {
        val selectedDrones = drones.filter { it.selected }
        val selectedWatchers = watcherUnits.filter { it.selected }
        val selectedGuards = defenders.filter { it.selected }
        val selectedBabies = hatchlings.filter { it.selected }
        val selectedSpreaders = spreaders.filter { it.selected }
        val total = selectedUnitCount()
        if (total == 0) return
        val centerX = (selectedDrones.sumOf { it.x.toDouble() } + selectedWatchers.sumOf { it.x.toDouble() } + selectedGuards.sumOf { it.x.toDouble() } +
            selectedBabies.sumOf { it.x.toDouble() } + selectedSpreaders.sumOf { it.x.toDouble() }).toFloat() / total
        val centerY = (selectedDrones.sumOf { it.y.toDouble() } + selectedWatchers.sumOf { it.y.toDouble() } + selectedGuards.sumOf { it.y.toDouble() } +
            selectedBabies.sumOf { it.y.toDouble() } + selectedSpreaders.sumOf { it.y.toDouble() }).toFloat() / total
        var index = 0
        fun targetFor(): Pair<Float, Float> {
            val angle = index * (6.28318f / max(1, total))
            val radius = 22f + (index % 3) * 12f
            index++
            return Pair(centerX + cos(angle) * radius, centerY + sin(angle) * radius)
        }
        selectedDrones.forEach {
            val p = targetFor()
            it.targetX = p.first
            it.targetY = p.second
            it.state = DroneState.MOVING
            it.preferredResourceType = null
            it.targetResourceId = null
        }
        selectedWatchers.forEach {
            val p = targetFor()
            it.targetX = p.first
            it.targetY = p.second
            it.hasMoveOrder = true
        }
        selectedGuards.forEach {
            val p = targetFor()
            it.guardTargetX = p.first
            it.guardTargetY = p.second
            it.hasMoveOrder = true
        }
        selectedBabies.forEach {
            val p = targetFor()
            it.targetX = p.first
            it.targetY = p.second
            it.hasMoveOrder = true
        }
        selectedSpreaders.forEach {
            val p = targetFor()
            it.targetX = p.first
            it.targetY = p.second
            it.state = SpreaderState.RELOCATING
        }
        showMessage("Selected units spread out")
    }

    private fun beginContextCommand() {
        val selectedCombatCount = watcherUnits.count { it.selected } + defenders.count { it.selected } + hatchlings.count { it.selected }
        val selectedSpreaderCount = spreaders.count { it.selected }
        when {
            selectedSpreaderCount > 0 && selectedCombatCount == 0 && drones.none { it.selected } -> {
                commandMode = CommandMode.BURROW_TARGET
                showMessage("Tap open explored ground to establish biofilm")
            }
            selectedCombatCount > 0 -> {
                commandMode = CommandMode.GUARD_TARGET
                showMessage("Tap a building or open ground to assign a guard post")
            }
            else -> showMessage("Select guards, hatchlings, watch units, or a spreader first")
        }
    }

    private fun issueGuardOrder(x: Float, y: Float, label: String) {
        val watchers = watcherUnits.filter { it.selected }
        val guards = defenders.filter { it.selected }
        val babies = hatchlings.filter { it.selected }
        val total = watchers.size + guards.size + babies.size
        val cols = max(1, sqrt(total.toFloat()).roundToInt())
        var index = 0
        watchers.forEach { unit ->
            val row = index / cols
            val col = index % cols
            unit.targetX = x + (col - (cols - 1) / 2f) * 28f
            unit.targetY = y + row * 24f
            unit.hasMoveOrder = true
            index++
        }
        guards.forEach { guard ->
            val row = index / cols
            val col = index % cols
            guard.guardTargetX = x + (col - (cols - 1) / 2f) * 34f
            guard.guardTargetY = y + row * 30f
            guard.hasMoveOrder = true
            index++
        }
        babies.forEach { hatchling ->
            val row = index / cols
            val col = index % cols
            hatchling.targetX = x + (col - (cols - 1) / 2f) * 18f
            hatchling.targetY = y + row * 16f
            hatchling.hasMoveOrder = true
            index++
        }
        showMessage("$total combat unit(s) assigned to guard $label")
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun issueSpreaderOrder(selected: List<Spreader>, x: Float, y: Float) {
        val cols = max(1, sqrt(selected.size.toFloat()).roundToInt())
        selected.forEachIndexed { index, spreader ->
            val row = index / cols
            val col = index % cols
            spreader.targetX = x + (col - (cols - 1) / 2f) * 42f
            spreader.targetY = y + row * 42f
            spreader.state = SpreaderState.MOVING_TO_BURROW
            spreader.selected = false
        }
        showMessage("${selected.size} spreader(s) moving to establish biofilm")
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun issueHarvestOrder(selected: List<Drone>, resource: ResourceNode) {
        selected.forEach { drone ->
            drone.preferredResourceType = resource.type
            drone.targetResourceId = resource.id
            drone.targetX = resource.x
            drone.targetY = resource.y
            drone.state = DroneState.HARVESTING
        }
        val name = if (resource.type == ResourceType.MINERAL) "mineral" else "gas"
        showMessage("${selected.size} drone(s) assigned to $name until reassigned")
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun issueMoveOrder(selected: List<Drone>, x: Float, y: Float) {
        val cols = max(1, sqrt(selected.size.toFloat()).roundToInt())
        selected.forEachIndexed { index, drone ->
            val row = index / cols
            val col = index % cols
            drone.preferredResourceType = null
            drone.targetResourceId = null
            drone.targetX = x + (col - (cols - 1) / 2f) * 18f
            drone.targetY = y + row * 18f
            drone.state = DroneState.MOVING
        }
        showMessage("Move order issued")
    }

    private fun issueDirectMoveOrder(x: Float, y: Float) {
        val selectedDrones = drones.filter { it.selected }
        val selectedWatchers = watcherUnits.filter { it.selected }
        val selectedGuards = defenders.filter { it.selected }
        val selectedBabies = hatchlings.filter { it.selected }
        val selectedSpreaders = spreaders.filter { it.selected }
        val total = selectedDrones.size + selectedWatchers.size + selectedGuards.size + selectedBabies.size + selectedSpreaders.size
        if (total <= 0) return

        val cols = max(1, sqrt(total.toFloat()).roundToInt())
        var index = 0
        fun nextTarget(spacing: Float): Pair<Float, Float> {
            val row = index / cols
            val col = index % cols
            index++
            return Pair(x + (col - (cols - 1) / 2f) * spacing, y + row * spacing)
        }

        selectedDrones.forEach { drone ->
            val target = nextTarget(20f)
            drone.preferredResourceType = null
            drone.targetResourceId = null
            drone.targetX = target.first
            drone.targetY = target.second
            drone.state = DroneState.MOVING
        }
        selectedWatchers.forEach { unit ->
            val target = nextTarget(24f)
            unit.targetX = target.first
            unit.targetY = target.second
            unit.hasMoveOrder = true
        }
        selectedGuards.forEach { guard ->
            val target = nextTarget(30f)
            guard.guardTargetX = target.first
            guard.guardTargetY = target.second
            guard.hasMoveOrder = true
        }
        selectedBabies.forEach { hatchling ->
            val target = nextTarget(18f)
            hatchling.targetX = target.first
            hatchling.targetY = target.second
            hatchling.hasMoveOrder = true
        }
        selectedSpreaders.forEach { spreader ->
            val target = nextTarget(28f)
            spreader.targetX = target.first
            spreader.targetY = target.second
            spreader.state = SpreaderState.RELOCATING
        }

        showMessage("$total unit(s) moving to the new location")
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun assignNextResourceOrIdle(drone: Drone) {
        val type = drone.preferredResourceType
        if (type == null) {
            drone.state = DroneState.IDLE
            return
        }
        val next = resourceNodes.filter { it.type == type && it.amount > 0.05f }
            .minByOrNull { distance(drone.x, drone.y, it.x, it.y) }
        if (next == null) {
            drone.state = DroneState.IDLE
            drone.targetResourceId = null
        } else {
            drone.targetResourceId = next.id
            drone.targetX = next.x
            drone.targetY = next.y
            drone.state = DroneState.HARVESTING
        }
    }

    private fun depositDroneCargo(drone: Drone) {
        val amount = floor(drone.carryingAmount).toInt().coerceAtLeast(1)
        when (drone.carryingType) {
            ResourceType.MINERAL -> minerals += amount
            ResourceType.GAS -> gas += amount
            null -> Unit
        }
        drone.carryingAmount = 0f
        drone.carryingType = null
    }

    private fun spawnSpreader() {
        val activeNest = nest ?: return
        val waiting = spreaders.count {
            it.state != SpreaderState.BURROWING && it.state != SpreaderState.BURROWED
        }
        if (waiting >= maxSpreadersWaiting) {
            showMessage("Direct the current spreaders before spawning more")
            return
        }
        if (minerals < spreaderMineralCost || gas < spreaderGasCost) {
            showMessage("Need ${spreaderMineralCost}M and ${spreaderGasCost}G for a spreader")
            return
        }
        minerals -= spreaderMineralCost
        gas -= spreaderGasCost
        val angle = random.nextFloat() * 6.28318f
        val spawnRadius = GameScale.NEST_FOOTPRINT_RADIUS + GameScale.CELL * 2.2f
        var spawnX = activeNest.x + cos(angle) * spawnRadius
        var spawnY = activeNest.y + sin(angle) * spawnRadius
        if (!isWalkable(spawnX, spawnY, GameScale.CELL * 0.55f)) {
            for (index in 0 until 12) {
                val testAngle = angle + index * (6.28318f / 12f)
                val testX = activeNest.x + cos(testAngle) * spawnRadius
                val testY = activeNest.y + sin(testAngle) * spawnRadius
                if (isWalkable(testX, testY, GameScale.CELL * 0.55f)) {
                    spawnX = testX
                    spawnY = testY
                    break
                }
            }
        }
        spreaders += Spreader(
            id = nextSpreaderId++,
            x = spawnX,
            y = spawnY,
            facingDir = facingCardinal(spawnX - activeNest.x, spawnY - activeNest.y),
        )
        nestMenuOpen = false
        showMessage("Spreader spawned. Tap it, then choose where it should burrow")
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun upgradeSelectedWatcher() {
        val watcher = selectedWatcherId?.let(::findWatcher) ?: return
        if (watcher.level >= 4) {
            showMessage("This NestWatcher is fully upgraded")
            return
        }
        val cost = watcherUpgradeCost(watcher)
        if (minerals < cost.first || gas < cost.second) {
            showMessage("Need ${cost.first}M and ${cost.second}G")
            return
        }
        minerals -= cost.first
        gas -= cost.second
        watcher.level++
        watcher.maxHealth += 25
        watcher.health = watcher.maxHealth
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        showMessage("NestWatcher level ${watcher.level}: total capacity ${droneCapacity()}")
    }

    private fun unlockSelectedBarrier() {
        val key = selectedBarrierKey ?: return
        val tile = tiles[key] ?: return
        if (tile.unlocked || !hasUnlockedNeighbor(tile.q, tile.r)) {
            showMessage("This barrier is not connected to your explored territory")
            return
        }
        val cost = barrierCost(tile)
        if (minerals < cost.first || gas < cost.second) {
            showMessage("Need ${cost.first}M and ${cost.second}G to break this barrier")
            return
        }
        minerals -= cost.first
        gas -= cost.second
        tile.unlocked = true
        generateTerrainForTile(key)
        generateFogFrontier(tile.q, tile.r, radius = 3)
        spawnResourceSetForTile(tile)
        selectedBarrierKey = null
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        showMessage("Fog wall dissolved. ${resourceFieldLabel(tile)} discovered")
        val center = hexCenter(tile.q, tile.r)
        cameraX = (cameraX + center.first) * 0.5f
        cameraY = (cameraY + center.second) * 0.5f
    }

    private fun buySpeedUpgrade() {
        val cost = speedUpgradeCost()
        if (minerals < cost) { showMessage("Need ${cost}M"); return }
        minerals -= cost
        speedLevel++
        showMessage("Drone movement upgraded")
    }

    private fun buyHarvestUpgrade() {
        val cost = harvestUpgradeCost()
        if (gas < cost) { showMessage("Need ${cost}G"); return }
        gas -= cost
        harvestLevel++
        showMessage("Drone harvesting upgraded")
    }

    private fun buyNestHealthUpgrade() {
        val activeNest = nest ?: return
        val cost = healthUpgradeCost()
        if (minerals < cost) { showMessage("Need ${cost}M"); return }
        minerals -= cost
        nestHealthLevel++
        activeNest.level++
        activeNest.maxHealth += 50
        activeNest.health = activeNest.maxHealth
        showMessage("Bionest reinforced")
    }

    private fun buyShopMinerals() {
        val cost = 8
        if (shopGold < cost) { showMessage("Need ${cost} shop gold"); return }
        shopGold -= cost
        minerals += 120
        showMessage("Purchased mineral cache: +120M")
    }

    private fun buyShopGas() {
        val cost = 8
        if (shopGold < cost) { showMessage("Need ${cost} shop gold"); return }
        shopGold -= cost
        gas += 120
        showMessage("Purchased gas cache: +120G")
    }

    private fun buyShopLarva() {
        val activeNest = nest
        val cost = 12
        if (activeNest == null) { showMessage("Place the Bionest before buying larvae"); return }
        if (shopGold < cost) { showMessage("Need ${cost} shop gold"); return }
        if (drones.size + larvae.size >= droneCapacity()) { showMessage("Drone capacity is full"); return }
        shopGold -= cost
        larvae += Larva(activeNest.x + 18f, activeNest.y)
        showMessage("Emergency larva delivered")
    }

    private fun droneCapacity(): Int = 8 + nestWatchers.sumOf { watcherCapacityBonus(it) }
    private fun watcherCapacityBonus(watcher: NestWatcher): Int = 6 + (watcher.level - 1) * 4
    private fun watcherUpgradeCost(watcher: NestWatcher): Pair<Int, Int> =
        Pair(28 + watcher.level * 18, 16 + watcher.level * 11)
    private fun speedUpgradeCost() = 25 + speedLevel * 20
    private fun harvestUpgradeCost() = 20 + harvestLevel * 18
    private fun healthUpgradeCost() = 40 + nestHealthLevel * 30

    private fun tileBiome(tile: HexTile): BiomeType {
        val center = hexCenter(tile.q, tile.r)
        val x = center.first * 0.0011f
        val y = center.second * 0.0011f
        val elevation = fbm(x, y, worldSeed xor 0x21551)
        val moisture = fbm(center.first * 0.00155f, center.second * 0.00155f, worldSeed xor 0x31A7F)
        val anomaly = fbm(center.first * 0.0019f, center.second * 0.0019f, worldSeed xor 0x44F19)
        return when {
            elevation > 0.76f -> BiomeType.HIGHLANDS
            elevation > 0.58f && moisture < 0.30f -> BiomeType.CANYON
            elevation < 0.31f && moisture > 0.58f -> BiomeType.MISTY_WETLAND
            anomaly > 0.80f -> BiomeType.RUINS
            moisture < 0.28f -> BiomeType.CRYSTAL_BARRENS
            else -> BiomeType.VERDANT_FOREST
        }
    }

    private fun biomeBaseColor(biome: BiomeType): Int = when (biome) {
        BiomeType.VERDANT_FOREST -> Color.rgb(105, 186, 84)
        BiomeType.MISTY_WETLAND -> Color.rgb(92, 167, 104)
        BiomeType.CRYSTAL_BARRENS -> Color.rgb(119, 155, 94)
        BiomeType.HIGHLANDS -> Color.rgb(116, 135, 108)
        BiomeType.CANYON -> Color.rgb(166, 121, 82)
        BiomeType.RUINS -> Color.rgb(122, 145, 104)
    }

    private fun biomeDarkColor(biome: BiomeType): Int = when (biome) {
        BiomeType.VERDANT_FOREST -> Color.rgb(20, 57, 39)
        BiomeType.MISTY_WETLAND -> Color.rgb(22, 68, 52)
        BiomeType.CRYSTAL_BARRENS -> Color.rgb(34, 60, 43)
        BiomeType.HIGHLANDS -> Color.rgb(44, 58, 54)
        BiomeType.CANYON -> Color.rgb(74, 48, 35)
        BiomeType.RUINS -> Color.rgb(46, 58, 47)
    }

    private fun biomeName(biome: BiomeType): String = when (biome) {
        BiomeType.VERDANT_FOREST -> "Verdant Forest"
        BiomeType.MISTY_WETLAND -> "Misty Wetland"
        BiomeType.CRYSTAL_BARRENS -> "Crystal Barrens"
        BiomeType.HIGHLANDS -> "Highlands"
        BiomeType.CANYON -> "Canyon Expanse"
        BiomeType.RUINS -> "Ancient Ruins"
    }

    private fun noiseHash(ix: Int, iy: Int, seed: Int): Float {
        var n = ix * 374761393 + iy * 668265263 + seed * 700001
        n = (n xor (n shr 13)) * 1274126177
        n = n xor (n shr 16)
        return (n and 0x7fffffff) / 2147483647f
    }

    private fun smoothStep(t: Float): Float = t * t * (3f - 2f * t)

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t

    private fun valueNoise(x: Float, y: Float, seed: Int): Float {
        val x0 = floor(x).toInt()
        val y0 = floor(y).toInt()
        val tx = smoothStep(x - x0)
        val ty = smoothStep(y - y0)
        val n00 = noiseHash(x0, y0, seed)
        val n10 = noiseHash(x0 + 1, y0, seed)
        val n01 = noiseHash(x0, y0 + 1, seed)
        val n11 = noiseHash(x0 + 1, y0 + 1, seed)
        return lerp(lerp(n00, n10, tx), lerp(n01, n11, tx), ty)
    }

    private fun fbm(x: Float, y: Float, seed: Int, octaves: Int = 4): Float {
        var total = 0f
        var amplitude = 0.5f
        var frequency = 1f
        var amplitudeSum = 0f
        repeat(octaves) { octave ->
            total += valueNoise(x * frequency, y * frequency, seed + octave * 92821) * amplitude
            amplitudeSum += amplitude
            amplitude *= 0.5f
            frequency *= 2f
        }
        return if (amplitudeSum <= 0f) 0.5f else total / amplitudeSum
    }

    private fun addTile(q: Int, r: Int, unlocked: Boolean) {
        if (hexDistanceFromOrigin(q, r) > selectedMapSize.radius) return
        val key = tileKey(q, r)
        if (tiles.containsKey(key)) return
        tiles[key] = HexTile(q, r, unlocked, (q * 73856093) xor (r * 19349663) xor worldSeed)
    }

    private fun hexDistanceFromOrigin(q: Int, r: Int): Int =
        (abs(q) + abs(r) + abs(q + r)) / 2

    private fun generateFogFrontier(q: Int, r: Int, radius: Int) {
        for (dq in -radius..radius) {
            for (dr in -radius..radius) {
                val localDistance = (abs(dq) + abs(dr) + abs(dq + dr)) / 2
                if (localDistance <= radius) addTile(q + dq, r + dr, unlocked = false)
            }
        }
    }

    private fun generateTerrainForTile(key: String) {
        val tile = tiles[key] ?: return
        if (!tile.unlocked) return
        val biome = tileBiome(tile)
        if (waterFeatures.none { it.tileKey == key }) generateWaterForTile(tile)
        if (landmarks.none { it.tileKey == key }) generateLandmarksForTile(tile, biome)

        if (obstacles.none { it.tileKey == key }) {
            val seeded = Random(tile.seed)
            val count = when (biome) {
                BiomeType.VERDANT_FOREST -> 46 + abs(tile.seed % 18)
                BiomeType.MISTY_WETLAND -> 33 + abs(tile.seed % 16)
                BiomeType.CRYSTAL_BARRENS -> 26 + abs(tile.seed % 12)
                BiomeType.HIGHLANDS -> 24 + abs(tile.seed % 14)
                BiomeType.CANYON -> 18 + abs(tile.seed % 10)
                BiomeType.RUINS -> 22 + abs(tile.seed % 11)
            }
            repeat(count) { index ->
                var placed = false
                var attempts = 0
                while (!placed && attempts < 40) {
                    attempts++
                    val point = randomPointInTile(tile, margin = GameScale.CELL * 1.5f, seeded)
                    val center = hexCenter(tile.q, tile.r)
                    if (tile.q == 0 && tile.r == 0 && distance(point.first, point.second, center.first, center.second) < GameScale.CELL * 10f) continue
                    val type = when {
                        biome == BiomeType.HIGHLANDS || biome == BiomeType.CANYON -> if (index % 4 == 0) ObstacleType.BUSH else ObstacleType.ROCK
                        biome == BiomeType.CRYSTAL_BARRENS -> if (index % 5 == 0) ObstacleType.TREE else ObstacleType.ROCK
                        biome == BiomeType.RUINS -> if (index % 2 == 0) ObstacleType.ROCK else ObstacleType.BUSH
                        index % 5 == 0 -> ObstacleType.ROCK
                        index % 3 == 0 -> ObstacleType.BUSH
                        else -> ObstacleType.TREE
                    }
                    val radius = when (type) {
                        ObstacleType.TREE -> GameScale.CELL * (1.25f + seeded.nextFloat() * 0.55f)
                        ObstacleType.ROCK -> GameScale.CELL * (1.0f + seeded.nextFloat() * 0.50f)
                        ObstacleType.BUSH -> GameScale.CELL * (0.75f + seeded.nextFloat() * 0.45f)
                    }
                    if (isPointInWater(point.first, point.second, radius + GameScale.CELL * 0.25f)) continue
                    if (obstacles.none { distance(point.first, point.second, it.x, it.y) < radius + it.radius + GameScale.CELL * 0.5f }) {
                        obstacles += Obstacle(nextObstacleId++, key, type, point.first, point.second, radius)
                        placed = true
                    }
                }
            }
        }

        if (enemyCamps.none { it.tileKey == key }) generateEnemyCampForTile(tile)
        if (wildAnimals.none { it.tileKey == key }) generateWildAnimalsForTile(tile)
    }

    private fun generateLandmarksForTile(tile: HexTile, biome: BiomeType) {
        val key = tileKey(tile.q, tile.r)
        val seeded = Random(tile.seed xor 0x11477)
        val chance = abs((tile.seed xor 0x41F55) % 100)
        val type = when {
            biome == BiomeType.HIGHLANDS && chance < 70 -> LandmarkType.MOUNTAIN
            biome == BiomeType.CANYON && chance < 72 -> LandmarkType.CANYON
            biome == BiomeType.RUINS && chance < 78 -> LandmarkType.RUIN
            biome == BiomeType.VERDANT_FOREST && chance < 22 -> LandmarkType.GROVE
            else -> null
        } ?: return
        val point = randomPointInTile(tile, margin = GameScale.CELL * 6f, seeded)
        if (tile.q == 0 && tile.r == 0) {
            val center = hexCenter(tile.q, tile.r)
            if (distance(point.first, point.second, center.first, center.second) < GameScale.CELL * 10f) return
        }
        val radius = when (type) {
            LandmarkType.RUIN -> GameScale.CELL * 3f
            LandmarkType.MOUNTAIN -> GameScale.CELL * 5f
            LandmarkType.CANYON -> GameScale.CELL * 4.5f
            LandmarkType.GROVE -> GameScale.CELL * 4f
        }
        if (isPointInWater(point.first, point.second, radius + GameScale.CELL)) return
        landmarks += Landmark(nextLandmarkId++, key, type, point.first, point.second, radius)
    }

    private fun generateWaterForTile(tile: HexTile) {
        val key = tileKey(tile.q, tile.r)
        val center = hexCenter(tile.q, tile.r)
        val elevation = fbm(center.first * 0.0012f, center.second * 0.0012f, worldSeed xor 0xAA11)
        val moisture = fbm(center.first * 0.00165f, center.second * 0.00165f, worldSeed xor 0xBB51)
        val riverBand = abs(fbm(center.first * 0.00185f, center.second * 0.00185f, worldSeed xor 0xCC87) - 0.5f)
        val flow = fbm(center.first * 0.00085f, center.second * 0.00085f, worldSeed xor 0xDD77) * 6.28318f

        if (elevation < 0.16f) {
            val edgeAngle = flow
            val x = center.first + cos(edgeAngle) * (hexRadius * 0.84f)
            val y = center.second + sin(edgeAngle) * (hexRadius * 0.84f)
            waterFeatures += WaterFeature(nextWaterId++, key, WaterType.OCEAN, x, y, x, y, GameScale.CELL * 13f)
        }

        if (moisture > 0.63f && elevation < 0.35f) {
            val offAngle = flow + 1.7f
            val lakeX = center.first + cos(offAngle) * GameScale.CELL * 5f
            val lakeY = center.second + sin(offAngle) * GameScale.CELL * 3.5f
            waterFeatures += WaterFeature(nextWaterId++, key, WaterType.LAKE, lakeX, lakeY, lakeX, lakeY, GameScale.CELL * (3.8f + moisture * 2.2f))
        }

        if (riverBand < 0.05f && elevation in 0.18f..0.82f) {
            val dx = cos(flow) * hexRadius * 0.92f
            val dy = sin(flow) * hexRadius * 0.92f
            waterFeatures += WaterFeature(
                nextWaterId++, key, WaterType.RIVER,
                center.first - dx, center.second - dy,
                center.first + dx, center.second + dy,
                GameScale.CELL * (1.35f + moisture * 1.2f),
            )
        }
    }

    private fun generateWildAnimalsForTile(tile: HexTile) {
        val key = tileKey(tile.q, tile.r)
        val count = 3 + abs(tile.seed % 4)
        repeat(count) { index ->
            val point = randomWalkablePoint(tile, GameScale.CELL)
            val type = when (index % 3) {
                0 -> AlienAnimalType.GRAZER
                1 -> AlienAnimalType.HOPPER
                else -> AlienAnimalType.STRIDER
            }
            wildAnimals += WildAnimal(
                id = nextWildAnimalId++,
                tileKey = key,
                type = type,
                x = point.first,
                y = point.second,
                targetX = point.first,
                targetY = point.second,
                speed = when (type) {
                    AlienAnimalType.GRAZER -> GameScale.CELL
                    AlienAnimalType.HOPPER -> GameScale.CELL * 1.75f
                    AlienAnimalType.STRIDER -> GameScale.CELL * 1.3f
                },
                wanderTimer = 1f + random.nextFloat() * 5f,
                phase = random.nextFloat() * 6.28318f,
            )
        }
    }

    private fun generateEnemyCampForTile(tile: HexTile) {
        val key = tileKey(tile.q, tile.r)
        if (!tile.unlocked || enemyCamps.any { it.tileKey == key }) return
        val campRoll = abs((tile.seed xor 0x4C731) % 100)
        if (!(tile.q == 0 && tile.r == 0) && campRoll >= 58) return

        val seeded = Random(tile.seed xor 0x7A29)
        val center = hexCenter(tile.q, tile.r)
        var campPoint: Pair<Float, Float>? = null
        repeat(120) {
            val point = randomPointInTile(tile, margin = GameScale.CELL * 5f, seeded)
            if (tile.q == 0 && tile.r == 0 && distance(point.first, point.second, center.first, center.second) < GameScale.CELL * 12f) {
                return@repeat
            }
            if (isPointInWater(point.first, point.second, GameScale.CELL * 2.25f)) return@repeat
            if (obstacles.any { distance(point.first, point.second, it.x, it.y) < it.radius + GameScale.CELL * 2.25f }) return@repeat
            if (enemyCamps.any { distance(point.first, point.second, it.x, it.y) < GameScale.CELL * 16f }) return@repeat
            campPoint = point
            return@repeat
        }
        val point = campPoint ?: return
        val population = 2 + abs((tile.seed xor 0x2D41) % 7)
        val maxHealth = 220 + population * 28
        val reward = campGoldBaseReward + population * 3
        val camp = EnemyCamp(
            id = nextEnemyCampId++,
            tileKey = key,
            x = point.first,
            y = point.second,
            populationTarget = population,
            health = maxHealth,
            maxHealth = maxHealth,
            goldReward = reward,
        )
        enemyCamps += camp
        repeat(population) { spawnPrimitiveEnemy(camp) }
    }

    private fun spawnPrimitiveEnemy(camp: EnemyCamp) {
        val angle = random.nextFloat() * 6.28318f
        val radius = GameScale.CELL * (1.5f + random.nextFloat() * 2.5f)
        var x = camp.x + cos(angle) * radius
        var y = camp.y + sin(angle) * radius
        if (!isWalkable(x, y, 8f)) {
            x = camp.x
            y = camp.y + GameScale.CELL * 1.5f
        }
        primitiveEnemies += PrimitiveEnemy(
            id = nextPrimitiveEnemyId++,
            campId = camp.id,
            x = x,
            y = y,
            targetX = x,
            targetY = y,
            facingDir = facingCardinal(cos(angle), sin(angle)),
            wanderTimer = random.nextFloat() * 3f,
            phase = random.nextFloat() * 6.28318f,
        )
    }

    private fun randomWalkablePoint(tile: HexTile, margin: Float): Pair<Float, Float> {
        repeat(100) {
            val point = randomPointInTile(tile, margin)
            if (isWalkable(point.first, point.second, 10f)) return point
        }
        return hexCenter(tile.q, tile.r)
    }

    private fun randomPointInTile(tile: HexTile, margin: Float, seeded: Random = random): Pair<Float, Float> {
        val center = hexCenter(tile.q, tile.r)
        repeat(100) {
            val angle = seeded.nextFloat() * 6.28318f
            val radius = sqrt(seeded.nextFloat()) * (hexRadius - margin)
            val x = center.first + cos(angle) * radius
            val y = center.second + sin(angle) * radius
            if (pointInsideHex(x, y, center.first, center.second, hexRadius - margin)) return Pair(x, y)
        }
        return center
    }

    private fun tileAtWorld(x: Float, y: Float): HexTile? = tiles.values
        .filter { tile ->
            val center = hexCenter(tile.q, tile.r)
            pointInsideHex(x, y, center.first, center.second, hexRadius)
        }
        .minByOrNull { tile ->
            val center = hexCenter(tile.q, tile.r)
            distance(x, y, center.first, center.second)
        }

    private fun pointInsideHex(x: Float, y: Float, cx: Float, cy: Float, radius: Float): Boolean {
        val dx = abs(x - cx) / radius
        val dy = abs(y - cy) / radius
        return dx <= 1f && dy <= sqrt3 / 2f && sqrt3 * dx + dy <= sqrt3
    }

    private fun isInGoo(x: Float, y: Float): Boolean =
        gooPatches.any { distance(x, y, it.x, it.y) <= it.radius }

    private fun isPointInWater(x: Float, y: Float, extraRadius: Float = 0f): Boolean =
        waterFeatures.any { water ->
            if (!isTileUnlocked(water.tileKey)) return@any false
            when (water.type) {
                WaterType.RIVER -> distancePointToSegment(x, y, water.x1, water.y1, water.x2, water.y2) <= water.radius + extraRadius
                WaterType.LAKE, WaterType.OCEAN -> distance(x, y, water.x1, water.y1) <= water.radius + extraRadius
            }
        }

    private fun distancePointToSegment(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        val lengthSq = dx * dx + dy * dy
        if (lengthSq <= 0.001f) return distance(px, py, x1, y1)
        val t = (((px - x1) * dx + (py - y1) * dy) / lengthSq).coerceIn(0f, 1f)
        return distance(px, py, x1 + dx * t, y1 + dy * t)
    }

    private fun obstacleBlockingRadius(obstacle: Obstacle): Float = when (obstacle.type) {
        ObstacleType.TREE -> obstacle.radius * 0.80f
        ObstacleType.ROCK -> obstacle.radius * 0.86f
        ObstacleType.BUSH -> obstacle.radius * 0.42f
    }

    private fun isBlockedByStructure(x: Float, y: Float, radius: Float): Boolean {
        nest?.let {
            if (distance(x, y, it.x, it.y) < radius + GameScale.NEST_FOOTPRINT_RADIUS) return true
        }
        if (biospewers.any { distance(x, y, it.x, it.y) < radius + GameScale.BIOSPEWER_FOOTPRINT_RADIUS }) return true
        if (nestWatchers.any { distance(x, y, it.x, it.y) < radius + GameScale.WATCHER_FOOTPRINT_RADIUS }) return true
        if (spreaders.any {
                (it.state == SpreaderState.BURROWED || it.state == SpreaderState.BURROWING) &&
                    distance(x, y, it.x, it.y) < radius + GameScale.CELL * 1.35f
            }) return true
        return false
    }

    private fun resolvePointOutsideObstacles(x: Float, y: Float, radius: Float, seed: Int): Pair<Float, Float> {
        var px = x
        var py = y
        repeat(4) { pass ->
            var changed = false
            obstacles.filter { isTileUnlocked(it.tileKey) }.forEach { obstacle ->
                val minimumDistance = radius + obstacleBlockingRadius(obstacle)
                var dx = px - obstacle.x
                var dy = py - obstacle.y
                var dist = hypot(dx, dy)
                if (dist >= minimumDistance) return@forEach
                if (dist < 0.001f) {
                    val angle = ((seed * 0.618f) + pass * 1.37f) % 6.28318f
                    dx = cos(angle)
                    dy = sin(angle)
                    dist = 1f
                }
                px = obstacle.x + dx / dist * (minimumDistance + 1f)
                py = obstacle.y + dy / dist * (minimumDistance + 1f)
                changed = true
            }
            fun resolveAgainst(cx: Float, cy: Float, blockerRadius: Float) {
                val minimumDistance = radius + blockerRadius
                var dx = px - cx
                var dy = py - cy
                var dist = hypot(dx, dy)
                if (dist >= minimumDistance) return
                if (dist < 0.001f) {
                    val angle = ((seed * 0.731f) + pass * 1.11f) % 6.28318f
                    dx = cos(angle)
                    dy = sin(angle)
                    dist = 1f
                }
                px = cx + dx / dist * (minimumDistance + 1f)
                py = cy + dy / dist * (minimumDistance + 1f)
                changed = true
            }
            nest?.let { resolveAgainst(it.x, it.y, GameScale.NEST_FOOTPRINT_RADIUS) }
            biospewers.forEach { resolveAgainst(it.x, it.y, GameScale.BIOSPEWER_FOOTPRINT_RADIUS) }
            nestWatchers.forEach { resolveAgainst(it.x, it.y, GameScale.WATCHER_FOOTPRINT_RADIUS) }
            spreaders.forEach {
                if (it.state == SpreaderState.BURROWED || it.state == SpreaderState.BURROWING) {
                    resolveAgainst(it.x, it.y, GameScale.CELL * 1.35f)
                }
            }
            if (!changed) return Pair(px, py)
        }
        return Pair(px, py)
    }

    private fun resolveUnitObstacleOverlaps() {
        drones.forEach { unit ->
            val oldX = unit.x
            val oldY = unit.y
            val p = resolvePointOutsideObstacles(unit.x, unit.y, GameScale.CELL * 0.30f, unit.id)
            unit.x = p.first
            unit.y = p.second
            if (unit.state == DroneState.IDLE && distance(oldX, oldY, unit.x, unit.y) > 0.1f) {
                unit.targetX = unit.x
                unit.targetY = unit.y
            }
        }
        watcherUnits.forEach { unit ->
            val p = resolvePointOutsideObstacles(unit.x, unit.y, GameScale.CELL * 0.35f, unit.id + 1000)
            unit.x = p.first
            unit.y = p.second
            unit.patrolX = unit.x
            unit.patrolY = unit.y
            if (!unit.hasMoveOrder) {
                unit.targetX = unit.x
                unit.targetY = unit.y
            }
        }
        defenders.forEach { unit ->
            val p = resolvePointOutsideObstacles(unit.x, unit.y, GameScale.CELL * 0.45f, unit.id + 2000)
            unit.x = p.first
            unit.y = p.second
            unit.guardX = unit.x
            unit.guardY = unit.y
            if (!unit.hasMoveOrder) {
                unit.guardTargetX = unit.x
                unit.guardTargetY = unit.y
            }
        }
        hatchlings.forEach { unit ->
            val p = resolvePointOutsideObstacles(unit.x, unit.y, GameScale.CELL * 0.30f, unit.id + 3000)
            unit.x = p.first
            unit.y = p.second
            if (!unit.hasMoveOrder) {
                unit.targetX = unit.x
                unit.targetY = unit.y
            }
        }
        spreaders.filter { it.state != SpreaderState.BURROWED }.forEach { unit ->
            val wasHolding = unit.state == SpreaderState.IDLE
            val p = resolvePointOutsideObstacles(unit.x, unit.y, GameScale.CELL * 0.42f, unit.id + 4000)
            unit.x = p.first
            unit.y = p.second
            if (wasHolding) {
                unit.targetX = unit.x
                unit.targetY = unit.y
            }
        }
        wildAnimals.forEach { animal ->
            val p = resolvePointOutsideObstacles(animal.x, animal.y, GameScale.CELL * 0.34f, animal.id + 5000)
            animal.x = p.first
            animal.y = p.second
        }
        primitiveEnemies.forEach { enemy ->
            val p = resolvePointOutsideObstacles(enemy.x, enemy.y, GameScale.CELL * 0.38f, enemy.id + 6000)
            enemy.x = p.first
            enemy.y = p.second
        }
    }

    private fun isWalkable(x: Float, y: Float, radius: Float): Boolean {
        val tile = tileAtWorld(x, y) ?: return false
        if (!tile.unlocked) return false
        if (isPointInWater(x, y, radius)) return false
        if (enemyCamps.any { isTileUnlocked(it.tileKey) && distance(x, y, it.x, it.y) < radius + GameScale.ENEMY_CAMP_RADIUS * 0.72f }) return false
        if (landmarks.any { isTileUnlocked(it.tileKey) && distance(x, y, it.x, it.y) < radius + it.radius * 0.76f }) return false
        if (isBlockedByStructure(x, y, radius)) return false
        return obstacles.none { isTileUnlocked(it.tileKey) && distance(x, y, it.x, it.y) < radius + obstacleBlockingRadius(it) }
    }

    private fun isBuildable(x: Float, y: Float, radius: Float): Boolean {
        val tile = tileAtWorld(x, y) ?: return false
        if (!tile.unlocked) return false
        if (isPointInWater(x, y, radius)) return false
        if (!pointInsideHex(x, y, hexCenter(tile.q, tile.r).first, hexCenter(tile.q, tile.r).second, hexRadius - radius - GameScale.CELL * 0.5f)) return false
        if (landmarks.any { isTileUnlocked(it.tileKey) && distance(x, y, it.x, it.y) < radius + it.radius }) return false
        if (obstacles.any { isTileUnlocked(it.tileKey) && distance(x, y, it.x, it.y) < radius + it.radius }) return false
        if (resourceNodes.any { distance(x, y, it.x, it.y) < radius + resourcePatchRadius(it) }) return false
        if (enemyCamps.any { isTileUnlocked(it.tileKey) && distance(x, y, it.x, it.y) < radius + GameScale.ENEMY_CAMP_RADIUS }) return false
        if (nest?.let { distance(x, y, it.x, it.y) < radius + GameScale.NEST_FOOTPRINT_RADIUS + GameScale.BUILD_SPACING } == true) return false
        if (biospewers.any { distance(x, y, it.x, it.y) < radius + GameScale.BIOSPEWER_FOOTPRINT_RADIUS + GameScale.BUILD_SPACING }) return false
        if (nestWatchers.any { distance(x, y, it.x, it.y) < radius + GameScale.WATCHER_FOOTPRINT_RADIUS + GameScale.BUILD_SPACING }) return false
        if (spreaders.any { (it.state == SpreaderState.BURROWED || it.state == SpreaderState.BURROWING) && distance(x, y, it.x, it.y) < radius + GameScale.CELL * 1.35f + GameScale.BUILD_SPACING }) return false
        if (buildSites.any { site ->
                val siteRadius = when (site.type) {
                    BuildingType.BIOSPEWER -> GameScale.BIOSPEWER_FOOTPRINT_RADIUS
                    BuildingType.NEST_WATCHER -> GameScale.WATCHER_FOOTPRINT_RADIUS
                }
                distance(x, y, site.x, site.y) < radius + siteRadius + GameScale.BUILD_SPACING
            }) return false
        return true
    }

    private fun barrierCost(tile: HexTile): Pair<Int, Int> {
        val distance = hexDistance(tile.q, tile.r).coerceAtLeast(1)
        return Pair(45 + (distance - 1) * 25, 25 + (distance - 1) * 14)
    }

    private fun hasUnlockedNeighbor(q: Int, r: Int): Boolean = hexDirections.any {
        tiles[tileKey(q + it.first, r + it.second)]?.unlocked == true
    }

    private fun hexDistance(q: Int, r: Int): Int = (abs(q) + abs(r) + abs(q + r)) / 2

    private val hexDirections: List<Pair<Int, Int>>
        get() = listOf(
            Pair(1, 0), Pair(1, -1), Pair(0, -1), Pair(-1, 0), Pair(-1, 1), Pair(0, 1),
        )

    private fun hexCenter(q: Int, r: Int): Pair<Float, Float> = Pair(
        hexRadius * 1.5f * q,
        hexRadius * sqrt3 * (r + q / 2f),
    )

    private fun makeHexPath(cx: Float, cy: Float, radius: Float) {
        path.reset()
        for (i in 0 until 6) {
            val angle = Math.toRadians((60.0 * i).toDouble())
            val x = cx + cos(angle).toFloat() * radius
            val y = cy + sin(angle).toFloat() * radius
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    private fun playfieldRect(): RectF = RectF(
        sidebarWidth,
        0f,
        width.toFloat(),
        if (hasBottomMenu) menuTop() else height.toFloat(),
    )

    private fun worldViewportRect(): RectF = RectF(sidebarWidth, 0f, width.toFloat(), height.toFloat())

    private fun worldToScreen(x: Float, y: Float): Pair<Float, Float> {
        val viewport = worldViewportRect()
        return Pair(viewport.centerX() + (x - cameraX) * zoom, viewport.centerY() + (y - cameraY) * zoom)
    }

    private fun screenToWorld(x: Float, y: Float): Pair<Float, Float> {
        val viewport = worldViewportRect()
        return Pair(cameraX + (x - viewport.centerX()) / zoom, cameraY + (y - viewport.centerY()) / zoom)
    }

    private fun setZoomAroundScreen(newZoom: Float, screenX: Float, screenY: Float) {
        val before = screenToWorld(screenX, screenY)
        zoom = newZoom.coerceIn(minZoom, maxZoom)
        val after = screenToWorld(screenX, screenY)
        cameraX += before.first - after.first
        cameraY += before.second - after.second
        clampCameraToMap()
        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun startPinch(event: MotionEvent) {
        if (event.pointerCount < 2) return
        pinching = true
        panning = false
        selectionRingActive = false
        pinchStartDistance = pointerDistance(event).coerceAtLeast(1f)
        pinchStartZoom = zoom
        val midX = (event.getX(0) + event.getX(1)) / 2f
        val midY = (event.getY(0) + event.getY(1)) / 2f
        val anchor = screenToWorld(midX, midY)
        pinchAnchorWorldX = anchor.first
        pinchAnchorWorldY = anchor.second
    }

    private fun updatePinch(event: MotionEvent) {
        if (event.pointerCount < 2) return
        val newZoom = (pinchStartZoom * pointerDistance(event) / pinchStartDistance).coerceIn(minZoom, maxZoom)
        zoom = newZoom
        val midX = (event.getX(0) + event.getX(1)) / 2f
        val midY = (event.getY(0) + event.getY(1)) / 2f
        val now = screenToWorld(midX, midY)
        cameraX += pinchAnchorWorldX - now.first
        cameraY += pinchAnchorWorldY - now.second
        clampCameraToMap()
    }

    private fun clampCameraToMap() {
        if (tiles.isEmpty()) return
        val viewport = worldViewportRect()
        val worldHalfWidth = viewport.width() / (2f * zoom.coerceAtLeast(0.04f))
        val worldHalfHeight = viewport.height() / (2f * zoom.coerceAtLeast(0.04f))
        val mapHalfWidth = hexRadius * (1.5f * selectedMapSize.radius + 1f)
        val mapHalfHeight = hexRadius * sqrt3 * (selectedMapSize.radius + 0.65f)
        val limitX = max(0f, mapHalfWidth - worldHalfWidth * 0.34f)
        val limitY = max(0f, mapHalfHeight - worldHalfHeight * 0.34f)
        cameraX = cameraX.coerceIn(-limitX, limitX)
        cameraY = cameraY.coerceIn(-limitY, limitY)
    }

    private fun pointerDistance(event: MotionEvent): Float =
        hypot(event.getX(0) - event.getX(1), event.getY(0) - event.getY(1)).toFloat()

    private fun zoomButtonRects(): List<RectF> {
        val play = playfieldRect()
        val size = 34f * density
        val gap = 5f * density
        val right = play.right - 8f * density
        val top = play.top + 8f * density
        return listOf(
            RectF(right - size, top, right, top + size),
            RectF(right - size, top + size + gap, right, top + size * 2f + gap),
        )
    }

    private fun sidebarToggleRect(): RectF = RectF(0f, 0f, sidebarWidth, 32f * density)
    private fun menuTop(): Float = height - bottomMenuHeight

    private fun menuButtonRects(count: Int): List<RectF> {
        val left = sidebarWidth + 8f * density
        val right = width - 8f * density
        val top = menuTop() + 38f * density
        val bottom = height - 8f * density
        val gap = 7f * density
        if (isPortrait && count >= 3) {
            val cols = when {
                count == 3 -> 3
                count >= 5 -> 3
                else -> 2
            }
            val rows = (count + cols - 1) / cols
            val buttonW = (right - left - gap * (cols - 1)) / cols
            val buttonH = (bottom - top - gap * (rows - 1)) / rows
            return (0 until count).map { index ->
                val row = index / cols
                val col = index % cols
                RectF(left + col * (buttonW + gap), top + row * (buttonH + gap),
                    left + col * (buttonW + gap) + buttonW, top + row * (buttonH + gap) + buttonH)
            }
        }
        val buttonW = (right - left - gap * (count - 1)) / count
        return (0 until count).map { index ->
            RectF(left + index * (buttonW + gap), top, left + index * (buttonW + gap) + buttonW, bottom)
        }
    }

    private fun mainMenuButtonRects(): List<RectF> {
        val panel = if (isPortrait) {
            RectF(width * 0.10f, height * 0.08f, width * 0.90f, height * 0.88f)
        } else {
            RectF(width * 0.26f, height * 0.10f, width * 0.74f, height * 0.88f)
        }
        val widthPx = min(panel.width() - 38f * density, 280f * density)
        val left = panel.centerX() - widthPx / 2f
        val top = panel.top + if (isPortrait) 124f * density else 108f * density
        val h = if (isPortrait) 50f * density else 44f * density
        val gap = 12f * density
        return (0 until 4).map { index ->
            val y = top + index * (h + gap)
            RectF(left, y, left + widthPx, y + h)
        }
    }

    private fun bioBookPanelRect(): RectF = if (isPortrait) {
        RectF(width * 0.045f, height * 0.025f, width * 0.955f, height * 0.965f)
    } else {
        RectF(width * 0.10f, height * 0.035f, width * 0.90f, height * 0.965f)
    }

    private fun bioBookTabRects(): List<RectF> {
        val panel = bioBookPanelRect()
        val left = panel.left + 18f * density
        val right = panel.right - 18f * density
        val top = panel.top + 50f * density
        val gap = 5f * density
        val cols = if (isPortrait) 3 else 5
        val widthPx = (right - left - gap * (cols - 1)) / cols
        val heightPx = 28f * density
        return BioBookSection.entries.indices.map { index ->
            val row = index / cols
            val col = index % cols
            RectF(
                left + col * (widthPx + gap),
                top + row * (heightPx + gap),
                left + col * (widthPx + gap) + widthPx,
                top + row * (heightPx + gap) + heightPx,
            )
        }
    }

    private fun bioBookCardRects(count: Int): List<RectF> {
        if (count <= 0) return emptyList()
        val panel = bioBookPanelRect()
        val tabs = bioBookTabRects()
        val left = panel.left + 16f * density
        val right = panel.right - 16f * density
        val top = tabs.maxOf { it.bottom } + 9f * density
        val bottom = panel.bottom - 54f * density
        val cols = if (isPortrait) 2 else 3
        val rows = (count + cols - 1) / cols
        val gap = 7f * density
        val cardW = (right - left - gap * (cols - 1)) / cols
        val availableHeight = (bottom - top - gap * (rows - 1)) / rows.coerceAtLeast(1)
        val cardH = min(availableHeight, if (isPortrait) 150f * density else 170f * density)
        return (0 until count).map { index ->
            val row = index / cols
            val col = index % cols
            RectF(
                left + col * (cardW + gap),
                top + row * (cardH + gap),
                left + col * (cardW + gap) + cardW,
                top + row * (cardH + gap) + cardH,
            )
        }
    }

    private fun bioBookBackRect(): RectF {
        val panel = bioBookPanelRect()
        val size = 40f * density
        return RectF(panel.left + 16f * density, panel.bottom - size - 9f * density, panel.left + 16f * density + size, panel.bottom - 9f * density)
    }

    private fun settingsPanelRect(): RectF {
        val maxWidth = width * if (isPortrait) 0.88f else 0.62f
        val maxHeight = height * if (isPortrait) 0.46f else 0.72f
        val scale = min(maxWidth / uiPanelLargeV2.width.toFloat(), maxHeight / uiPanelLargeV2.height.toFloat())
        val widthPx = uiPanelLargeV2.width * scale
        val heightPx = uiPanelLargeV2.height * scale
        val left = width * 0.5f - widthPx * 0.5f
        val top = height * if (isPortrait) 0.12f else 0.10f
        return RectF(left, top, left + widthPx, top + heightPx)
    }

    private fun worldSetupPanelRect(): RectF {
        return if (isPortrait) {
            RectF(width * 0.06f, height * 0.025f, width * 0.94f, height * 0.955f)
        } else {
            RectF(width * 0.17f, height * 0.035f, width * 0.83f, height * 0.965f)
        }
    }

    private fun worldSetupRects(): WorldSetupRects {
        val panel = worldSetupPanelRect()
        val left = panel.left + panel.width() * 0.075f
        val right = panel.right - panel.width() * 0.075f
        val contentWidth = right - left
        val nameTop = panel.top + panel.height() * if (isPortrait) 0.285f else 0.25f
        val fieldHeight = panel.height() * if (isPortrait) 0.075f else 0.085f
        val nameField = RectF(left, nameTop, right, nameTop + fieldHeight)

        val sizeTop = panel.top + panel.height() * if (isPortrait) 0.425f else 0.40f
        val sizeHeight = panel.height() * if (isPortrait) 0.095f else 0.11f
        val sizeGap = panel.width() * 0.025f
        val sizeWidth = (contentWidth - sizeGap * 2f) / 3f
        val sizeButtons = (0 until 3).map { index ->
            val x = left + index * (sizeWidth + sizeGap)
            RectF(x, sizeTop, x + sizeWidth, sizeTop + sizeHeight)
        }

        val seedTop = panel.top + panel.height() * if (isPortrait) 0.595f else 0.585f
        val randomWidth = contentWidth * 0.28f
        val seedGap = panel.width() * 0.025f
        val seedField = RectF(left, seedTop, right - randomWidth - seedGap, seedTop + fieldHeight)
        val randomButton = RectF(seedField.right + seedGap, seedTop, right, seedTop + fieldHeight)

        val createTop = panel.top + panel.height() * if (isPortrait) 0.735f else 0.745f
        val createHeight = panel.height() * if (isPortrait) 0.095f else 0.11f
        val createWidth = contentWidth * 0.72f
        val createButton = RectF(panel.centerX() - createWidth * 0.5f, createTop, panel.centerX() + createWidth * 0.5f, createTop + createHeight)

        val backSize = panel.height() * if (isPortrait) 0.075f else 0.09f
        val backButton = RectF(left, panel.bottom - backSize - panel.height() * 0.065f, left + backSize, panel.bottom - panel.height() * 0.065f)
        return WorldSetupRects(nameField, sizeButtons, seedField, randomButton, createButton, backButton)
    }

    private fun settingsButtonRects(): List<RectF> {
        val panel = settingsPanelRect()
        val widthPx = min(panel.width() - 48f * density, 290f * density)
        val left = panel.centerX() - widthPx / 2f
        val top = panel.top + panel.height() * 0.60f
        val h = panel.height() * 0.20f
        val backSize = 40f * density
        return listOf(
            RectF(left, top, left + widthPx, top + h),
            RectF(panel.left, panel.bottom + 10f * density, panel.left + backSize, panel.bottom + 10f * density + backSize),
        )
    }

    private fun unitCardRect(): RectF {
        val left = sidebarWidth + 8f * density
        val right = width - 8f * density
        return RectF(left, menuTop() + 34f * density, right, menuTop() + 76f * density)
    }

    private fun unitTypeChipRects(count: Int): List<RectF> {
        if (count <= 0) return emptyList()
        val left = sidebarWidth + 8f * density
        val right = width - 8f * density
        val top = menuTop() + 36f * density
        val gap = 6f * density
        val chipHeight = 36f * density
        val chipWidth = (right - left - gap * (count - 1)) / count
        return (0 until count).map { index ->
            RectF(left + index * (chipWidth + gap), top, left + index * (chipWidth + gap) + chipWidth, top + chipHeight)
        }
    }

    private fun unitCommandButtonRects(count: Int): List<RectF> {
        val left = sidebarWidth + 8f * density
        val right = width - 8f * density
        val gap = 6f * density
        val top = if (selectedUnitCount() == 1) menuTop() + 90f * density else menuTop() + 82f * density
        val bottom = height - 8f * density
        if (isPortrait && count >= 4) {
            val cols = 2
            val rows = (count + cols - 1) / cols
            val buttonW = (right - left - gap * (cols - 1)) / cols
            val buttonH = (bottom - top - gap * (rows - 1)) / rows
            return (0 until count).map { index ->
                val row = index / cols
                val col = index % cols
                RectF(left + col * (buttonW + gap), top + row * (buttonH + gap),
                    left + col * (buttonW + gap) + buttonW, top + row * (buttonH + gap) + buttonH)
            }
        }
        val buttonWidth = (right - left - gap * (count - 1)) / count
        return (0 until count).map { index ->
            RectF(left + index * (buttonWidth + gap), top, left + index * (buttonWidth + gap) + buttonWidth, bottom)
        }
    }

    private fun showMessage(text: String) {
        message = text
        messageTimer = 3.2f
    }

    private fun findResource(id: Int): ResourceNode? = resourceNodes.firstOrNull { it.id == id }
    private fun findBuildSite(id: Int): BuildSite? = buildSites.firstOrNull { it.id == id }
    private fun findDrone(id: Int): Drone? = drones.firstOrNull { it.id == id }
    private fun findWatcher(id: Int): NestWatcher? = nestWatchers.firstOrNull { it.id == id }
    private fun findResourceAt(x: Float, y: Float): ResourceNode? =
        resourceNodes.asReversed().firstOrNull {
            distance(x, y, it.x, it.y) <= resourcePatchRadius(it) + 8f / zoom.coerceAtLeast(0.45f)
        }
    private fun resourcePatchRadius(node: ResourceNode): Float =
        if (node.richnessTier >= 2) GameScale.RICH_RESOURCE_RADIUS else GameScale.RESOURCE_RADIUS
    private fun unitTapRadius(minimumWorldRadius: Float): Float =
        (30f * density / zoom.coerceAtLeast(0.08f)).coerceIn(minimumWorldRadius, GameScale.CELL * 3.2f)

    private fun findDroneAt(x: Float, y: Float): Drone? =
        drones.filter { distance(x, y, it.x, it.y) <= unitTapRadius(GameScale.CELL * 0.75f) }
            .minByOrNull { distance(x, y, it.x, it.y) }
    private fun findWatcherUnitAt(x: Float, y: Float): WatcherUnit? =
        watcherUnits.filter { distance(x, y, it.x, it.y) <= unitTapRadius(GameScale.CELL * 0.82f) }
            .minByOrNull { distance(x, y, it.x, it.y) }
    private fun findDefenderAt(x: Float, y: Float): Defender? =
        defenders.filter { distance(x, y, it.x, it.y) <= unitTapRadius(GameScale.CELL) }
            .minByOrNull { distance(x, y, it.x, it.y) }
    private fun findHatchlingAt(x: Float, y: Float): Hatchling? =
        hatchlings.filter { distance(x, y, it.x, it.y) <= unitTapRadius(GameScale.CELL * 0.72f) }
            .minByOrNull { distance(x, y, it.x, it.y) }
    private fun findSpreaderAt(x: Float, y: Float): Spreader? =
        spreaders.filter { distance(x, y, it.x, it.y) <= unitTapRadius(GameScale.CELL) }
            .minByOrNull { distance(x, y, it.x, it.y) }
    private fun isTileUnlocked(key: String): Boolean = tiles[key]?.unlocked == true
    private fun tileKey(q: Int, r: Int): String = "$q,$r"
    private fun isScreenVisible(x: Float, y: Float, radius: Float): Boolean {
        val viewport = worldViewportRect()
        return x + radius >= viewport.left && x - radius <= viewport.right && y + radius >= viewport.top && y - radius <= viewport.bottom
    }

    private fun isWorldVisible(x: Float, y: Float, worldRadius: Float): Boolean {
        val screen = worldToScreen(x, y)
        return isScreenVisible(screen.first, screen.second, worldRadius * zoom + 24f * density)
    }

    private fun resetTouchState() {
        touchDown = false
        touchStartedInPlayfield = false
        selectionRingActive = false
        selectionRingRadius = 0f
        panning = false
        pinching = false
    }

    private fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float = hypot(x2 - x1, y2 - y1)
}
