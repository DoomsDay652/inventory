# SkidCount Android Preview

This project wraps the tested SkidCount browser interface in a native Android app and adds Android-only features.

## Included in this first native pass

- Existing parts, full/partial/mixed skid receiving, table counts, adjustments, history, backups, and assembly recipes.
- Add Part label photo capture.
- Receipt label photo capture.
- Offline printed-text recognition through the bundled Google ML Kit Latin text model.
- Native app icon and home-screen launch.
- Home-screen widget with:
  - vertical swiping between parts,
  - Previous and Next buttons,
  - unopened-box and table counts,
  - an **Open 1 Box** action,
  - an **Open App** button.
- Native storage shared with the widget.
- Backup/CSV files saved to `Downloads/SkidCount`.
- A project-specific signing key so later APK builds can install as updates without erasing inventory.

## Important data note

The browser HTML file and installed Android app use separate storage. In the browser version:

1. Open **Settings**.
2. Tap **Download Backup**.
3. Install/open the APK.
4. Open **Settings → Restore** and select that backup file.

Do not uninstall the APK when applying a future update. Install the newer APK over the current one.

## Build the APK in Android Studio

This chat environment did not contain the Android SDK or Gradle compiler, so an APK binary could not be compiled here. The project is prepared for Android Studio:

1. Install a recent Android Studio release.
2. Open this `SkidCount_Android_Project` folder.
3. Allow Android Studio to install Android SDK Platform 35 and sync the Gradle project.
4. For a quick phone test, choose **Build → Build APK(s)**. Android Studio will create a signed debug APK under `app/build/outputs/apk/debug/`. This preview uses the same package name and included signing key as the release build so later builds can preserve its inventory.
5. For the updateable signed version, choose the **release** build variant and build the APK. The included Gradle signing configuration uses `skidcount-release.jks`.
6. Transfer the APK to the phone and allow installation from the file manager when Android asks.

The release APK normally appears under:

`app/build/outputs/apk/release/app-release.apk`

## Keep this private

`skidcount-release.jks` and `keystore.properties` are included so later versions can be signed with the same identity. Keep both files private and backed up. Anyone with them can sign an APK that Android would accept as a SkidCount update.

## Dependency note

The project pins stable build dependencies instead of requesting the newest available versions. Android Studio needs internet access during the first project sync to download Gradle, the Android build plugin, and ML Kit. Once the app is installed, OCR runs offline.

## Browser testing

`SkidCount_Browser_Test.html` remains included for quick workflow testing. Browser mode can save label photos, but dependable automatic OCR is provided by the APK project.
