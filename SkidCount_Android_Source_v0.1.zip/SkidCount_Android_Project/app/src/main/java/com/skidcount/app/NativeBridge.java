package com.skidcount.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class NativeBridge {
    private final Context context;
    private final WebView webView;
    private final TextRecognizer recognizer;
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();

    NativeBridge(Context context, WebView webView) {
        this.context = context.getApplicationContext();
        this.webView = webView;
        this.recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @JavascriptInterface
    public String getState() {
        return StateStore.getStateJson(context);
    }

    @JavascriptInterface
    public void syncState(String json) {
        if (json == null || json.isBlank()) {
            return;
        }
        try {
            new JSONObject(json);
            StateStore.saveStateJson(context, json);
        } catch (Exception ignored) {
            showToast("SkidCount could not save invalid inventory data");
        }
    }

    @JavascriptInterface
    public void recognizeText(String requestId, String dataUrl) {
        ioExecutor.execute(() -> {
            try {
                final int comma = dataUrl == null ? -1 : dataUrl.indexOf(',');
                final String encoded = comma >= 0 ? dataUrl.substring(comma + 1) : dataUrl;
                final byte[] bytes = Base64.decode(encoded, Base64.DEFAULT);
                final Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (bitmap == null) {
                    sendOcrResult(requestId, "", "The image could not be decoded");
                    return;
                }

                final InputImage image = InputImage.fromBitmap(bitmap, 0);
                recognizer.process(image)
                        .addOnSuccessListener(result -> sendOcrResult(requestId, result.getText(), ""))
                        .addOnFailureListener(error -> sendOcrResult(requestId, "", error.getMessage() == null ? "OCR failed" : error.getMessage()));
            } catch (Exception error) {
                sendOcrResult(requestId, "", error.getMessage() == null ? "OCR failed" : error.getMessage());
            }
        });
    }

    @JavascriptInterface
    public void saveTextFile(String filename, String mimeType, String content) {
        ioExecutor.execute(() -> {
            try {
                final String safeName = sanitizeFilename(filename);
                final ContentResolver resolver = context.getContentResolver();
                final ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mimeType == null || mimeType.isBlank() ? "text/plain" : mimeType);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/SkidCount");

                final Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) {
                    throw new IllegalStateException("Downloads location is unavailable");
                }
                try (OutputStream stream = resolver.openOutputStream(uri, "w")) {
                    if (stream == null) {
                        throw new IllegalStateException("The download file could not be opened");
                    }
                    stream.write((content == null ? "" : content).getBytes(StandardCharsets.UTF_8));
                }
                showToast("Saved to Downloads/SkidCount/" + safeName);
            } catch (Exception error) {
                showToast("Could not save the file: " + (error.getMessage() == null ? "unknown error" : error.getMessage()));
            }
        });
    }

    void close() {
        recognizer.close();
        ioExecutor.shutdownNow();
    }

    private void sendOcrResult(String requestId, String text, String error) {
        final String script = "window.onNativeOcrResult(" +
                JSONObject.quote(requestId == null ? "" : requestId) + "," +
                JSONObject.quote(text == null ? "" : text) + "," +
                JSONObject.quote(error == null ? "" : error) + ");";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void showToast(String message) {
        webView.post(() -> Toast.makeText(context, message, Toast.LENGTH_LONG).show());
    }

    private static String sanitizeFilename(String filename) {
        final String fallback = "skidcount-export.txt";
        if (filename == null || filename.isBlank()) {
            return fallback;
        }
        final String sanitized = filename.replaceAll("[^A-Za-z0-9._-]", "_");
        return sanitized.isBlank() ? fallback : sanitized;
    }
}
