package com.skidcount.app;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.Instant;
import java.util.UUID;

final class StateStore {
    static final String PREFS_NAME = "skidcount_native";
    static final String STATE_KEY = "state_json";

    private StateStore() {}

    static String getStateJson(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getString(STATE_KEY, "");
    }

    static void saveStateJson(Context context, String json) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(STATE_KEY, json == null ? "" : json)
                .apply();
        notifyWidgets(context);
    }

    static OpenBoxResult openBox(Context context, String partId) {
        if (partId == null || partId.isBlank()) {
            return new OpenBoxResult(false, "Part not found");
        }

        final String raw = getStateJson(context);
        if (raw == null || raw.isBlank()) {
            return new OpenBoxResult(false, "Open SkidCount and add a part first");
        }

        try {
            final JSONObject state = new JSONObject(raw);
            final JSONArray parts = state.optJSONArray("parts");
            if (parts == null) {
                return new OpenBoxResult(false, "Part not found");
            }

            JSONObject selected = null;
            for (int i = 0; i < parts.length(); i++) {
                final JSONObject part = parts.optJSONObject(i);
                if (part != null && partId.equals(part.optString("id"))) {
                    selected = part;
                    break;
                }
            }

            if (selected == null) {
                return new OpenBoxResult(false, "Part not found");
            }

            final double unopenedBoxes = selected.optDouble("unopenedBoxes", 0);
            if (unopenedBoxes < 1) {
                return new OpenBoxResult(false, "No unopened boxes for " + selected.optString("name", "this part"));
            }

            final double boxQty = selected.optDouble("boxQty", 0);
            selected.put("unopenedBoxes", unopenedBoxes - 1);
            selected.put("tableQty", selected.optDouble("tableQty", 0) + boxQty);

            final JSONObject transaction = new JSONObject();
            transaction.put("id", UUID.randomUUID().toString());
            transaction.put("type", "open");
            transaction.put("title", "Box opened");
            transaction.put("detail", selected.optString("name", "Part") + " · " + formatCount(boxQty) + " pieces moved to table");
            transaction.put("createdAt", Instant.now().toString());
            transaction.put("undone", false);

            final JSONArray deltas = new JSONArray();
            deltas.put(new JSONObject()
                    .put("partId", partId)
                    .put("field", "unopenedBoxes")
                    .put("delta", -1));
            deltas.put(new JSONObject()
                    .put("partId", partId)
                    .put("field", "tableQty")
                    .put("delta", boxQty));
            transaction.put("deltas", deltas);

            final JSONArray oldTransactions = state.optJSONArray("transactions");
            final JSONArray newTransactions = new JSONArray();
            newTransactions.put(transaction);
            if (oldTransactions != null) {
                final int max = Math.min(oldTransactions.length(), 999);
                for (int i = 0; i < max; i++) {
                    newTransactions.put(oldTransactions.opt(i));
                }
            }
            state.put("transactions", newTransactions);

            saveStateJson(context, state.toString());
            return new OpenBoxResult(true, "Opened 1 box of " + selected.optString("name", "part"));
        } catch (JSONException exception) {
            return new OpenBoxResult(false, "Inventory data could not be read");
        }
    }

    static void notifyWidgets(Context context) {
        final AppWidgetManager manager = AppWidgetManager.getInstance(context);
        final ComponentName componentName = new ComponentName(context, SkidCountWidget.class);
        final int[] ids = manager.getAppWidgetIds(componentName);
        if (ids.length > 0) {
            manager.notifyAppWidgetViewDataChanged(ids, R.id.widget_stack);
            SkidCountWidget.updateWidgets(context, manager, ids);
        }
    }

    private static String formatCount(double value) {
        if (Math.rint(value) == value) {
            return Long.toString((long) value);
        }
        return Double.toString(value);
    }

    record OpenBoxResult(boolean success, String message) {}
}
