package com.skidcount.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4012;

    private WebView webView;
    private NativeBridge nativeBridge;
    private ValueCallback<Uri[]> pendingFileCallback;
    private Uri pendingCameraUri;
    private File pendingCameraFile;
    private boolean cameraLaunchInProgress;
    private boolean pageLoaded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configureSystemBars();
        setContentView(R.layout.activity_main);
        applySystemBarInsets();
        configureWebView();
    }

    private void configureSystemBars() {
        final int darkBackground = Color.parseColor("#09121C");
        getWindow().setStatusBarColor(darkBackground);
        getWindow().setNavigationBarColor(darkBackground);
        getWindow().getDecorView().setBackgroundColor(darkBackground);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
            getWindow().setStatusBarContrastEnforced(false);
        }
        WindowCompat.setDecorFitsSystemWindows(getWindow(), true);
        final WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(
                getWindow(),
                getWindow().getDecorView()
        );
        controller.setAppearanceLightStatusBars(false);
        controller.setAppearanceLightNavigationBars(false);
    }

    /**
     * Android 15 enforces edge-to-edge drawing for apps targeting API 35.
     * Apply status-bar, navigation-bar, gesture-area, and display-cutout insets
     * so the app header and bottom controls remain fully visible.
     */
    private void applySystemBarInsets() {
        final View root = findViewById(R.id.root_container);
        root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
            final android.graphics.Insets safeInsets = windowInsets.getInsets(
                    WindowInsets.Type.systemBars()
                            | WindowInsets.Type.displayCutout()
            );
            view.setPadding(
                    safeInsets.left,
                    safeInsets.top,
                    safeInsets.right,
                    safeInsets.bottom
            );
            return windowInsets;
        });
        root.requestApplyInsets();
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void configureWebView() {
        webView = findViewById(R.id.web_view);
        webView.setBackgroundColor(Color.parseColor("#09121C"));
        final WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        nativeBridge = new NativeBridge(this, webView);
        webView.addJavascriptInterface(nativeBridge, "SkidCountNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                final Uri uri = request.getUrl();
                if ("file".equalsIgnoreCase(uri.getScheme())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "No app can open that link", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                reloadNativeState();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                }
                pendingFileCallback = filePathCallback;

                final String[] acceptTypes = fileChooserParams.getAcceptTypes();
                final boolean wantsImage = acceptsImages(acceptTypes);
                final boolean captureOnly = wantsImage && fileChooserParams.isCaptureEnabled();

                final Intent contentIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentIntent.setType(wantsImage ? "image/*" : firstAcceptType(acceptTypes));
                contentIntent.putExtra(
                        Intent.EXTRA_ALLOW_MULTIPLE,
                        fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE
                );

                Intent cameraIntent = null;
                if (wantsImage) {
                    cameraIntent = createPrivateCameraIntent();
                }

                try {
                    if (captureOnly && cameraIntent != null) {
                        cameraLaunchInProgress = true;
                        startActivityForResult(cameraIntent, FILE_CHOOSER_REQUEST);
                    } else {
                        cameraLaunchInProgress = false;
                        final Intent chooser = Intent.createChooser(
                                contentIntent,
                                wantsImage ? "Take or choose a work photo" : "Choose file"
                        );
                        if (cameraIntent != null) {
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
                        }
                        startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    }
                    return true;
                } catch (Exception error) {
                    clearPendingCameraFile();
                    pendingFileCallback = null;
                    Toast.makeText(
                            MainActivity.this,
                            "Could not open the camera or file picker",
                            Toast.LENGTH_LONG
                    ).show();
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/skidcount.html");
    }

    /**
     * Camera captures first land in a temporary app cache so they do not enter
     * Camera/DCIM. The web interface then saves one durable master copy into
     * Downloads/Accutek Inventory/Work Photos and removes the temporary file.
     */
    private Intent createPrivateCameraIntent() {
        try {
            final File cacheRoot = getExternalCacheDir() != null
                    ? getExternalCacheDir()
                    : getCacheDir();
            final File cameraDir = new File(cacheRoot, "accutek-camera");
            if (!cameraDir.exists() && !cameraDir.mkdirs()) {
                return null;
            }

            final String stamp = new SimpleDateFormat(
                    "yyyyMMdd-HHmmss",
                    Locale.US
            ).format(new Date());
            pendingCameraFile = File.createTempFile(
                    "accutek-" + stamp + "-",
                    ".jpg",
                    cameraDir
            );
            pendingCameraUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    pendingCameraFile
            );

            final Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            cameraIntent.setClipData(
                    ClipData.newRawUri("Accutek Inventory temporary camera photo", pendingCameraUri)
            );
            cameraIntent.addFlags(
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
            return cameraIntent;
        } catch (Exception error) {
            clearPendingCameraFile();
            return null;
        }
    }

    private static boolean acceptsImages(String[] acceptTypes) {
        if (acceptTypes == null || acceptTypes.length == 0) {
            return false;
        }
        for (String type : acceptTypes) {
            if (type != null && (type.startsWith("image/") || type.equals("*/*"))) {
                return true;
            }
        }
        return false;
    }

    private static String firstAcceptType(String[] acceptTypes) {
        if (acceptTypes == null) {
            return "*/*";
        }
        for (String type : acceptTypes) {
            if (type != null && !type.isBlank()) {
                return type;
            }
        }
        return "*/*";
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || pendingFileCallback == null) {
            return;
        }

        Uri[] result = null;
        boolean usedCameraPhoto = false;
        if (resultCode == RESULT_OK) {
            if (cameraLaunchInProgress && pendingCameraUri != null) {
                result = new Uri[]{pendingCameraUri};
                usedCameraPhoto = true;
            } else if (data != null && data.getClipData() != null) {
                final ClipData clipData = data.getClipData();
                result = new Uri[clipData.getItemCount()];
                for (int i = 0; i < clipData.getItemCount(); i++) {
                    result[i] = clipData.getItemAt(i).getUri();
                }
            } else if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            } else if (pendingCameraUri != null) {
                result = new Uri[]{pendingCameraUri};
                usedCameraPhoto = true;
            }
        }

        final File cameraFile = pendingCameraFile;
        if (!usedCameraPhoto && cameraFile != null) {
            // A gallery/file selection was used instead, or capture was cancelled.
            // Remove the unused private placeholder immediately.
            //noinspection ResultOfMethodCallIgnored
            cameraFile.delete();
        } else if (usedCameraPhoto && cameraFile != null && webView != null) {
            // Give JavaScript time to read and persist the image before cleaning
            // the temporary file. NativeBridge saves the durable master copy.
            webView.postDelayed(() -> {
                //noinspection ResultOfMethodCallIgnored
                cameraFile.delete();
            }, 10 * 60 * 1000L);
        }

        pendingFileCallback.onReceiveValue(result);
        pendingFileCallback = null;
        pendingCameraUri = null;
        pendingCameraFile = null;
        cameraLaunchInProgress = false;
    }

    private void clearPendingCameraFile() {
        if (pendingCameraFile != null) {
            //noinspection ResultOfMethodCallIgnored
            pendingCameraFile.delete();
        }
        pendingCameraFile = null;
        pendingCameraUri = null;
        cameraLaunchInProgress = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        reloadNativeState();
    }

    private void reloadNativeState() {
        if (webView != null && pageLoaded) {
            webView.evaluateJavascript(
                    "window.reloadNativeState && window.reloadNativeState();",
                    null
            );
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        clearPendingCameraFile();
        if (nativeBridge != null) {
            nativeBridge.close();
        }
        if (webView != null) {
            webView.removeJavascriptInterface("SkidCountNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
