# Accutek Inventory Android v0.14.3

Accutek Inventory is a native Android inventory and work-documentation app for skid, box, loose-part, assembly, and process-photo tracking.

## New in v0.3.0

- Added a dedicated **Photos** tab.
- Create photo sets by part and optional job/run number.
- Default workflow expects five process photos:
  1. Received
  2. Before process
  3. In process
  4. Completed
  5. Final / shipping
- Photos are grouped in collapsible folders by part and local date.
- Each photo stores its stage, note, date, and exact time.
- Camera captures are placed in app-private storage instead of the personal Camera/DCIM roll.
- Added **Email Set** with all photos attached through the user's email app.
- Added **Export Set** and **Export All** to copy images into:
  `Downloads/Accutek Inventory/Work Photos`
- Added Settings fields for the company email, expected photos per set, and email subject prefix.
- Label and skid camera captures also use a private temporary camera area, so new app captures do not clutter the personal gallery.
- Keeps the Android status-bar and bottom-navigation safe-area fix.
- Visible version: `0.3.0`
- Android `versionCode`: `5`

## Existing inventory features

- Parts with pieces per box, boxes per full skid, low-stock amount, and label photo.
- Full, partial, mixed, and custom skid receipts.
- Quick `+ 1 Skid` and `− 1 Skid` controls on each part.
- Open Box, Use, Adjust, and Edit controls.
- Organized History filters and collapsible folders by part and local date.
- Assembly recipes with hardware required per finished unit.
- Offline Google ML Kit label OCR.
- Home-screen part widget.
- CSV export and JSON backup.
- Stable application ID `com.skidcount.app`.

## Work-photo storage

Native full-size work photos are stored inside the app's private external-files area. They do not appear in the normal Camera/DCIM roll.

Important:

- Installing an update over the existing app preserves these private photos.
- Uninstalling the app removes them.
- Before uninstalling, use **Email Set**, **Export Set**, or **Export All**.
- JSON backup preserves photo records and settings, but full-size native image files should also be exported or emailed.

The browser test can preview the photo-set workflow, but it cannot attach photos to email or guarantee private Android storage.

## Update safety

1. Open the installed app.
2. Go to **Settings → Download Backup**.
3. Keep the JSON backup.
4. Upload and build v0.3.0.
5. Install v0.3.0 directly over the existing APK.
6. Do not uninstall the old app first.

The application ID and included signing key are unchanged, so this build is intended to update the existing installation without erasing inventory.

## GitHub Actions build

Upload:

`Accutek_Inventory_Android_Source_v0.3.0.zip`

Then replace:

`.github/workflows/build-apk.yml`

with the included:

`build-accutek-inventory-v0.3.0.yml`

The completed artifact is:

`Accutek-Inventory-APK-v0.3.0`

The APK inside it is:

`Accutek-Inventory-v0.3.0-release.apk`

## Android Studio build

1. Open `Accutek_Inventory_Android_Project_v0.3.0`.
2. Install Android SDK Platform 35 when prompted.
3. Sync Gradle.
4. Select the `release` build variant.
5. Choose **Build → Build APK(s)**.

Output:

`app/build/outputs/apk/release/app-release.apk`

## Keep the repository private

The project contains `skidcount-release.jks` and `keystore.properties`. Keep the repository private and back up both files. The same signing identity is required for future updates.


## v0.4.1 inventory hierarchy

- Parent folders keep the Inventory page compact.
- Open a folder and tap **+ Hardware** to add child items.
- Older ungrouped items migrate into **Unfiled Hardware** and can be moved by editing them.
- Every hardware card has separate **−/+ 1 Box** and **−/+ 1 Skid** controls.
- **Open Box** still moves one unopened box onto the assembly table; it is intentionally separate from quick box removal.
- v0.4.1 supersedes v0.3.0, so v0.3.0 does not need to be installed first.


## v0.4.1 scoped inventory summary

- Adds a **Totals shown for** selector above the Inventory summary.
- Choose All Inventory, a parent part folder, or one individual hardware item.
- Summary cards show scoped hardware count, unopened boxes, table pieces, and total estimated pieces.
- The selected summary view is saved on the device and restored when the app reopens.


## v0.4.2 build fix

- Fixes GitHub Actions failure at `:app:checkReleaseDuplicateClasses`.
- Aligns `kotlin-stdlib`, `kotlin-stdlib-jdk7`, and `kotlin-stdlib-jdk8` on version `1.8.22`.
- Prevents old Kotlin `1.6.21` classes from being packaged beside Kotlin `1.8.22`.
- No inventory workflow or stored-data format was changed.
- Android `versionCode`: `8`.


## v0.5.0

- Adds Light, Dark, and Follow phone appearance modes.
- Keeps a visible Edit Part action on every hardware card.
- Removes the per-box Open Box workflow from Inventory.
- Adds Set Counts for absolute unopened-box and open/loose-piece estimates.
- Migrates old loose-storage pieces into the open/loose estimate without losing inventory.
- Changes the home-screen widget action from Open 1 Box to − 1 Box.
- Android versionCode: 9.


## v0.6.0 gallery import

- Imports up to 20 existing gallery photos at a time.
- Copies imports into private Accutek Inventory work-photo storage.
- Assigns each photo to a parent part, photo set, process stage, and optional note.
- Supports new or existing photo sets.
- Preserves the gallery file date when available.
- Skips repeat imports using filename, size, and source timestamp.
- Leaves originals in the personal gallery until the user deletes them manually.
- Android versionCode: 10.


## v0.6.1

- Fixes broken HEIC/HEIF previews in the imported-photo review screen.
- Uses Android ImageDecoder and a JPEG thumbnail for the WebView preview.
- Converts imported HEIC/HEIF and other supported images into real JPEG files
  before saving, emailing, or exporting them.
- Renames Job / run number to Work order / batch / run and explains that it is
  only an optional company tracking reference for organizing photo sets.
- Android versionCode: 11.


## v0.6.2 micro patch

- Stores each new work photo once in the visible persistent folder:
  `Download/Accutek Inventory/Work Photos`.
- Keeps the master files separate from Camera/DCIM and lets them survive app
  uninstall.
- Adds Photos → Storage with counts, total size, missing files, duplicate
  imports, unfiled photos, preview-cache size, and last data backup.
- Adds one-tap migration of older app-private work photos. The old private file
  is deleted only after the visible master copy is written.
- Clear Preview Cache removes only small cached thumbnails, never master files.
- Reset App keeps visible master work-photo files.
- Changes the launcher icon to a shipping box.
- Android versionCode: 12.


## v0.6.3 Help organization patch

- Replaces the long flat Help Guide with page categories:
  Start Here, Inventory, Receive, Photos, History, Settings, and Phone Transfer.
- Adds a contextual `? Help` button to every main page.
- Opens Help directly to the page the user is currently working in.
- Updates photo help for visible single-master storage, HEIC conversion,
  imported originals, migration, storage checks, and phone transfers.
- Android versionCode: 13.


## v0.7.0 cleanup and weekly-photo workflow

- Restores an obvious camera workflow with `Start Weekly Set` and `Next Photo`.
- Uses one dated five-photo set per product and week.
- Removes the long process-stage list. Photos use only Skid proof,
  Label proof, or Final proof, and can be categorized after capture.
- Automatically assigns five client-proof slots:
  Skid overview, Skid detail, two label close-ups, and final proof.
- Emails the set to the saved shop email address.
- Adds photo relinking by filename after restoring a backup or moving phones.
- Recycles OCR and photo bitmaps more reliably.
- Removes an unused duplicate-export path and outdated private-storage wording.
- Fixes the old widget OPEN_BOX action/resource names.
- Fixes an undefined CSS color variable and improves small-screen photo layouts.
- Android versionCode: 14.


## v0.7.1 quick-camera patch

- Makes Open Camera the most prominent action on the Work Photos page.
- Makes the weekly workflow explanation dismissible with an × button.
- Remembers the dismissal while retaining the instructions under Photos Help.
- Adds a small camera shortcut to every Inventory parent-folder card.
- A folder shortcut continues that product's unfinished current-week set,
  automatically creates a dated set when none exists, or opens a completed set
  rather than creating an accidental duplicate.
- Confirms Galaxy Watch 6 is suitable for a later Wear OS companion app; this
  patch is the phone-side quick-camera workflow.
- Android versionCode: 15.


## v0.7.2 photo editor patch

- Opens a crop-and-adjust review editor after every camera capture.
- Supports touch crop-box movement and four draggable corner handles.
- Adds free crop, square, and 4:3 crop presets.
- Adds rotate left/right, brightness, contrast, center crop, and reset.
- Adds Crop actions to existing saved photos and the full-photo viewer.
- Replaces the same master JPEG when editing an existing photo, preserving its
  MediaStore URI and avoiding full-size duplicate files.
- Email Set automatically uses the adjusted master files.
- Android versionCode: 16.


## v0.8.0 inventory-focused release

- Retires the weekly Work Photos tab, camera shortcuts, photo email workflow,
  and active photo rendering.
- Preserves any existing photo files and provides a Settings link so the user
  can remove the old folder manually.
- Changes inventory display to total pieces, calculated full boxes, and one
  partial-box remainder.
- Adds typed Add Pieces entry on every inventory item.
- Adds a dedicated Scrap workflow with reason, note, History record, and Undo.
- Changes normal Use to subtract from total pieces rather than only the loose
  count.
- Rebuilds custom receipts around exact total pieces and automatic box/remainder
  calculations.
- Example: 7,000 pieces at 600 per box = 11 full boxes + 400 partial pieces.
- Keeps label-camera OCR; only the retired client-proof photo workflow is hidden.
- Android versionCode: 17.


## v0.9.0 parent production workflow

- Adds a finished-skid recipe directly to every parent Inventory tile.
- Uses child hardware as the parent's bill of materials.
- Stores finished units per box, finished boxes per skid, and each child part's
  quantity required per finished parent unit.
- Shows projected full skids, extra finished boxes, extra units, total finished
  units possible, and the limiting child hardware.
- Adds a prominent Skid Finished action on the parent tile.
- Recording finished skids previews every hardware deduction, prevents negative
  inventory, writes a History entry, and supports Undo.
- Example MID recipe: 1 T-nut, 1 bolt, and 2 pins per MID; 100 MIDs per box;
  90 boxes per skid; therefore one skid requires 9,000 T-nuts, 9,000 bolts,
  and 18,000 pins.
- Replaces the older Settings-first assembly workflow with the cleaner
  parent-tile setup.
- Android versionCode: 18.


## v0.9.1 universal hardware patch

- Adds a Universal Hardware Folder checkbox to parent-folder creation/editing.
- Universal folders are visually labeled and do not require their own finished
  skid recipe.
- Finished-skid setup now includes an Add Hardware selector.
- The selector prioritizes parts from Universal Hardware folders but can also
  add a part from any other parent folder.
- Outside hardware remains in its original folder and is referenced directly;
  inventory is never copied or duplicated.
- Existing child hardware is still included automatically.
- Outside hardware can be removed from a recipe without deleting the part.
- Production forecasts and Finished Skid deductions use the shared part's one
  live inventory total.
- Android versionCode: 19.


## v0.10.0 monthly Friday schedule

- Adds a dedicated Schedule tab and parent-tile Monthly Schedule action.
- Creates one shipment row for every Friday in the chosen month.
- Stores both the total monthly skid request and the per-Friday distribution.
- Supports months with four or five Friday shipments automatically.
- Allocates shared hardware once across every scheduled parent product.
- Processes weeks chronologically and rotates one skid at a time between products
  sharing the same Friday, preventing one product from claiming the full shared
  Pins balance before the other is considered.
- Shows required, completed, forecast-covered, and short skid counts.
- Shows projected hardware remaining after the selected month.
- Finished Skid automatically credits the earliest incomplete scheduled Friday.
- Planning never subtracts inventory; only recording finished skids does.
- Android versionCode: 20.


## v0.10.1 schedule UI cleanup

- Replaces the visually inconsistent Finished Skid controls with the app's
  standard primary-button style.
- Rebuilds product selection as a clean multi-select list for adding or editing
  several parent products in one month.
- Adds a clickable month calendar with scheduled, partly completed, completed,
  and shortage markers.
- Replaces the large always-open weekly cards with compact collapsible shipment
  cards showing date and parent product in the header.
- Keeps zero-skid dates valid so products may ship only on selected or irregular
  weeks.
- Fixes manually entered completed skid totals so they appear on the Schedule
  page and hide the Finished Skid action once that shipment is complete.
- Adds a per-month shipping-day chooser, defaulting to Friday, and carries
  amounts by week order when the day changes.
- Preserves manual and app-recorded completion separately when shipping dates
  are remapped, preventing double-counted completed skids.
- Android versionCode: 21.


## v0.10.2 schedule hierarchy and hardware organization

- Condenses Schedule into Month -> Product -> Hardware.
- The month card contains the interactive calendar and collapsible products.
- Each product contains compact shipment-date rows plus a nested hardware
  forecast showing pieces per skid, that product's remaining scheduled need,
  and the balance after all products share the same hardware pool.
- Zero-skid weeks remain stored in the monthly editor but are not shown as
  active shipment rows.
- Calendar markers open the matching product and shipping-date row.
- Adds Move Parent to every hardware tile.
- Moving hardware preserves its inventory count, History, and all finished-skid
  recipe references because the same part ID is retained.
- Shared hardware can be moved into a Universal Hardware folder and referenced
  by XR MIDS C3, AIRE MIDS, and future products without duplicate counts.
- Android versionCode: 22.


## v0.10.3 History cleanup

- Reorganizes History as Parent Part -> Hardware -> Date -> Record.
- Adds text search across parent names, hardware names, action titles, details,
  notes, categories, and formatted dates.
- Adds a Parent Part filter, including Universal Hardware and General Activity.
- Retains All, Added, Removed, and Changes quick filters with counts.
- Shows shared/universal hardware source folders under product History.
- Shows per-hardware net piece movement and parent-level record summaries.
- Keeps exact timestamps, notes, Undo, and CSV export.
- Android versionCode: 23.


## v0.11.0 Products and Hardware redesign

- Inventory now has two top-level sections: Products and Hardware.
- Products contain finished-skid recipes, schedules, and production actions.
- Hardware is one global physical inventory; each item exists once and can be
  referenced by any number of product recipes.
- Existing part IDs, counts, History, recipes, schedules, and Undo data are
  preserved. Old folder ownership remains only as migration metadata and is no
  longer used to duplicate or organize hardware in the main Inventory UI.
- New hardware is saved into an invisible global catalog. Duplicate names are
  blocked for new entries and existing duplicate names are flagged for review;
  records are never merged automatically.
- Hardware tiles show which products use them. Product tiles show their recipe
  hardware and quantities per finished unit.
- Schedule now shows Monthly Hardware Totals: current pieces, full-month demand,
  open need, and projected balance after unfinished shipments.
- Replaces awkward user-facing "covered" wording with accurate phrases such as
  "open skids supported", "hardware needed", and "current hardware can supply".
- Android versionCode: 24.


## v0.12.0 production history and forecast overhaul

- Adds Historical Production entries for previous months. Historical skids train
  future projections but never subtract from the current Hardware inventory.
- Existing schedules migrate as Current / Future Plans.
- Completed skids are assumed to already be reflected in the live inventory;
  only unfinished plan rows create Need.
- Builds estimates from up to the three most recent available months, weighted
  toward the newest month, and projects future shipping dates and product skid
  capacity.
- Allocates shared Hardware once across all Products in chronological date order.
- Shows every hardware shortage, not only the first limiter.
- Monthly Hardware Totals use Current, Full Month, Need, and Projected Balance.
  Negative projected balances remain visible in red; positive balances are green;
  zero is neutral. Stress-test values are preserved exactly.
- Replaces unsupported/covered wording with direct unfinished, can-complete,
  Need, and short wording.
- Condenses Hardware cards and removes duplicate box displays.
- Replaces the native white totals selector with an in-app dark picker.
- Removes the redundant Settings recipe card and old Universal-folder language.
- Adds a safer in-app reset path and native state-clear bridge.
- Android versionCode: 25.


## v0.12.1 direct hardware controls and schedule split
- Partial pieces are editable directly on each Hardware card.
- Add Pieces was removed from Hardware cards; Receive remains the delivery workflow.
- Box and skid adjustments now use a center quantity multiplier.
- Schedule has Current Hardware Usage and Projected Usage tabs.
- Current Usage restores the exact shipment calendar and exact month-end hardware balances.
- Projected Usage shows calendars, product capacity, shortages, and hardware balances across upcoming months.
- Positive balances remain green, zero neutral, and every negative balance red.
- versionCode 26.


## v0.12.2 exact production accounting and dated receipts

- Converts manually entered current-month completed skids into real hardware-use ledger transactions.
- Existing v0.12.1 `startingCompleted` values are reconciled once during migration, then cleared to prevent double deductions.
- Skid Finished transactions remain the minimum completion count and are never deducted twice.
- Exact Hardware Totals now show Received This Month, Used So Far, Current Remaining, Need, Full Month, and Projected Balance.
- Current Usage and Projected Usage both show full month calendars with numbered days.
- Projected Usage begins after the selected exact month and shows future estimated month calendars.
- Completed Products show Complete instead of `0 can be completed`; open Products show unfinished counts.
- Receive Full Skid and Receive Pieces now include a received date and store dated receipt lines.
- Hardware cards contain collapsible Received Orders; live leftovers automatically carry into later months.
- Startup repairs orphaned Product schedules and broken recipe references instead of crashing.
- Android versionCode: 27.


## v0.13.0 Physical Inventory Check

- Replaces the bottom Settings tab with a dedicated Check page.
- Moves Settings to a gear button in the global top bar.
- Removes the duplicate global Help button; each page Help button opens that page's guide.
- Adds dated physical inventory checks using unopened skids, extra boxes, and partial/loose pieces.
- Compares each physical count with the live expected inventory and shows Short, Over, or Exact.
- Supports Save Check Only or Save & Reconcile with History and Undo.
- Stores checks by date and provides Copy Report and CSV export.
- Includes inventory checks in normal JSON backups.
- Forces dark Android status/navigation surfaces and dark WebView/root backgrounds to eliminate white system-bar bands.
- Android versionCode: 28.


## v0.13.1 Android build fix

- Removes the invalid `android:windowNavigationBarContrastEnforced` theme attribute that caused `processReleaseResources` to fail.
- Keeps dark status/navigation bars through compatible theme colors and the existing Android runtime calls in `MainActivity`.
- Android versionCode: 29.


## v0.13.2 inventory-check checklist cleanup

- Starts each Inventory Check with an Add Hardware picker.
- Shows every hardware item with a checkbox, expected quantity, box size, and skid size.
- Supports Select All, Clear, and adding many selected hardware items at once.
- Added hardware count entries are collapsible to save vertical space.
- Each collapsed row shows Not Counted or the live variance after entry.
- Hardware can be removed from the active check without affecting Inventory.
- Saved check records now collapse each hardware result as well.
- Existing Save Check Only, Save & Reconcile, History, Undo, Copy Report, and CSV export behavior remains.
- Android versionCode: 30.


## v0.13.3 Inventory Master

- Makes each Hardware record the authoritative source of truth.
- Adds masterCurrentPieces so forecast rendering cannot silently alter live counts.
- Schedule and Projected Usage read from Master Inventory only.
- Only receipts, completed production, Use, Scrap, Set Counts, and confirmed
  Inventory Check reconciliation can change live Hardware.
- Adds a collapsible Master Inventory ledger to each Hardware card showing the
  entered total, actual removals, later additions, and current available amount.
- Preserves exact piece deltas so later pieces-per-box edits do not rewrite
  current inventory.
- Repairs any silent mismatch between cached box fields and the master piece
  total during load/save/render.
- Android versionCode: 31.


## v0.13.4 Master totals correction

- Keeps the main Hardware card's saved live total authoritative on startup.
- Prevents the audit ledger from overwriting live inventory.
- Corrects the Master Inventory equation so the opening receipt is not shown a second time under Added After Start.
- Master summary now follows: Starting Total + Added After Start - Removed / Used = Current Available.
- Partial Pieces defaults to 0 when blank; saved nonzero partials remain until changed.
- Box and skid quantity multipliers continue to default back to 1 after each adjustment.
- Android versionCode: 32.


## v0.13.5 fixed reference and live Master Inventory

- Freezes the large Hardware-tile number as a fixed starting reference.
- Master Inventory now shows Inventory Now, which is the live balance used by all other pages.
- Adds a red/green running history with each action, piece change, prior total, new total, date, and time.
- Adds Correct Inventory Now, Clear Inventory Now, and Replace Starting Baseline.
- Corrections preserve the audit trail and support History Undo.
- Clearing Inventory Now sets only the live balance to zero; it does not delete receipts, production, or History.
- Replacing the baseline starts a new dated reference while retaining the older audit trail.
- Partial Pieces defaults to 0 until saved; box and skid multipliers default to 1.
- Android versionCode: 33.


## v0.13.6 protected master setup lock

- Moves the former Set behavior into a centered sliding Lock/Unlock control.
- Locked is red-left with the lock knob on the right; Unlocked is green-right
  with the knob on the left.
- Box, skid, and partial controls edit only the fixed starting reference while
  unlocked. Inventory Now remains the live operational balance.
- Partial Pieces sits below both box and skid adjustment rows and defaults to
  zero unless a nonzero fixed partial is saved.
- Sliding back to Locked confirms and saves the fixed reference correction.
- Uncommitted edits auto-lock and discard after 30 seconds, when leaving the
  Inventory page, when the app backgrounds, or when it closes.
- The unlocked state is never persisted, so every app start is safely locked.
- Fixed reference corrections are recorded in History and support Undo.
- Android versionCode: 34.


## v0.13.7 stability and flow cleanup

- Adds explicit Save & Lock and Discard controls to protected Hardware references.
- Saves zero boxes, zero skids, and zero partial pieces as a true zero reference.
- Reconciles older completed-skid records with Inventory Now once, with an Undo-capable audit transaction.
- Allows a previously finished skid to be reopened from the monthly schedule.
- Reopening restores the exact recipe hardware once and records the correction in History.
- Removes the old completed-skid minimum validation that blocked legitimate corrections.
- Makes partial-piece changes update the pending reference immediately.
- Audits navigation targets and refreshes Schedule, History, and Check pages when opened.
- Adds safer focus states and clearer confirmation copy.
- Android versionCode: 35.


## v0.13.8 inventory periods and app dialogs

- Hardware tiles are collapsible and show `Inventory Now of Period Start` at a glance.
- A hardware item entered for the first time automatically initializes both the starting supply and live Inventory Now amount.
- Existing records with a valid starting amount but a blank live balance are repaired only when no quantity activity exists.
- Closing one period or all hardware periods archives the ending balance and rolls remaining pieces into a new dated period.
- Dated receipts expand the active period supply total while Inventory Now remains the master live quantity.
- Schedule, projections, checks, production, receipts, use, scrap, corrections, and Undo continue to read or update Inventory Now.
- Replaces browser-native alert/confirm popups with dark app-styled dialogs throughout the app.
- Android versionCode 36.


## v0.13.9 recipe safety and live recalculation

- New Product skid setup numeric values begin at 0 instead of silently assuming
  100 units per box and 90 boxes per skid.
- Zero or missing recipe values are highlighted in red and cannot be saved.
- Every selected Hardware quantity must be above 0.
- The live formula preview shows units per skid and Hardware per box/skid.
- Editing units per box, boxes per skid, or recipe quantities immediately
  recalculates Product capacity, exact schedules, Hardware Totals, and future
  projections.
- When completed skids already exist, saving a changed recipe reconciles the
  difference into Inventory Now exactly once and records the adjustment in
  History.
- Replaced remaining native duplicate/save warnings in Product and Hardware
  setup with Accutek-styled messages.
- Android versionCode: 37.


## v0.14.0 guided setup and workflow cleanup

- Product creation now continues directly from Product details to Assembly Setup.
- After saving, Add Another Product loops immediately or Done returns to the new card.
- Hardware creation has the same Add Another Hardware / Done loop.
- Replaces user-facing Recipe wording with Assembly Setup and Assembly Hardware.
- Removes the redundant Product/Schedule Finished Skid buttons; completed quantities are edited only in Monthly Schedule.
- Removes active Product/Hardware label photo and OCR setup controls.
- Positions + Hardware as a full right-hand catalog action beside Close Periods.
- Keeps old photo fields and transaction types readable for backup compatibility.
- Android versionCode: 38.


## v0.14.1 Android build fix

- Removes the stale `recognizer.close()` call left behind after OCR was retired.
- Keeps the ML Kit OCR dependency removed.
- No inventory data model or workflow behavior changed.
- Android versionCode: 39.


## v0.14.2 Hardware setup flow

- Shows Close Periods on both Products and Hardware catalog tabs.
- Splits new Hardware creation into Details and Opening Inventory steps.
- Step 1 stores the name, pieces per box, boxes per received skid, and warning level only in a temporary draft.
- Step 2 requires opening skids, extra boxes, partial pieces, and a starting date before the Hardware tile is created.
- Starting at zero requires an explicit confirmation checkbox to prevent accidental 0 of 0 inventory records.
- Saving creates the Hardware database record, first dated inventory period, and Inventory Now together.
- The existing Add Another Hardware / Done completion loop remains.
- Android versionCode: 40.


## v0.14.3 Hardware folders and quick completion

- Adds user-created collapsible Hardware folders.
- Hardware can be moved between folders without changing Inventory Now, Assembly links, schedules, or History.
- Schedule Hardware Totals reuse the same folder organization.
- Adds Complete 1 to each active Product schedule card; it completes the earliest unfinished shipment and deducts Assembly Hardware exactly once.
- Completed Product cards show a disabled Complete button.
- Keeps Close Periods beside the create button on both Products and Hardware.
- Android versionCode: 41.
