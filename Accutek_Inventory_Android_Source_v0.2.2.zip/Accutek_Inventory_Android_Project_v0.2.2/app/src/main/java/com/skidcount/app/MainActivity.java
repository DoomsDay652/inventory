package com.skidcount.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.WindowInsets;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4012;

    private WebView webView;
    private NativeBridge nativeBridge;
    private ValueCallback<Uri[]> pendingFileCallback;
    private Uri pendingCameraUri;
    private boolean cameraLaunchInProgress;
    private boolean pageLoaded;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        applySystemBarInsets();
        configureWebView();
    }


    /**
     * Android 15 enforces edge-to-edge drawing for apps targeting API 35.
     * Apply status-bar, navigation-bar, gesture-area, and display-cutout insets
     * to the WebView so the app header and bottom controls remain fully visible.
     */
    private void applySystemBarInsets() {
        final View root = findViewById(R.id.root_container);
        root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
            final android.graphics.Insets safeInsets = windowInsets.getInsets(
                    WindowInsets.Type.systemBars()
                            | WindowInsets.Type.displayCutout()
            );
            view.setPadding(
                    safeInsets.left,
                    safeInsets.top,
                    safeInsets.right,
                    safeInsets.bottom
            );
            return windowInsets;
        });
        root.requestApplyInsets();
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void configureWebView() {
        webView = findViewById(R.id.web_view);
        final WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        nativeBridge = new NativeBridge(this, webView);
        webView.addJavascriptInterface(nativeBridge, "SkidCountNative");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                final Uri uri = request.getUrl();
                if ("file".equalsIgnoreCase(uri.getScheme())) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                    Toast.makeText(MainActivity.this, "No app can open that link", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                reloadNativeState();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (pendingFileCallback != null) {
                    pendingFileCallback.onReceiveValue(null);
                }
                pendingFileCallback = filePathCallback;

                final String[] acceptTypes = fileChooserParams.getAcceptTypes();
                final boolean wantsImage = acceptsImages(acceptTypes);
                final boolean captureOnly = wantsImage && fileChooserParams.isCaptureEnabled();

                final Intent contentIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                contentIntent.addCategory(Intent.CATEGORY_OPENABLE);
                contentIntent.setType(wantsImage ? "image/*" : firstAcceptType(acceptTypes));
                contentIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, fileChooserParams.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);

                Intent cameraIntent = null;
                if (wantsImage) {
                    cameraIntent = createCameraIntent();
                }

                try {
                    if (captureOnly && cameraIntent != null) {
                        cameraLaunchInProgress = true;
                        startActivityForResult(cameraIntent, FILE_CHOOSER_REQUEST);
                    } else {
                        cameraLaunchInProgress = false;
                        final Intent chooser = Intent.createChooser(contentIntent, wantsImage ? "Take or choose a label photo" : "Choose file");
                        if (cameraIntent != null) {
                            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
                        }
                        startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    }
                    return true;
                } catch (Exception error) {
                    pendingFileCallback = null;
                    Toast.makeText(MainActivity.this, "Could not open the camera or file picker", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });

        webView.loadUrl("file:///android_asset/skidcount.html");
    }

    private Intent createCameraIntent() {
        try {
            final ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "skidcount-label-" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Accutek Inventory");
            pendingCameraUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (pendingCameraUri == null) {
                return null;
            }

            final Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
            cameraIntent.setClipData(ClipData.newRawUri("Accutek Inventory label photo", pendingCameraUri));
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            return cameraIntent;
        } catch (Exception error) {
            pendingCameraUri = null;
            return null;
        }
    }

    private static boolean acceptsImages(String[] acceptTypes) {
        if (acceptTypes == null || acceptTypes.length == 0) {
            return false;
        }
        for (String type : acceptTypes) {
            if (type != null && (type.startsWith("image/") || type.equals("*/*"))) {
                return true;
            }
        }
        return false;
    }

    private static String firstAcceptType(String[] acceptTypes) {
        if (acceptTypes == null) {
            return "*/*";
        }
        for (String type : acceptTypes) {
            if (type != null && !type.isBlank()) {
                return type;
            }
        }
        return "*/*";
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || pendingFileCallback == null) {
            return;
        }

        Uri[] result = null;
        boolean usedCameraPhoto = false;
        if (resultCode == RESULT_OK) {
            // When capture=environment launched the camera directly, always prefer the
            // full-resolution MediaStore image. Some camera apps also return a tiny
            // thumbnail URI in data, which is too small for dependable label OCR.
            if (cameraLaunchInProgress && pendingCameraUri != null) {
                result = new Uri[]{pendingCameraUri};
                usedCameraPhoto = true;
            } else if (data != null && data.getClipData() != null) {
                final ClipData clipData = data.getClipData();
                result = new Uri[clipData.getItemCount()];
                for (int i = 0; i < clipData.getItemCount(); i++) {
                    result[i] = clipData.getItemAt(i).getUri();
                }
            } else if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            } else if (pendingCameraUri != null) {
                result = new Uri[]{pendingCameraUri};
                usedCameraPhoto = true;
            }
        }
        if (pendingCameraUri != null && !usedCameraPhoto) {
            try {
                getContentResolver().delete(pendingCameraUri, null, null);
            } catch (Exception ignored) {
            }
        }

        pendingFileCallback.onReceiveValue(result);
        pendingFileCallback = null;
        pendingCameraUri = null;
        cameraLaunchInProgress = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        reloadNativeState();
    }

    private void reloadNativeState() {
        if (webView != null && pageLoaded) {
            webView.evaluateJavascript("window.reloadNativeState && window.reloadNativeState();", null);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) {
            pendingFileCallback.onReceiveValue(null);
            pendingFileCallback = null;
        }
        if (nativeBridge != null) {
            nativeBridge.close();
        }
        if (webView != null) {
            webView.removeJavascriptInterface("SkidCountNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
