# Accutek Inventory Android v0.2.2

This project wraps the tested Accutek Inventory browser interface in a native Android app and adds Android-only OCR, storage, and widget support.

## Revision 4 workflow fixes

- Fixed Inventory card actions that could stop working after startup.
- Added **+ 1 Skid** and **− 1 Skid** directly to every part card.
- Quick skid changes immediately update unopened boxes, record local date/time, and can be undone from History.
- Rebuilt History with:
  - All, Added, Removed, and Changes filters,
  - collapsible folders by part,
  - nested collapsible folders by local calendar date,
  - exact local times, notes, and Undo controls.
- Added missing **Manage Recipes**, **Help**, and **Settings Help Guide** controls.
- Improved label parsing for short alphanumeric part names such as `C3S`.
- Native OCR now reads both a normal image and a high-contrast image and chooses/combines the stronger result.
- Native camera capture now prefers the full-resolution photo instead of a small returned thumbnail.
- App version: `0.2.0` (`versionCode 2`).

## Included features

- Parts with pieces per box, boxes per full skid, low-stock amount, and saved label photo.
- Full, partial, mixed, and custom skid receipts.
- Table counts, opened boxes, parts used, corrections, scrap, and damage.
- Multiple assembly recipes with hardware required per finished unit.
- Offline Google ML Kit Latin label OCR in the APK.
- Local Android storage shared with the home-screen widget.
- Widget with vertical part swiping, Previous/Next, Open 1 Box, and Open App.
- CSV exports and JSON backups saved to `Downloads/Accutek Inventory`.
- Stable application ID `com.skidcount.app`.
- Included signing key so v0.2 can update v0.1 without deleting inventory.

## Data safety

Before changing versions:

1. Open the current app or browser test.
2. Go to **Settings → Download Backup**.
3. Keep the JSON backup in Downloads.
4. Install the newer APK over the existing APK. Do **not** uninstall the old APK.
5. Restore the backup only if the existing data does not appear.

The browser HTML and APK use separate storage. Move browser test data into the APK through backup and restore.

## Build with GitHub Actions

Upload `Accutek_Inventory_Android_Source_v0.2.2.zip` to the private repository and update `.github/workflows/build-apk.yml` with the included `build-accutek-inventory-v0.2.2.yml`. The revised workflow selects the highest versioned SkidCount source ZIP, builds the signed release APK, and uploads it as an artifact.

## Build with Android Studio

1. Open the `Accutek_Inventory_Android_Project_v0.2.1` folder.
2. Install Android SDK Platform 35 when prompted.
3. Sync Gradle.
4. Select the `release` build variant.
5. Choose **Build → Build APK(s)**.

Output:

`app/build/outputs/apk/release/app-release.apk`

## Keep the repository private

`skidcount-release.jks` and `keystore.properties` are included so later APKs can use the same signing identity. Keep them private and backed up.


## Branding and update identity

- Visible app name: **Accutek Inventory**
- Visible/build version: **0.2.2** (`versionCode 4`)
- Application ID remains `com.skidcount.app` so this build can update the existing installation.
- Keep using the same included signing key for every future APK update.


## v0.2.2 system-bar fix

- Applies Android status-bar, navigation-bar, gesture-area, and display-cutout insets.
- Prevents the app header from appearing underneath the phone's top status bar.
- Prevents lower controls from sitting behind gesture navigation or the bottom navigation bar.
