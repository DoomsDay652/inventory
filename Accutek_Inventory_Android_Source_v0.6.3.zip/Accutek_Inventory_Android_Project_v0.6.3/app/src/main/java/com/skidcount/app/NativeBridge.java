package com.skidcount.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class NativeBridge {
    private static final String LEGACY_WORK_ROOT = "Accutek Inventory Work Photos";
    private static final String PERSISTENT_RELATIVE_ROOT = Environment.DIRECTORY_DOWNLOADS
            + "/Accutek Inventory/Work Photos/";

    private final Activity activity;
    private final Context context;
    private final WebView webView;
    private final TextRecognizer recognizer;
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor();

    NativeBridge(Activity activity, WebView webView) {
        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.webView = webView;
        this.recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
    }

    @JavascriptInterface
    public String getState() {
        return StateStore.getStateJson(context);
    }

    @JavascriptInterface
    public void syncState(String json) {
        if (json == null || json.isBlank()) {
            return;
        }
        try {
            new JSONObject(json);
            StateStore.saveStateJson(context, json);
        } catch (Exception ignored) {
            showToast("Accutek Inventory could not save invalid inventory data");
        }
    }

    @JavascriptInterface
    public void recognizeText(String requestId, String dataUrl) {
        ioExecutor.execute(() -> {
            try {
                final byte[] bytes = decodeDataUrl(dataUrl);
                final Bitmap bitmap = decodeBitmap(bytes, 2600);
                if (bitmap == null) {
                    sendOcrResult(requestId, "", "The image could not be decoded");
                    return;
                }

                final InputImage image = InputImage.fromBitmap(bitmap, 0);
                recognizer.process(image)
                        .addOnSuccessListener(result ->
                                sendOcrResult(requestId, result.getText(), "")
                        )
                        .addOnFailureListener(error ->
                                sendOcrResult(
                                        requestId,
                                        "",
                                        error.getMessage() == null
                                                ? "OCR failed"
                                                : error.getMessage()
                                )
                        );
            } catch (Exception error) {
                sendOcrResult(
                        requestId,
                        "",
                        error.getMessage() == null ? "OCR failed" : error.getMessage()
                );
            }
        });
    }

    /**
     * Saves a durable camera capture into app-private external storage.
     */
    @JavascriptInterface
    public void saveWorkPhoto(
            String requestId,
            String dataUrl,
            String partId,
            String partName,
            String stage,
            String notes,
            String setId,
            String setName
    ) {
        saveWorkPhotoInternal(
                requestId, dataUrl, partId, partName, stage, notes,
                setId, setName, "", "", "", false
        );
    }

    /**
     * Copies an existing gallery photo into app-private work storage while
     * preserving its supplied source date and categorization metadata.
     */
    @JavascriptInterface
    public void importWorkPhoto(
            String requestId,
            String dataUrl,
            String partId,
            String partName,
            String stage,
            String notes,
            String setId,
            String setName,
            String sourceCreatedAt,
            String sourceName,
            String importKey
    ) {
        saveWorkPhotoInternal(
                requestId, dataUrl, partId, partName, stage, notes,
                setId, setName, sourceCreatedAt, sourceName, importKey, true
        );
    }

    /**
     * Converts a selected image, including HEIC/HEIF when Android can decode it,
     * into a small JPEG data URL for the WebView review screen.
     */
    @JavascriptInterface
    public void prepareImportPreview(String requestId, String dataUrl) {
        ioExecutor.execute(() -> {
            Bitmap bitmap = null;
            try {
                final byte[] bytes = decodeDataUrl(dataUrl);
                bitmap = decodeBitmap(bytes, 1200);
                if (bitmap == null) {
                    sendWorkPhotoResult(requestId, null, "The selected photo could not be decoded");
                    return;
                }
                final JSONObject result = new JSONObject();
                result.put("thumbnail", createThumbnailDataUrl(bitmap));
                sendWorkPhotoResult(requestId, result, "");
            } catch (Exception error) {
                sendWorkPhotoResult(
                        requestId,
                        null,
                        error.getMessage() == null
                                ? "The selected photo could not be previewed"
                                : error.getMessage()
                );
            } finally {
                if (bitmap != null && !bitmap.isRecycled()) {
                    bitmap.recycle();
                }
            }
        });
    }

    private void saveWorkPhotoInternal(
            String requestId,
            String dataUrl,
            String partId,
            String partName,
            String stage,
            String notes,
            String setId,
            String setName,
            String sourceCreatedAt,
            String sourceName,
            String importKey,
            boolean imported
    ) {
        ioExecutor.execute(() -> {
            try {
                final byte[] bytes = decodeDataUrl(dataUrl);
                final Bitmap bitmap = decodeBitmap(bytes, 3600);
                if (bitmap == null) {
                    sendWorkPhotoResult(requestId, null, "The work photo could not be decoded");
                    return;
                }

                Date photoDate = new Date();
                if (sourceCreatedAt != null && !sourceCreatedAt.isBlank()) {
                    try {
                        photoDate = Date.from(java.time.Instant.parse(sourceCreatedAt));
                    } catch (Exception ignored) {
                        // Keep the current date when the source timestamp is invalid.
                    }
                }

                final JSONObject stored = writePersistentPhoto(
                        bitmap,
                        partName,
                        stage,
                        setName == null || setName.isBlank() ? setId : setName,
                        photoDate
                );

                final JSONObject result = new JSONObject();
                result.put("id", UUID.randomUUID().toString());
                result.put("path", stored.getString("path"));
                result.put("filename", stored.getString("filename"));
                result.put("fileSizeBytes", stored.optLong("fileSizeBytes", 0));
                result.put("partId", partId == null ? "" : partId);
                result.put("partName", partName == null ? "" : partName);
                result.put("stage", stage == null ? "" : stage);
                result.put("notes", notes == null ? "" : notes);
                result.put("setId", setId == null ? "" : setId);
                result.put("setName", setName == null ? "" : setName);
                result.put("createdAt", photoDate.toInstant().toString());
                result.put("thumbnail", createThumbnailDataUrl(bitmap));
                result.put("privateStorage", false);
                result.put("persistentStorage", true);
                result.put("imported", imported);
                result.put("sourceName", sourceName == null ? "" : sourceName);
                result.put("importKey", importKey == null ? "" : importKey);
                bitmap.recycle();
                sendWorkPhotoResult(requestId, result, "");
            } catch (Exception error) {
                sendWorkPhotoResult(
                        requestId,
                        null,
                        error.getMessage() == null ? "The work photo could not be saved" : error.getMessage()
                );
            }
        });
    }

    @JavascriptInterface
    public void deleteWorkPhoto(String storedPath) {
        ioExecutor.execute(() -> {
            try {
                if (isPersistentWorkPhoto(storedPath)) {
                    context.getContentResolver().delete(Uri.parse(storedPath), null, null);
                    return;
                }
                if (!isLegacyWorkPhoto(storedPath)) {
                    return;
                }
                final File file = new File(storedPath);
                if (file.exists() && !file.delete()) {
                    showToast("The photo record was removed, but the image file could not be deleted");
                }
                removeEmptyParents(file.getParentFile());
            } catch (Exception ignored) {
            }
        });
    }

    @JavascriptInterface
    public void openWorkPhoto(String storedPath) {
        activity.runOnUiThread(() -> {
            try {
                final Uri uri;
                if (isPersistentWorkPhoto(storedPath)) {
                    uri = Uri.parse(storedPath);
                } else {
                    final File file = requireLegacyWorkPhoto(storedPath);
                    uri = FileProvider.getUriForFile(
                            activity,
                            activity.getPackageName() + ".fileprovider",
                            file
                    );
                }
                final Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(uri, "image/jpeg");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(intent);
            } catch (Exception error) {
                showToast("Could not open that work photo");
            }
        });
    }

    /**
     * Opens the user's email/share app with the selected work photos attached.
     * The user still reviews and sends the message themselves.
     */
    @JavascriptInterface
    public void shareWorkPhotos(
            String absolutePathsJson,
            String recipient,
            String subject,
            String body
    ) {
        ioExecutor.execute(() -> {
            try {
                final ArrayList<Uri> uris = parseManagedPhotoUris(absolutePathsJson);
                if (uris.isEmpty()) {
                    showToast("There are no saved work photos to attach");
                    return;
                }

                final Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                intent.setType("image/jpeg");
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                if (recipient != null && !recipient.isBlank()) {
                    intent.putExtra(
                            Intent.EXTRA_EMAIL,
                            new String[]{recipient.trim()}
                    );
                }
                intent.putExtra(
                        Intent.EXTRA_SUBJECT,
                        subject == null ? "" : subject
                );
                intent.putExtra(
                        Intent.EXTRA_TEXT,
                        body == null ? "" : body
                );
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                final ClipData clipData = ClipData.newRawUri(
                        "Accutek Inventory work photos",
                        uris.get(0)
                );
                for (int i = 1; i < uris.size(); i++) {
                    clipData.addItem(new ClipData.Item(uris.get(i)));
                }
                intent.setClipData(clipData);

                activity.runOnUiThread(() -> {
                    try {
                        activity.startActivity(
                                Intent.createChooser(
                                        intent,
                                        "Email or share work photos"
                                )
                        );
                    } catch (Exception error) {
                        showToast("No email or sharing app is available");
                    }
                });
            } catch (Exception error) {
                showToast(
                        "Could not prepare the work photos: "
                                + safeMessage(error)
                );
            }
        });
    }

    /**
     * Copies selected private work photos into a visible Downloads folder.
     * This is useful for manual upload, backup, or transferring them elsewhere.
     */
    @JavascriptInterface
    public void exportWorkPhotos(
            String absolutePathsJson,
            String folderName
    ) {
        ioExecutor.execute(() -> {
            try {
                final JSONArray paths = new JSONArray(
                        absolutePathsJson == null ? "[]" : absolutePathsJson
                );
                int copied = 0;
                final String relativeFolder = Environment.DIRECTORY_DOWNLOADS
                        + "/Accutek Inventory/Work Photos/"
                        + safeFolder(folderName, "Export");

                for (int i = 0; i < paths.length(); i++) {
                    final String path = paths.optString(i, "");
                    if (isPersistentWorkPhoto(path)) {
                        continue;
                    }
                    if (!isLegacyWorkPhoto(path)) {
                        continue;
                    }
                    final File source = new File(path);
                    if (!source.exists()) {
                        continue;
                    }

                    final ContentValues values = new ContentValues();
                    values.put(
                            MediaStore.MediaColumns.DISPLAY_NAME,
                            source.getName()
                    );
                    values.put(
                            MediaStore.MediaColumns.MIME_TYPE,
                            "image/jpeg"
                    );
                    values.put(
                            MediaStore.MediaColumns.RELATIVE_PATH,
                            relativeFolder
                    );

                    final Uri destination = context
                            .getContentResolver()
                            .insert(
                                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                                    values
                            );
                    if (destination == null) {
                        continue;
                    }

                    try (
                            FileInputStream input = new FileInputStream(source);
                            OutputStream output = context
                                    .getContentResolver()
                                    .openOutputStream(destination, "w")
                    ) {
                        if (output == null) {
                            continue;
                        }
                        final byte[] buffer = new byte[16 * 1024];
                        int read;
                        while ((read = input.read(buffer)) != -1) {
                            output.write(buffer, 0, read);
                        }
                        copied++;
                    }
                }

                showToast(
                        copied + " work photo"
                                + (copied == 1 ? "" : "s")
                                + " exported to Downloads/Accutek Inventory/Work Photos"
                );
            } catch (Exception error) {
                showToast(
                        "Could not export the work photos: "
                                + safeMessage(error)
                );
            }
        });
    }

    @JavascriptInterface
    public void openWorkPhotoFolder() {
        activity.runOnUiThread(() -> {
            try {
                final Uri initial = DocumentsContract.buildDocumentUri(
                        "com.android.externalstorage.documents",
                        "primary:Download/Accutek Inventory/Work Photos"
                );
                final Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(initial, "resource/folder");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(view);
            } catch (Exception firstError) {
                try {
                    final Intent tree = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    tree.putExtra(
                            DocumentsContract.EXTRA_INITIAL_URI,
                            DocumentsContract.buildDocumentUri(
                                    "com.android.externalstorage.documents",
                                    "primary:Download/Accutek Inventory/Work Photos"
                            )
                    );
                    activity.startActivity(tree);
                } catch (Exception secondError) {
                    showToast("Open Files, then Download/Accutek Inventory/Work Photos");
                }
            }
        });
    }

    @JavascriptInterface
    public void openPersonalGallery() {
        activity.runOnUiThread(() -> {
            try {
                final Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        "image/*"
                );
                activity.startActivity(intent);
            } catch (Exception error) {
                showToast("Open your phone Gallery to review personal originals");
            }
        });
    }

    @JavascriptInterface
    public void getPhotoStorageStatus(String requestId, String storedPathsJson) {
        ioExecutor.execute(() -> {
            try {
                final JSONArray paths = new JSONArray(
                        storedPathsJson == null ? "[]" : storedPathsJson
                );
                int persistent = 0;
                int legacy = 0;
                int missing = 0;
                long totalBytes = 0;
                for (int i = 0; i < paths.length(); i++) {
                    final String path = paths.optString(i, "");
                    if (isPersistentWorkPhoto(path)) {
                        persistent++;
                        final long size = storedPhotoSize(path);
                        if (size < 0) missing++;
                        else totalBytes += size;
                    } else if (isLegacyWorkPhoto(path)) {
                        legacy++;
                        final File file = new File(path);
                        if (!file.exists()) missing++;
                        else totalBytes += file.length();
                    } else {
                        missing++;
                    }
                }
                final JSONObject result = new JSONObject();
                result.put("persistentCount", persistent);
                result.put("legacyCount", legacy);
                result.put("missingCount", missing);
                result.put("totalBytes", totalBytes);
                sendWorkPhotoResult(requestId, result, "");
            } catch (Exception error) {
                sendWorkPhotoResult(requestId, null, safeMessage(error));
            }
        });
    }

    @JavascriptInterface
    public void migrateLegacyWorkPhotos(String requestId, String photosJson) {
        ioExecutor.execute(() -> {
            final JSONArray migrated = new JSONArray();
            final JSONArray failed = new JSONArray();
            try {
                final JSONArray photos = new JSONArray(
                        photosJson == null ? "[]" : photosJson
                );
                for (int i = 0; i < photos.length(); i++) {
                    final JSONObject item = photos.optJSONObject(i);
                    if (item == null) continue;
                    final String id = item.optString("id", "");
                    final String oldPath = item.optString("path", "");
                    if (!isLegacyWorkPhoto(oldPath)) {
                        failed.put(id);
                        continue;
                    }
                    Bitmap bitmap = null;
                    try {
                        final byte[] bytes = readStoredPhotoBytes(oldPath);
                        bitmap = decodeBitmap(bytes, 3600);
                        if (bitmap == null) throw new IllegalStateException("Could not decode older photo");
                        Date photoDate = new Date();
                        final String createdAt = item.optString("createdAt", "");
                        if (!createdAt.isBlank()) {
                            try {
                                photoDate = Date.from(java.time.Instant.parse(createdAt));
                            } catch (Exception ignored) {
                            }
                        }
                        final JSONObject stored = writePersistentPhoto(
                                bitmap,
                                item.optString("partName", "Unknown Part"),
                                item.optString("stage", "process"),
                                item.optString("setName", "Photo Set"),
                                photoDate
                        );
                        final File legacyFile = new File(oldPath);
                        if (legacyFile.exists() && legacyFile.delete()) {
                            removeEmptyParents(legacyFile.getParentFile());
                        }
                        stored.put("id", id);
                        migrated.put(stored);
                    } catch (Exception photoError) {
                        failed.put(id);
                    } finally {
                        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                    }
                }
                final JSONObject result = new JSONObject();
                result.put("migrated", migrated);
                result.put("failed", failed);
                sendWorkPhotoResult(requestId, result, "");
            } catch (Exception error) {
                sendWorkPhotoResult(requestId, null, safeMessage(error));
            }
        });
    }

    @JavascriptInterface
    public void saveTextFile(String filename, String mimeType, String content) {
        ioExecutor.execute(() -> {
            try {
                final String safeName = sanitizeFilename(filename);
                final ContentResolver resolver = context.getContentResolver();
                final ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
                values.put(
                        MediaStore.MediaColumns.MIME_TYPE,
                        mimeType == null || mimeType.isBlank()
                                ? "text/plain"
                                : mimeType
                );
                values.put(
                        MediaStore.MediaColumns.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/Accutek Inventory"
                );

                final Uri uri = resolver.insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                        values
                );
                if (uri == null) {
                    throw new IllegalStateException(
                            "Downloads location is unavailable"
                    );
                }
                try (OutputStream stream = resolver.openOutputStream(uri, "w")) {
                    if (stream == null) {
                        throw new IllegalStateException(
                                "The download file could not be opened"
                        );
                    }
                    stream.write(
                            (content == null ? "" : content)
                                    .getBytes(StandardCharsets.UTF_8)
                    );
                }
                showToast(
                        "Saved to Downloads/Accutek Inventory/" + safeName
                );
            } catch (Exception error) {
                showToast(
                        "Could not save the file: " + safeMessage(error)
                );
            }
        });
    }

    void close() {
        recognizer.close();
        ioExecutor.shutdownNow();
    }

    private JSONObject writePersistentPhoto(
            Bitmap bitmap,
            String partName,
            String stage,
            String setName,
            Date photoDate
    ) throws Exception {
        final String dateFolder = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(photoDate);
        final String timestamp = new SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.US).format(photoDate);
        final String filename = timestamp
                + "-" + UUID.randomUUID().toString().substring(0, 8)
                + "-" + safeFolder(stage, "process") + ".jpg";
        final String relativeFolder = PERSISTENT_RELATIVE_ROOT
                + safeFolder(partName, "Unknown Part") + "/"
                + dateFolder + "/"
                + safeFolder(setName, "Photo Set") + "/";

        final ByteArrayOutputStream encoded = new ByteArrayOutputStream();
        if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 92, encoded)) {
            throw new IllegalStateException("The work photo could not be converted to JPEG");
        }
        final byte[] jpeg = encoded.toByteArray();

        final ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
        values.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, relativeFolder);
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);

        final ContentResolver resolver = context.getContentResolver();
        final Uri destination = resolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
        );
        if (destination == null) {
            throw new IllegalStateException("The visible Work Photos folder is unavailable");
        }

        boolean finished = false;
        try (OutputStream output = resolver.openOutputStream(destination, "w")) {
            if (output == null) {
                throw new IllegalStateException("The work photo file could not be opened");
            }
            output.write(jpeg);
            output.flush();
            finished = true;
        } finally {
            if (!finished) {
                resolver.delete(destination, null, null);
            }
        }

        final ContentValues ready = new ContentValues();
        ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
        resolver.update(destination, ready, null, null);

        final JSONObject result = new JSONObject();
        result.put("path", destination.toString());
        result.put("filename", filename);
        result.put("fileSizeBytes", jpeg.length);
        result.put("persistentStorage", true);
        result.put("privateStorage", false);
        return result;
    }

    private byte[] readStoredPhotoBytes(String storedPath) throws Exception {
        final InputStream input;
        if (isPersistentWorkPhoto(storedPath)) {
            input = context.getContentResolver().openInputStream(Uri.parse(storedPath));
        } else {
            input = new FileInputStream(requireLegacyWorkPhoto(storedPath));
        }
        if (input == null) {
            throw new IllegalStateException("The work photo file is unavailable");
        }
        try (InputStream source = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            final byte[] buffer = new byte[16 * 1024];
            int read;
            while ((read = source.read(buffer)) != -1) {
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        }
    }

    private long storedPhotoSize(String storedPath) {
        if (isLegacyWorkPhoto(storedPath)) {
            final File file = new File(storedPath);
            return file.exists() ? file.length() : -1;
        }
        if (!isPersistentWorkPhoto(storedPath)) return -1;
        try (Cursor cursor = context.getContentResolver().query(
                Uri.parse(storedPath),
                new String[]{OpenableColumns.SIZE},
                null,
                null,
                null
        )) {
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndex(OpenableColumns.SIZE);
                return index >= 0 ? cursor.getLong(index) : 0;
            }
        } catch (Exception ignored) {
        }
        return -1;
    }

    private Bitmap decodeBitmap(byte[] bytes, int maxSide) throws Exception {
        if (bytes == null || bytes.length == 0) {
            return null;
        }

        try {
            final ImageDecoder.Source source = ImageDecoder.createSource(ByteBuffer.wrap(bytes));
            return ImageDecoder.decodeBitmap(source, (decoder, info, src) -> {
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                decoder.setMemorySizePolicy(ImageDecoder.MEMORY_POLICY_LOW_RAM);
                final int width = info.getSize().getWidth();
                final int height = info.getSize().getHeight();
                final int largest = Math.max(width, height);
                if (maxSide > 0 && largest > maxSide) {
                    final int sample = Math.max(1, (int) Math.ceil((double) largest / maxSide));
                    decoder.setTargetSampleSize(sample);
                }
            });
        } catch (Exception imageDecoderError) {
            final Bitmap fallback = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (fallback != null) {
                return fallback;
            }
            throw imageDecoderError;
        }
    }

    private byte[] decodeDataUrl(String dataUrl) {
        final int comma = dataUrl == null ? -1 : dataUrl.indexOf(',');
        final String encoded = comma >= 0
                ? dataUrl.substring(comma + 1)
                : dataUrl;
        return Base64.decode(encoded, Base64.DEFAULT);
    }

    private String createThumbnailDataUrl(Bitmap bitmap) {
        final int maxSide = 320;
        final double scale = Math.min(
                1.0,
                (double) maxSide / Math.max(bitmap.getWidth(), bitmap.getHeight())
        );
        final int width = Math.max(
                1,
                (int) Math.round(bitmap.getWidth() * scale)
        );
        final int height = Math.max(
                1,
                (int) Math.round(bitmap.getHeight() * scale)
        );
        final Bitmap thumb = width == bitmap.getWidth()
                && height == bitmap.getHeight()
                ? bitmap
                : Bitmap.createScaledBitmap(bitmap, width, height, true);
        final ByteArrayOutputStream stream = new ByteArrayOutputStream();
        thumb.compress(Bitmap.CompressFormat.JPEG, 62, stream);
        if (thumb != bitmap) {
            thumb.recycle();
        }
        return "data:image/jpeg;base64,"
                + Base64.encodeToString(
                        stream.toByteArray(),
                        Base64.NO_WRAP
                );
    }

    private ArrayList<Uri> parseManagedPhotoUris(String json) throws Exception {
        final JSONArray paths = new JSONArray(json == null ? "[]" : json);
        final ArrayList<Uri> uris = new ArrayList<>();
        for (int i = 0; i < paths.length(); i++) {
            final String path = paths.optString(i, "");
            if (isPersistentWorkPhoto(path)) {
                uris.add(Uri.parse(path));
            } else if (isLegacyWorkPhoto(path)) {
                final File file = new File(path);
                if (!file.exists()) continue;
                uris.add(
                        FileProvider.getUriForFile(
                                activity,
                                activity.getPackageName() + ".fileprovider",
                                file
                        )
                );
            }
        }
        return uris;
    }

    private File requireLegacyWorkPhoto(String absolutePath) {
        if (!isLegacyWorkPhoto(absolutePath)) {
            throw new IllegalArgumentException("Photo is outside the legacy work folder");
        }
        final File file = new File(absolutePath);
        if (!file.exists()) {
            throw new IllegalArgumentException("Photo file is missing");
        }
        return file;
    }

    private boolean isPersistentWorkPhoto(String storedPath) {
        if (storedPath == null || !storedPath.startsWith("content://")) {
            return false;
        }
        try (Cursor cursor = context.getContentResolver().query(
                Uri.parse(storedPath),
                new String[]{MediaStore.MediaColumns.RELATIVE_PATH},
                null,
                null,
                null
        )) {
            if (cursor == null || !cursor.moveToFirst()) return false;
            final int index = cursor.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
            if (index < 0) return false;
            final String relative = cursor.getString(index);
            return relative != null
                    && relative.replace("\\", "/").startsWith(PERSISTENT_RELATIVE_ROOT);
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean isLegacyWorkPhoto(String absolutePath) {
        if (absolutePath == null || absolutePath.isBlank() || absolutePath.startsWith("content://")) {
            return false;
        }
        try {
            final File picturesRoot = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            if (picturesRoot == null) return false;
            final File workRoot = new File(picturesRoot, LEGACY_WORK_ROOT);
            final String canonicalRoot = workRoot.getCanonicalPath() + File.separator;
            final String canonicalPhoto = new File(absolutePath).getCanonicalPath();
            return canonicalPhoto.startsWith(canonicalRoot);
        } catch (Exception ignored) {
            return false;
        }
    }

    private void removeEmptyParents(File folder) {
        try {
            final File picturesRoot = context.getExternalFilesDir(
                    Environment.DIRECTORY_PICTURES
            );
            if (picturesRoot == null) {
                return;
            }
            final File workRoot = new File(picturesRoot, LEGACY_WORK_ROOT);
            while (folder != null
                    && !folder.equals(workRoot)
                    && folder.isDirectory()) {
                final File[] children = folder.listFiles();
                if (children != null && children.length == 0) {
                    final File parent = folder.getParentFile();
                    //noinspection ResultOfMethodCallIgnored
                    folder.delete();
                    folder = parent;
                } else {
                    break;
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void sendOcrResult(String requestId, String text, String error) {
        final String script = "window.onNativeOcrResult("
                + JSONObject.quote(requestId == null ? "" : requestId) + ","
                + JSONObject.quote(text == null ? "" : text) + ","
                + JSONObject.quote(error == null ? "" : error)
                + ");";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void sendWorkPhotoResult(
            String requestId,
            JSONObject result,
            String error
    ) {
        final String script = "window.onNativeWorkPhotoSaved("
                + JSONObject.quote(requestId == null ? "" : requestId) + ","
                + (result == null ? "null" : result.toString()) + ","
                + JSONObject.quote(error == null ? "" : error)
                + ");";
        webView.post(() -> webView.evaluateJavascript(script, null));
    }

    private void showToast(String message) {
        webView.post(() ->
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        );
    }

    private static String sanitizeFilename(String filename) {
        final String fallback = "accutek-inventory-export.txt";
        if (filename == null || filename.isBlank()) {
            return fallback;
        }
        final String sanitized = filename.replaceAll(
                "[^A-Za-z0-9._-]",
                "_"
        );
        return sanitized.isBlank() ? fallback : sanitized;
    }

    private static String safeFolder(String value, String fallback) {
        final String cleaned = value == null
                ? ""
                : value.trim().replaceAll("[^A-Za-z0-9._ -]", "_");
        final String compact = cleaned.replaceAll("\\s+", " ").trim();
        if (compact.isBlank()) {
            return fallback;
        }
        return compact.length() > 80
                ? compact.substring(0, 80)
                : compact;
    }

    private static String safeMessage(Exception error) {
        return error.getMessage() == null
                ? "unknown error"
                : error.getMessage();
    }
}
