#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.7 is required. Android Studio can also build this project directly."
  exit 1
fi
gradle assembleDebug
