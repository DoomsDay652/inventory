# No shrinking rules are needed for this prototype.
