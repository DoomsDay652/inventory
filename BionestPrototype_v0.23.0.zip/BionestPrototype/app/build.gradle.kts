plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.bionest.prototype"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.bionest.prototype"
        minSdk = 26
        targetSdk = 35
        versionCode = 27
        versionName = "0.23.0"
    }

    signingConfigs {
        create("prototype") {
            storeFile = file("bionest-prototype.jks")
            storePassword = "bionestprototype"
            keyAlias = "bionestprototype"
            keyPassword = "bionestprototype"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("prototype")
        }
        release {
            signingConfig = signingConfigs.getByName("prototype")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
