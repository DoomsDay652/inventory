# Bionest Prototype v0.18.0

A native Android RTS/resource-gathering prototype drawn entirely with Kotlin `Canvas`. It uses Kotlin `Canvas` gameplay with bundled placeholder sprite sheets for the next art pass, no game engine, and no third-party runtime libraries.

Pre-1.0 note: version 1.0 is being reserved for the first true release build. Current builds remain prototype / pre-release versions.

## v0.17.0 highlights
- Sprite restoration pass for drones, nest structures, camps, and resource nodes.
- UI readability pass with larger panels, clearer buttons, improved spacing, and stronger contrast.
- Bottom command area expanded to reduce text overlap and improve touch readability.


- Added a true terrain presentation pass with larger biome ground patches, layered detail scatter, and biome-specific ridge / shelf lines
- Upgraded water rendering so rivers bend more naturally, shorelines blend into terrain better, and oceans / lakes sit cleaner in the world
- Shifted versioning to a pre-release 0.x series so 1.0 stays reserved for the first release build
- Rebuilt the currently used sprite set with clean transparent placeholder art so broken checkerboard assets no longer appear in play
- Cleaned the drawable resource folder to keep only assets actively referenced by the game
- Replaced the live UI art set with a clean, consistent placeholder pass so the sidebar, menus, buttons, and command panels render correctly
- Replaced the currently used colony, camp, resource, wildlife, and world-prop sprites with cleaner game-ready placeholders

## v1.3.0 highlights

- Added a full placeholder UI uplift with new bio-organic sidebar, menu, button, command-bar, day-strip, and portrait assets
- Added new biome-aware environmental placeholder sprites for trees, rocks, bushes, lakes, and wildlife
- Upgraded world presentation so units, wildlife, menus, and terrain props feel more cohesive together
- Kept the seeded world system generating broad biome variety with ruins, mountains, canyons, groves, camps, rivers, lakes, and ocean edges

## v1.2.0 highlights

- Integrated placeholder sprite assets into the runtime instead of only bundling the sheets
- Added sprite-driven world landmarks, camp visuals, resource visuals, and colony building visuals
- Added animated / directional sprite rendering for colony units and primitive enemies
- Swapped the main menu to the new placeholder UI art set

## v1.1.0 highlights

- Added a true main menu with Play, Settings, Exit, and version display
- Added seeded world generation so each new world can produce a unique biome and landmark layout
- Reworked water generation so rivers and water features are driven by shared world noise instead of isolated per-tile randomness
- Added biome variety including Verdant Forest, Misty Wetland, Crystal Barrens, Highlands, Canyon Expanse, and Ancient Ruins
- Added landmark structures such as ruins, mountains, canyon formations, and sacred groves
- Bundled placeholder pixel-art UI and world sprite sheets in `res/drawable-nodpi` for the next full art-integration pass

## v0.8.0 highlights

- Direct ground movement now works for drones, Watch Units, guards, hatchlings, and Spreaders
- Watch Units can be tapped, ring-selected, moved, guarded, spread out, stopped, and followed
- Spreaders now relocate without automatically burrowing; use their BURROW command to establish biofilm
- Biofilm renders through one shared pixel mask so overlapping growth becomes one connected surface
- New growth started inside existing biofilm is pushed toward its uncovered edge instead of layering at the center
- Mineral and gas fields now spawn before the first Bionest is placed
- Watch Units use a clearer code-drawn pixel sprite


## Core gather and expansion loop

1. Place the Bionest in the starting forest hex.
2. The nest produces larvae and worker drones up to the supported capacity.
3. Select workers individually or with the expanding selection ring.
4. Send workers to blue minerals or green gas; they keep harvesting that resource type until reassigned.
5. Use the BUILD tab to place Biospewers and NestWatchers through the ghost-preview confirmation flow.
6. Spend resources to dissolve fog walls and reveal additional generated hex regions.
7. Grow the purple-orange biofilm network to strengthen workers, buildings, and combat units.

## Guard reassignment

- Tap a guard to select it, or ring-select several guards and hatchlings.
- Tap the Bionest, a Biospewer, or a NestWatcher to assign the selected group to that structure.
- Tap open ground to create a free-standing defense post.
- Guards now travel toward the new post instead of instantly teleporting.
- Guards orbit their assigned defense position after arriving.

## Hatchlings

- Every Biospewer produces hatchlings on a four-second timer.
- Each Biospewer maintains up to twelve hatchlings.
- Hatchlings are smaller and faster than guards.
- Hatchlings have 20 health, making them fragile individually but useful as a large swarm.
- Hatchlings can be selected and reassigned with guards.
- Hatchlings automatically swarm and damage primitive enemies that enter close range.

## Biofilm network

- The first biofilm colony starts beneath the Bionest.
- It slowly expands as translucent purple organic ground with orange speckles.
- Connected Biospewers and NestWatchers become additional biofilm emitters.
- Workers inside biofilm receive movement and harvesting bonuses.
- The nest and connected production buildings operate faster inside biofilm.
- Guards, hatchlings, and spreaders move faster inside biofilm.

### Spreaders

- Open the Bionest menu and purchase a Spreader for `18 M + 14 G`.
- Tap the Spreader, then tap open explored ground.
- It travels to the location, burrows for about two seconds, and becomes a new expanding biofilm colony.
- Up to five unassigned/mobile Spreaders can wait at once.

## Tile resource fields

- Resources are condensed into visible clustered patches rather than many small nodes.
- Every normal unlocked hex begins with two active patches: one mineral and one gas.
- Approximately 4% of tiles are rich mineral regions and approximately 4% are dense gas regions.
- A very small number of tiles become abundant basins with four large patches.
- Rich-region patches are visually larger and marked `RICH` when the camera is close enough.
- Normal patches hold about five to eight times more material than the earlier nodes.
- The exact remaining amount appears over each field.
- When all patches in one tile are exhausted, that tile waits briefly and spawns a fresh set at new valid locations.
- Other tiles continue using their own independent resource cycles.

## Environment and wildlife

- The starting hex contains a lake.
- Newly explored regions can generate lakes, rivers, or coastal ocean water.
- Water blocks walking and construction, creating route and placement constraints.
- Unlocked regions populate with roaming alien wildlife:
  - six-legged grazers
  - small orb hoppers
  - tall reed-like striders
- Wildlife currently wanders peacefully; hunting, threats, and ecosystem interactions are reserved for later systems.

## Stable cloud shadows

- Cloud shadows now exist in world space.
- Zooming and changing orientation no longer compresses or redistributes clouds to fit the current screen.
- Shadows retain their proportions and move continuously across the world.

## Existing systems retained

- Portrait and landscape rotation without resetting the active game
- Collapsible responsive sidebar
- Two-column sidebar layout in landscape when many counters are visible
- Pinch zoom, plus/minus zoom buttons, and camera panning
- Bright day environment and prototype day/night cycle
- Large hex regions with mist-covered fog-of-war frontier
- Tile-based resource fields instead of scattered global nodes
- Every unlocked normal tile maintains two patches: one mineral and one gas
- Rare rich mineral, dense gas, and abundant tiles can generate extra high-capacity patches
- Normal patches contain roughly 420–630 resources; rich patches contain roughly 900–1,260
- Remaining resource amounts are displayed above each patch while zoomed in
- A tile only relocates its resource set after every patch in that set is depleted
- Persistent worker harvesting assignments
- Biospewer and NestWatcher ghost placement with confirm/cancel controls
- Biospewer guard production
- NestWatcher capacity support and Watcher units
- Stable prototype signing key for installing APK updates over earlier stable-signed builds

## GitHub Actions build

Keep this source archive at the repository root as:

```text
BionestPrototype.zip
```

The existing `.github/workflows/build-apk.yml` workflow extracts the archive, finds this Gradle project, and builds a new APK whenever the ZIP is replaced and committed.

The included signing key is only for prototype testing. Create a private production key before any store release.

## v0.9.0 enemy-camp pass

- Primitive enemy camps generate in unlocked hex regions
- Each tent begins with a random population of 2-8 primitive hunters
- Hunters wander locally and remain tied to their camp territory
- Hunters detect nearby colony units, chase them, attack, and retreat when pulled too far from the tent
- Camps slowly replace defeated hunters until their original population is restored
- Guards, hatchlings, and NestWatcher units automatically damage nearby primitive enemies
- Primitive hunters and tents use code-drawn pixel sprites
- Tapping a camp or hunter shows its name, population/health, and current behavior
- Enemy tents block movement and building placement


## v0.10.0 highlights

- Integrated the generated worker-drone sprite sheet into the Android game
- Worker drones now animate while idle, moving, harvesting, and building
- Spreaders now permanently enter a dark-orange BURROWED state
- Burrowed Spreaders cannot move again and automatically expand nearby biofilm
- Unit command buttons are context-sensitive to reduce clutter and dead buttons
- Primitive camps now have health and can be destroyed by combat units
- Destroyed camps award a separate shop-gold currency
- Added a standalone Hive Shop for mineral caches, gas caches, and emergency larvae
- The shop is earned-currency only; real-money monetization is not implemented



## v0.18.0 highlights
- First dedicated organic building sprite pass: staged Bionest growth sprites plus refreshed Biospewer and NestWatcher art.
- UI readability pass: heavier outlined text, clearer labels, and cleaner in-game panel typography.
- Nest visuals now grow by nest level for better progression feedback.


## v0.18.1 highlights
- Fixed unit command card alignment and added more breathing room above command buttons.
- Added a first terrain tile pass with seamless biome pattern textures for forest, wetland, crystal barrens, highlands, canyon, and ruins.
- Continued UI cleanup for better readability and structure.


## v0.19.0 highlights
- Added the next polish pass: improved water / shoreline rendering, stronger canyon and cliff edges, cleaner resource patch sprites, and a broader button layout cleanup.
- Portrait menu grids now organize large action groups more cleanly.
- Resource fields and lakes received a fresh pixel-art pass for easier readability in play.


## v0.19.1 highlights
- Gas nodes now stand out more clearly against grassy terrain with a stronger sprite contrast pass and a distinct in-game glow/base tint.


## v0.19.2 highlights
- Quick UI cleanup pass: improved spacing and hierarchy across menus.
- Main menu now uses the custom UI art in a cleaner contained layout instead of stretched presentation.
- Settings and menu panels were reorganized for a more polished presentation.


## v0.20.0 highlights
- Added the uploaded animated building sheets to the project: `nest_idle_sheet.png` and `biospewer_idle_sheet.png`.
- Wired the Bionest and Biospewer to use those animated sheets in game.
- Bionest still uses growth-stage sprites at higher levels, while early nests use the animated idle sheet.


## v0.21.0 highlights
- Added the first standardized world-scale test using 1 BioCell = 32 world units.
- Expanded the hex radius from 760 to 1,024 world units while lowering the starting zoom so roughly the same amount of terrain remains visible.
- Standardized building visuals, gameplay footprints, spacing, movement speeds, resource sizes, camp sizes, water, landmarks, and interaction ranges around the shared BioCell scale.
- Bionest, Biospewer, NestWatcher, units, resources, camps, wildlife, and placement ghosts now use cell-based sizing.
- Fixed the animated Bionest sheet integration compile issue from v0.20.0.
- Added a scale reference inside Settings for testing.


## v0.22.0 highlights
- Doubled the regional world scale: hex radius increased from 1,024 to 2,048 world units.
- Corrected Nest and Biospewer animation grounding with bottom-center sprite anchors; the Biospewer now stays aligned to its gameplay footprint.
- Controllable colony units now hold position unless explicitly ordered to move, harvest, guard, spread, or burrow.
- Increased tap-selection forgiveness for small units.
- Added tree/rock/bush collision resolution so units cannot occupy obstacle bases.
- Added world-Y depth sorting: units above a tree render behind it, while units below the tree base render in front.


## v0.23.0 highlights
- Added the new full worker creature animation sheet as a clean 18-row atlas with aligned 128x128 cells.
- Wired idle, walk, harvesting/building attack, and carrying animations into worker drone behavior.
- Added directional facing updates so north, south, east, and west animations match movement.
- Preserved death/splatter and morph/incubation rows in the atlas for later gameplay wiring.
